"use strict";
const nodemailer = require('nodemailer');
var sgTransport = require('nodemailer-sendgrid-transport');

const fs = require('fs');

async function sendEmail(compLink, runLink, errorlogs) {

  var size = errorlogs.size
  console.log('map size is : ' + size);

  var errors='';
  if(size>=1){
    for (var [key, value] of errorlogs) {
      errors = errors + '\n' + '\n' + key + '\n' + value + '\n'
    }
  }
  else if (size==0){
    errors='N/A - No Failures';
  }

  var smtpOptions = {
    auth: {
        api_user: 'Sarathkumar.rajendran', api_key: '1!Xlsiorss'
    }
  };

  // var todayTime = new Date();
  // var month = format(todayTime .getMonth() + 1);
  // var day = format(todayTime .getDate());
  // var year = format(todayTime .getFullYear());
  // var date = day + "/" + month + "/" + year;

  var gitpath = 'http://gitlab101.esd-oneapp.prod.rsc.local/one-app/qa-idlite-functional-test/-/jobs/' + process.env.Job_Id
  var runResult = 'https://gcsd.testrail.net/index.php?/runs/view/' + runLink
  var compResult = compLink

      var mailer = nodemailer.createTransport(sgTransport(smtpOptions));

      var email = {
        to: 'Sarathkuma.rajendran@rakuten.com; oleg.levy@rakuten.com; asmita.gahlot@rakuten.com; kartik.vakharia@rakuten.com; razi.kheir@rakuten.com; ts-bahdan.shyshkin@rakuten.com; nethaji.gunasekaran@rakuten.com' ,
        from: '1AppQATeam@rakuten.com',
        subject: "IDLite Automation Results",
        text: "IDLite", 
        html: '<head></head><body>Hello All,<br></br>' +
                'Please find the below report for IDLite API automation tests. <br></br>' +
                '<b>Gitlab job path:</b> <a href=' + gitpath+ '>' +gitpath + '</a><br></br>' + 
                '<b>Testrail:</b> <br></br>' +
                'Run Result: <a href=' + runResult+ '>' +runResult + '</a><br></br>' + 
                'Comparison Result: <a href=' + compResult+ '>' +compResult + '</a><br></br>' + 
                '<b>Run Result:</b> <br></br>' +
                '<img src="cid:unique1@kreata.aaa" width="800"/><br></br>'+
                '<b>Comparison Result:</b> <br></br>' +
                '<img src="cid:unique2@kreata.aaa" width="1300"/><br></br>'+
                '<b>Error logs: </b>' + errors.replace(/\n/g, "<br />") + '<br></br>' + 
                'Thanks, <br></br>' +
                'OneAPP QA Team <br></br>' +
                '</body>',
                  attachments: [{
                    filename: 'testrailrun.png',
                    path: '/builds/one-app/qa-idlite-functional-test/testrailrun.png',
                    //path: '/Users/sarathkuma.rajendran/qa-idlite-api_automation_js/testrailrun.png',
                    cid: 'unique1@kreata.aaa' 
                  },
                  {
                    filename: 'testrail.png',
                    path: '/builds/one-app/qa-idlite-functional-test/testrail.png',
                    //path: '/Users/sarathkuma.rajendran/qa-idlite-api_automation_js/testrail.png',
                    cid: 'unique2@kreata.aaa' 
                  }]
      };

    mailer.sendMail(email, function(err, res) {
      if (err) { 
          console.log(err) 
      }
      console.log(res);
    });
}

module.exports={
  sendEmail
}

