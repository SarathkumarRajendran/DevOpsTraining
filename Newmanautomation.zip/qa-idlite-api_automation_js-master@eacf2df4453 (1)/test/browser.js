selenium = require('selenium-webdriver')
chai = require ('chai')
chai.use = require('chai-as-promised')
expect = chai.expect
const puppeteer = require('puppeteer');


async function run(compLink, runLink) {
    const browser = await puppeteer.launch({
  //    executablePath: "./nnode_modules/puppeteer/.local-chromium/linux-722234/chromium",
        headless: true,
        slowMo: 100,
        timeout: 10000,
       //args: ['--start-fullscreen']
       args: [
        '--no-sandbox'
      ]
      });

      const options = {
        path: 'testrail.png',
        fullPage: false,
        clip: {
          x: 0,
          y: 100,
          width: 2200,
          height: 4400
        }
      }

      const options1 = {
        path: 'testrailrun.png',
        fullPage: false,
        clip: {
          x: 0,
          y: 100,
          width: 900,
          height: 400
        }
      }

    let page = await browser.newPage();
    await page.setViewport({ width: 2200, height: 4400 });
    await page.goto(compLink);
    await page.evaluate(() => {
    document.querySelector("input[id='name']").value = "sarathkuma.rajendran@rakuten.com";
});

await page.evaluate(() => {
    document.querySelector("input[id='password']").value = "3!Xlsiorss";
});

    await page.evaluate(() => {
    document.querySelector("button[id='button_primary']").click();
});
await new Promise(resolve => setTimeout(resolve, 10000));
await page.screenshot(options);
console.log('screenshot is captured')

await page.goto('https://gcsd.testrail.net/index.php?/runs/view/' + runLink);

await new Promise(resolve => setTimeout(resolve, 10000));
await page.screenshot(options1);
console.log('screenshot1 is captured')
await page.close();
await browser.close();

}

module.exports={
  run
}

