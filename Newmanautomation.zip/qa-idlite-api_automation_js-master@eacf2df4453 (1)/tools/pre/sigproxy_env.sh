#!/usr/bin/env bash
#TODO: add the necessary config here
message="pre file"
