#!/usr/bin/env bash
set -ex
mkdir -p $HOME/node_modules
#java -jar '/builds/one-app/qa-idlite-functional-test/tools/Fake-Provider-1.4.6.jar' '/builds/one-app/qa-idlite-functional-test/tools/jwks.provider.json' '4000' &
cp $PWD/tools/$env/.npmrc $HOME/.npmrc
sh $PWD/tools/$env/sigproxy_env.sh
http_proxy=http://pkg.proxy.prod.jp.local:10080 ./signature-proxy  </dev/null &> sig-proxy-log &
sleep 10
#ps aux |grep signature-proxy
cat sig-proxy-log
curl http://localhost:9090/api/v1/multi -v -k | true
echo "proxy settings"
npm config set registry http://registry.npmjs.org/
npm config set proxy http://pkg.proxy.prod.jp.local:10080
npm config set https-proxy http://pkg.proxy.prod.jp.local:10080
npm config set strict-ssl false
# set HTTPS_PROXY=http://dev-proxy.db.rakuten.co.jp:9502
# set HTTP_PROXY=http://dev-proxy.db.rakuten.co.jp:9502
export HTTPS_PROXY=http://dev-proxy.db.rakuten.co.jp:9502
export HTTP_PROXY=http://dev-proxy.db.rakuten.co.jp:9502
export http_proxy=http://dev-proxy.db.rakuten.co.jp:9502
export no_proxy='localhost,127.0.0.1,fake-provider,smtp-mail.outlook.com'
npm config list
npm --proxy http://pkg.proxy.prod.jp.local:10080 \
--without-ssl --insecure -g install

sleep 5
java -jar '/builds/one-app/qa-idlite-functional-test/tools/Fake-Provider-1.4.6.jar' '/builds/one-app/qa-idlite-functional-test/tools/jwks.provider.json' '4000' &
echo "starting test"
npm run test
