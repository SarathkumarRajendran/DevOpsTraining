#!/usr/bin/env bash
#TODO: add the necessary config here
export message="qa file"
export SIGPROXY_CLIENT_ID=IDLiteAPI
export SIGPROXY_CLIENT_KEY_STR='{"crv": "X25519", "d": "qCjC-NpxcMT67UA47d5Ej01qVpX7JnuX2TRx9XL27uE", "kty": "OKP", "kid": "ZD7P-Wh-EqE7uILB2PIaEx2rYdxv6n4Aq4GLpdjKCDw","x": "75hlRe8Y-DNp2WWXtCpOdilpQfqZsODPuzrJ6cx8IC4"}'
export SIGPROXY_CAT_ENV=''
export SIGPROXY_DISCOVERY_URL=https://cat.stress.gipdog.net/api/v1/discovery/keys
export SIGPROXY_SERVER_URL=https://cat.stress.gipdog.net/api/v1

http_proxy=http://pkg.proxy.prod.jp.local:10080 ./signature-proxy -c omni_client -k '{ "crv": "X25519", "d": "ElpZVYEqLKNwCf8yesoe5ncO1YBi9l7b1OgrAWp5WvQ", "kty": "OKP", "kid": "LKex9aAdyETZqSOLreXLkq6uycF7bS6tzXGZUyrMi84","x": "gbfn_ePnQuqwVRPVJ3iREGHldXPC3cJkuQNrK4hhuiM" }' -p 9070 -u https://cat.stress.gipdog.net/api/v1 --discovery-url https://cat.stress.gipdog.net/api/v1/discovery/keys &
sleep 10
ps aux |grep signature-proxy
cat sig-proxy-log
curl http://localhost:9070/api/v1/multi -v -k | true