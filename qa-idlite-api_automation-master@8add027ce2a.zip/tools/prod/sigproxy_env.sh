#!/usr/bin/env bash
#TODO: add the necessary config here
message="prod file"
