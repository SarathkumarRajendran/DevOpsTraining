#!/usr/bin/env bash
set -ex
mkdir -p $HOME/.m2
java -jar '/builds/one-app/qa-cat-idlite-apitesting/tools/Fake-Provider-1.4.5.jar' '/builds/one-app/qa-cat-idlite-apitesting/tools/jwks.provider.json' '4000' &
cp $PWD/tools/$env/settings.xml $HOME/.m2/settings.xml
sh $PWD/tools/$env/sigproxy_env.sh
http_proxy=http://pkg.proxy.prod.jp.local:10080 ./signature-proxy  </dev/null &> sig-proxy-log &
sleep 10
ps aux |grep signature-proxy
cat sig-proxy-log
curl http://localhost:9090/api/v1/multi -v -k | true
echo "starting test"
mvn test verify 
