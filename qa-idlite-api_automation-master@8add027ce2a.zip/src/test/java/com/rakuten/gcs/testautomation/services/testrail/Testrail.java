package com.rakuten.gcs.testautomation.services.testrail;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.mashape.unirest.http.utils.Base64Coder;

public class Testrail {

	
	 public static void main(String args[]) {
	  
		 String value = Base64Coder.encodeString("sarathkuma.rajendran@rakuten.com" + ":" + "3!Xlsiorss");
		 System.out.println(value);
		
		 String value1 = Base64Coder.decodeString(value);
		 System.out.println(value1);
		 
	 }
}

