package com.rakuten.gcs.testautomation.framework.api;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import cucumber.api.Scenario;

/**
 * Created by aldo.suwandi on 2015/08/27.
 */
public class SoapPort {

    final Log logger = LogFactory.getLog(SoapPort.class);

    private Map<String, SoapAPIObjectBase> soapObjectMap;
    private SoapAPIClient soapApiClient;
    private SoapAPIObjectBase selectedOperator;
    private String serviceName;

    public SoapPort() {
        soapObjectMap = new HashMap<String, SoapAPIObjectBase>();
    }

    public void initializeSoapClient(Scenario scenario, String proxyServer, int proxyPort) throws MalformedURLException, SOAPException {
        logger.info("Scenario : " + scenario.getName());
        this.soapApiClient = new SoapAPIClient(proxyServer, proxyPort);
    }

    public void initializeSoapClient(Scenario scenario, String proxyServer, int proxyPort, String proxyUsername, String proxyPassword) throws MalformedURLException, SOAPException {
        this.soapApiClient = new SoapAPIClient(proxyServer, proxyPort, proxyUsername, proxyPassword);
    }

    public Map<String, SoapAPIObjectBase> getOperators() {
        return this.soapObjectMap;
    }

    public void addOperator(String name, SoapAPIObjectBase soapAPIObjectBase) throws SOAPException {
        this.soapObjectMap.put(name, soapAPIObjectBase);
    }

    public SoapAPIObjectBase getOperator(String name) {
        this.selectedOperator = this.soapObjectMap.get(name);
        return this.soapObjectMap.get(name);
    }

    public SoapAPIClient getSoapApiClient() {
        return soapApiClient;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public void setSelectedOperator(String selectedOperator) {
        this.selectedOperator = this.getOperator(selectedOperator);
    }

    public SoapAPIObjectBase getSelectedOperator() {
        return this.selectedOperator;
    }

}
