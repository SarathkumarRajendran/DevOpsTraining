package com.rakuten.gcs.testautomation.framework.api.client;

import com.rakuten.gcs.testautomation.framework.api.object.APIObjectBase;
import com.rakuten.gcs.testautomation.framework.api.object.SoapAPIObjectBase;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import java.io.IOException;
import java.net.*;

/**
 * Created by aldo.suwandi on 2015/08/20.
 */
public class SoapAPIClient extends BaseAPIClient {

    final static Log logger = LogFactory.getLog(SoapAPIClient.class);

    public SoapAPIClient(String baseURI, String proxyHost, int proxyPort) {
        super(baseURI, proxyHost, proxyPort);
    }

    public SoapAPIClient(String baseURI) {
        super(baseURI);
    }

    private URL createConnection() throws URISyntaxException, MalformedURLException {
        URL url;
        if (this.proxy != null) {
            logger.info("Creating connection with Proxy "+this.proxy);
            URI uri = new URI(proxy.toURI());
            final Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(uri.getHost(), uri.getPort()));
            url = new URL(null, baseURI, new URLStreamHandler() {
                protected URLConnection openConnection(URL url) throws IOException {
                    URL clone = new URL(url.toString());
                    URLConnection urlConnection = null;
                    if (proxy.address().toString().equals("0.0.0.0/0.0.0.0:80")) {
                        urlConnection = clone.openConnection();
                    } else {
                        urlConnection = clone.openConnection(proxy);
                        urlConnection.setConnectTimeout(99999);
                        urlConnection.setReadTimeout(99999);
                    }
                    return urlConnection;
                }
            });
        } else {
            logger.info("Creating connection without Proxy");
            url = new URL(baseURI);
        }
        return url;
    }

    @Override public void sendRequest(APIObjectBase apiObjectBase) throws Exception {
        logger.info("#################################################");
        logger.info("------------------Request Start------------------");
        SoapAPIObjectBase soapAPIObjectBase = (SoapAPIObjectBase) apiObjectBase;
        URL baseURL = createConnection();
        logger.info("URL : " + baseURL);
        if (soapAPIObjectBase.getSoapAction() != null && !soapAPIObjectBase.getSoapAction().isEmpty()) {
            String soapActionUrl = baseURL.getProtocol()+ "://"+ baseURL.getHost() + "/" +soapAPIObjectBase.getSoapAction();
            soapAPIObjectBase.getSoapMessage().getMimeHeaders().addHeader("SOAPAction",soapActionUrl);
        }
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        SOAPConnection soapConnection = soapConnectionFactory.createConnection();
        soapAPIObjectBase.getSoapMessage().saveChanges();
        logger.info("HTTP Request Message : ");
        soapAPIObjectBase.printSoapMessage(soapAPIObjectBase.getSoapMessage());
        logger.info("------------------Request End------------------");
        SOAPMessage soapMessage = soapConnection.call(soapAPIObjectBase.getSoapMessage(), baseURL);
        soapAPIObjectBase.setHttpResponse(soapMessage);
        logger.info("-----------------Response Start----------------");
        logger.info("HTTP Response Message : ");
        soapAPIObjectBase.printSoapMessage(soapMessage);
        logger.info("#################################################");
    }
}