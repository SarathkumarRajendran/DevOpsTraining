package com.rakuten.gcs.testautomation.framework.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created by aldo.suwandi on 2016/01/21.
 */
public class Property {

    final static Log logger = LogFactory.getLog(Property.class);

    public static String getSauceLabsEnvironment(String key) {
        String value = get(key);
        if (value.isEmpty()) {
            switch (key) {
                case "SAUCELABS_PROXY":
                    return "http://pkg.proxy.prod.jp.local:10080";
                case "SAUCE_USERNAME":
                    logger.info("using default username");
                    return "qeuser";
                case "SAUCE_ACCESS_KEY":
                    logger.info("using default accesskey");
                    return "3ff01068-5283-4316-91ce-6ce27d649d87";
                case "SAUCELABS_OS":
                    return get("SELENIUM_PLATFORM");
                case "SAUCELABS_BROWSER_NAME":
                    return get("SELENIUM_BROWSER");
                case "SAUCELABS_BROWSER_VERSION":
                    return get("SELENIUM_VERSION");
                case "SAUCELABS_PLATFORM_NAME":
                    return get("SELENIUM_PLATFORM");
            }
            return "";
        } else {
            return value;
        }
    }

    public static String get(String key) {
        try {
            if (!System.getenv(key).trim().isEmpty()) {
                logger.info("Using {" + key + "} value from environment variable");
                return System.getenv(key);
            } else {
                logger.info("No value for " + key);
                return "";
            }
        } catch (NullPointerException ex) {
            try {
                if (!System.getProperty(key).trim().isEmpty()) {
                    logger.info("Using " + key + " value from property");
                    return System.getProperty(key);
                } else {
                    logger.info("No value for " + key);
                    return "";
                }
            } catch (NullPointerException ex1) {
                logger.info("No value for " + key);
                return "";
            }
        }
    }

}
