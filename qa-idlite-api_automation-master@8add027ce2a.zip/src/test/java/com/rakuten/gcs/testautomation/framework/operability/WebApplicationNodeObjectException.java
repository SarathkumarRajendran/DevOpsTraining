package com.rakuten.gcs.testautomation.framework.operability;

@SuppressWarnings("serial")
public class WebApplicationNodeObjectException extends Exception {

    public WebApplicationNodeObjectException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public WebApplicationNodeObjectException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }

    public WebApplicationNodeObjectException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public WebApplicationNodeObjectException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public WebApplicationNodeObjectException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
