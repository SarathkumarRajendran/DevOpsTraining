package com.rakuten.gcs.testautomation.services.IDLiteAPIs.runtest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpHost;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.http.utils.Base64Coder;
import com.rakuten.gcs.testautomation.services.IDLiteAPIs.steps.IDLiteAPIsCommonSteps;
import com.rakuten.gcs.testautomation.services.testrail.TestRailIntegrationClient;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import net.sf.json.JSONObject;


@RunWith(Cucumber.class)

@CucumberOptions(strict = false,
        format = { "pretty", "html:target/test-report/premium", "json:target/cucumber.json", "junit:target/test-report/premium/test-report.xml" , "html:target/site/cucumber-pretty"},
        features = {
        		"src/test/resources/com/rakuten/gcs/testautomation/services/IDLiteAPI/feature/happyPath/IDLiteAPI_happyPath.feature"
        	,"src/test/resources/com/rakuten/gcs/testautomation/services/IDLiteAPI/feature/errorCheck/IDLiteAPI_errorCheck.feature"
        	,"src/test/resources/com/rakuten/gcs/testautomation/services/IDLiteAPI/feature/happyPath/DeactivationAPI_happyPath.feature"
        	,"src/test/resources/com/rakuten/gcs/testautomation/services/IDLiteAPI/feature/errorCheck/DeactivationAPI_errorCheck.feature"
        
         },
        glue = { 
        		"com.rakuten.gcs.testautomation.services.IDLiteAPIs.steps",
        }
      //  ,tags = {"@Test"}
        
)


public class IDLiteAPIs_RunTest {
	
//	final static Log logger = LogFactory.getLog(IDLiteAPIsCommonSteps.class);
//	static String jsonPath = "src/test/resources/com/rakuten/gcs/testautomation/services/IDLiteAPI/json/";
//	
//	 static String requestBody;
//	 public static String runid;
//	 static HttpResponse<String> postRes;
//	
//	@BeforeClass
//    public  static void beforeAll() throws UnirestException {
//		Unirest.setProxy(new HttpHost("dev-proxy.db.rakuten.co.jp", 9502));
//		
//		Map<String, String> headers = new HashMap<String, String>();
//		String URL="https://gcsd.testrail.net/index.php?/api/v2/add_plan_entry/416";
//		
//		requestBody = JsonUtils.loadJsonFromResource(jsonPath + "happyPath/IDLiteAPIs.json", "testrail_update");
//		
//		  Date objDate = new Date(); 
//		  String strDateFormat = "dd-MM hh:mm";  
//		  SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); 
//		
//		  String randomRunName = "IDLite_API_" + objSDF.format(objDate); 
//		
//			if (requestBody.contains("$Fromrandom")) {
//				requestBody = requestBody.replace("$Fromrandom", randomRunName);
//			}
//				headers.put("Content-Type", "application/json");
//				headers.put("Authorization", "Basic c2FyYXRoa3VtYS5yYWplbmRyYW5AcmFrdXRlbi5jb206MyFYbHNpb3Jzcw==");
//				logger.info("request URL:" + URL);				
//				logger.info("headers --> "+headers);
//				logger.info("Read Request Body: " + requestBody);
//							
//				postRes = Unirest.post(URL).headers(headers).body(requestBody).asString();		
//				logger.info("Read Response Body: " + postRes.getBody());
//					
//				JSONObject jsonObject = JSONObject.fromObject(postRes.getBody());	
//				runid = jsonObject.getJSONArray("runs").getJSONObject(0).getString("id");
//				logger.info("runid is:" + runid);
//
//			Unirest.setProxy(null);
//
//    } 
//	
//	@AfterClass
//	public static void afterAll() throws UnirestException {
//		Unirest.setProxy(new HttpHost("dev-proxy.db.rakuten.co.jp", 9502));
//		
//		Map<String, String> headers = new HashMap<String, String>();
//		String URL="https://gcsd.testrail.net/index.php?/api/v2/run_report/8";
//
//				headers.put("Content-Type", "application/json");
//				headers.put("Authorization", "Basic c2FyYXRoa3VtYS5yYWplbmRyYW5AcmFrdXRlbi5jb206MyFYbHNpb3Jzcw==");
//				logger.info("request URL:" + URL);				
//				logger.info("headers --> "+headers);
//
//				postRes = Unirest.get(URL).headers(headers).asString();
//		
//				logger.info("Read Response Body: " + postRes.getBody());
//				
//				JSONObject jsonObject = JSONObject.fromObject(postRes.getBody());
//	
//				 String report_url = jsonObject.getString("report_url");
//				 String report_html = jsonObject.getString("report_html");
//				 String report_pdf = jsonObject.getString("report_pdf");		 
//	
//				 logger.info("report_url is:" + report_url);
//				 logger.info("report_html is:" + report_html);
//				 logger.info("report_pdf is:" + report_pdf);
//		Unirest.setProxy(null);
//	}
//	
	
	
	
}
