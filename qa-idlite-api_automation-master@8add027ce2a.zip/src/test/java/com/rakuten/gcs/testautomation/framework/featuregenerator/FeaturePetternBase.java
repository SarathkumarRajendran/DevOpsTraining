package com.rakuten.gcs.testautomation.framework.featuregenerator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import com.rakuten.gcs.testautomation.framework.web.PageObjectBase;

public class FeaturePetternBase {

    final static String WITHOUT_EXPECTATION_FEATURE_FILE_PREFIX = "Without-expectaion-";
    final static String WITH_EXPECTATION_FEATURE_FILE_PREFIX = "With-expectaion-";

    protected String feature;
    protected String background = null;
    protected List<String> givenPhrases;
    protected String scenarioOutline = null;
    protected List<String> whenPhrases;
    protected List<String> thenPhrases;
    protected String examplePhrase;
    protected String examplesHeader;
    protected List<String> examples;

    public String featureFileSuffix;
    public String featureFileName;

    public FeaturePetternBase(String patternFileName, String suffix) throws Exception {
        givenPhrases = new ArrayList<String>();
        whenPhrases = new ArrayList<String>();
        thenPhrases = new ArrayList<String>();
        examples = new ArrayList<String>();
        featureFileSuffix = suffix;
        readPatternFile(patternFileName);
    }

    final private void readPatternFile(String patternFileName) throws Exception {
        File file;
        BufferedReader bufferedReader = null;
        try {
            file = new File(patternFileName);
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
            //System.out.println("patternFileName = " + patternFileName);
            //int count=0;
            String line = bufferedReader.readLine();
            while (line != null) {
                //System.out.println(count);
                //System.out.println("line=" + line);
                //count++;
                Thread.sleep(1000);
                if (line.trim().startsWith("Feature")) {
                    feature = line;
                    line = bufferedReader.readLine();
                    continue;
                } else if (line.trim().startsWith("Background")) {
                    background = line;
                    line = bufferedReader.readLine();
                    while (line.trim().startsWith("Given")) {
                        givenPhrases.add(line);
                        line = bufferedReader.readLine();
                    }
                    continue;
                } else if (line.trim().startsWith("Scenario Outline")) {
                    scenarioOutline = line;
                    line = bufferedReader.readLine();
                    while (line.trim().startsWith("When") || line.trim().startsWith("Then")) {
                        if (line.trim().startsWith("When")) {
                            whenPhrases.add(line);
                        } else {
                            thenPhrases.add(line);
                        }
                        line = bufferedReader.readLine();
                    }
                    continue;
                } else if (line.trim().startsWith("Examples")) {
                    examplePhrase = line;

                    line = bufferedReader.readLine();
                    examplesHeader = line;
                    while ((line = bufferedReader.readLine()) != null) {
                        examples.add(line);
                        //System.out.println(line);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
            throw e;
        } finally {
            bufferedReader.close();
        }
    }

    final private String getFeatureFileDirectoryName(PageObjectBase pageObject, String suffix) {
        String packageName = pageObject.getClass().getPackage().getName();
        String directoryName = "src/test/resources/" + packageName.replaceAll("\\.", "/").replaceAll("pageobject", "") + "tmp";
        return directoryName;
    }

    final private void checkDirectoryExistsThenCreateDirectoryIfNotExist(String directoryName) {
        File directory = new File(directoryName);
        if (!directory.exists()) {
            directory.mkdir();
        }

    }

    protected void writeFeaturePart(PrintWriter writer, String pageName) {
        writer.println(feature.replaceAll("\\$PageName", pageName));
    }

    protected void writeBackgroundPart(PrintWriter writer, String pageName) {
        writer.println(background);
        for (String givenPhrase : givenPhrases) {
            writer.println(givenPhrase.replaceAll("\\$PageName", pageName).replace("$featureFile", featureFileName));
        }
    }

    protected void writeScenarioOutlinePart(PrintWriter writer) {
        writer.println(scenarioOutline);
        for (String whenPhrase : whenPhrases) {
            writer.println(whenPhrase);
        }
        for (String thenPhrase : thenPhrases) {
            writer.println(thenPhrase);
        }
    }

    protected void writeExamplesPart(PrintWriter writer, PageObjectBase pageObject) {
        writer.println(examplePhrase);
        writer.println(examplesHeader);
        for (String example : examples) {
            writer.println(example);
        }
    }

    protected void writeExamplesPartWithExpectations(PrintWriter writer, PageObjectBase pageObject, List<String> outputElements, List<String> messages) {
        writer.println(examplePhrase);
        writer.println(examplesHeader);
        for (String example : examples) {
            writer.println(example);
        }
    }

    final protected PrintWriter getWriterForFeatureFileThenSetIt(PageObjectBase pageObject, String prefix) throws FileNotFoundException, UnsupportedEncodingException {
        String pageName = pageObject.getClass().getSimpleName();
        String directoryName = getFeatureFileDirectoryName(pageObject, featureFileSuffix);
        featureFileName = directoryName + "/" + prefix + pageName + featureFileSuffix;

        checkDirectoryExistsThenCreateDirectoryIfNotExist(directoryName);
        return new PrintWriter(featureFileName, "UTF-8");

    }

    final protected BufferedWriter getAppendableWriterThenSetIt(PageObjectBase pageObject, String prefix) throws UnsupportedEncodingException, FileNotFoundException {
        String pageName = pageObject.getClass().getSimpleName();
        String directoryName = getFeatureFileDirectoryName(pageObject, featureFileSuffix);
        featureFileName = directoryName + "/" + prefix + pageName + featureFileSuffix;

        checkDirectoryExistsThenCreateDirectoryIfNotExist(directoryName);
        //System.out.println("Open writer for " + featureFileName);
        OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(featureFileName, true), "UTF-8");
        return new BufferedWriter(writer);
    }

    final private void writeOutBasePart(PrintWriter writer, PageObjectBase pageObject) throws FileNotFoundException, UnsupportedEncodingException {
        String pageName = pageObject.getClass().getSimpleName();
        writeFeaturePart(writer, pageName);
        writeBackgroundPart(writer, pageName);
        writeScenarioOutlinePart(writer);

    }

    final public void writeFeatureFile(PageObjectBase pageObject) throws FileNotFoundException, UnsupportedEncodingException {

        PrintWriter writer = getWriterForFeatureFileThenSetIt(pageObject, WITHOUT_EXPECTATION_FEATURE_FILE_PREFIX);
        writeOutBasePart(writer, pageObject);
        writeExamplesPart(writer, pageObject);
        writer.close();
    }

}
