package com.rakuten.gcs.testautomation.framework.api.object;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.xml.soap.*;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.util.Iterator;

/**
 * Created by aldo.suwandi on 2015/08/24.
 */

public class SoapAPIObjectBase extends APIObjectBase {

    final static Log logger = LogFactory.getLog(SoapAPIObjectBase.class);

    private SOAPMessage soapMessage;

    private SOAPEnvelope soapEnvelope;

    //For Soap 1.1 Only
    private String soapAction;

    public SoapAPIObjectBase(String apiName) throws SOAPException {
        prepareSoapRequestMessage();
        this.apiName = apiName;
    }

    protected void prepareSoapRequestMessage() throws SOAPException {
        MessageFactory messageFactory = MessageFactory.newInstance();
        soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();
        soapEnvelope = soapPart.getEnvelope();
    }

    public String getSoapAction() {
        return soapAction;
    }

    public void setSoapAction(String soapAction) {
        this.soapAction = soapAction;
    }

    public SOAPMessage getSoapMessage() {
        return soapMessage;
    }

    public SOAPEnvelope getSoapEnvelope() {
        return soapEnvelope;
    }


    public void printSoapMessage(SOAPMessage soapMessage) throws TransformerException, SOAPException {
        logger.info("Headers : ");
        MimeHeaders mimeHeaders = soapMessage.getMimeHeaders();
        Iterator eachHeader = mimeHeaders.getAllHeaders();
        while (eachHeader.hasNext()) {
            MimeHeader currentHeader = (MimeHeader) eachHeader.next();
            logger.info(currentHeader.getName()+" = "+currentHeader.getValue());
        }
        logger.info("Body : ");
        final StringWriter sw = new StringWriter();
        TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSOAPPart().getContent(), new StreamResult(sw));
        logger.info(sw.toString());
    }

    @Override
    public String getResponseAsString() throws Exception {
        SOAPMessage soapMessage = (SOAPMessage) this.httpResponse;
        final StringWriter sw = new StringWriter();
        TransformerFactory.newInstance().newTransformer().transform(soapMessage.getSOAPPart().getContent(), new StreamResult(sw));
        return sw.toString();
    }

    public SOAPBody getResponseAsSoapBody() throws Exception {
        SOAPMessage soapMessage = (SOAPMessage) this.httpResponse;
        return soapMessage.getSOAPBody();
    }

    public String getFaultCode() throws SOAPException {
        SOAPMessage soapMessage = (SOAPMessage) this.httpResponse;
        return soapMessage.getSOAPPart().getEnvelope().getBody().getFault().getFaultCode();
    }

}
