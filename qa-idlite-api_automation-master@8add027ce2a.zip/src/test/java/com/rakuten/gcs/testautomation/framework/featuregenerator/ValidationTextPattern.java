package com.rakuten.gcs.testautomation.framework.featuregenerator;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.rakuten.gcs.testautomation.framework.web.PageObjectBase;

public class ValidationTextPattern extends FeaturePetternBase {
    final static String VALIDATION_TEXT_PATTERN = "src/test/resources/com/rakuten/gcs/testautomation/viewpoint/validation_text.pattern";
    final static String VALIDATION_FEATURE_FILE_SUFFIX = "-text_validation.feature";

    public ValidationTextPattern() throws Exception {
        super(VALIDATION_TEXT_PATTERN, VALIDATION_FEATURE_FILE_SUFFIX);
    }

    public ValidationTextPattern(String featureFile) throws Exception {
        super(featureFile, VALIDATION_FEATURE_FILE_SUFFIX);
    }

    public ValidationTextPattern(String text_pattern, String file_suffix) throws Exception {
        super(text_pattern, file_suffix);
    }

    @Override
    protected void writeExamplesPart(PrintWriter writer, PageObjectBase pageObject) {
        int testID = 1;
        writer.println(examplePhrase);
        writer.println(examplesHeader);
        for (String inputElement : pageObject.getInputElementNameList()) {
            for (String example : examples) {
                String testIDStr = String.format("testID-%03d", testID);
                String exampleWithTestID = example.replace("$testid", testIDStr);
                //System.out.println("    exampleWithTestID=" + exampleWithTestID );
                //System.out.println("    inputElement" + inputElement);
                writer.println(exampleWithTestID.replace("$InputElement", inputElement));
                testID++;
            }
        }
    }

    public void writeAExampleWithExpectations(String testID, PageObjectBase pageObject, String outputElement, String message) throws IOException {
        BufferedWriter writer = getAppendableWriterThenSetIt(pageObject, WITH_EXPECTATION_FEATURE_FILE_PREFIX);

        String example = null;
        //System.out.println("testID="+testID);
        for (String str : examples) {
            //System.out.println("str=" + str);
            if (str.contains(testID)) {
                example = str;
                break;
            }
        }

        String exampleWithOutputElement = example.replace(PageObjectBase.pleaseInputMeOutputElementID, outputElement);
        String exampleWithOutputMessage = exampleWithOutputElement.replace(PageObjectBase.pleaseInputMeOutputMessageID, message);
        //System.out.println("exampleWithOutputMessage=" + exampleWithOutputMessage);
        writer.write(exampleWithOutputMessage);
        writer.newLine();
        writer.close();
    }

}
