package com.rakuten.gcs.testautomation.framework.operability;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoadBalancerHTTPMonitorSimulator implements Runnable {

    private final Thread workingThread;

    private final int sleepTime;
    private final URL url;
    private final Proxy proxy;

    final Log logger = LogFactory.getLog(LoadBalancerHTTPMonitorSimulator.class);

    private final String hostHeader;

    private volatile boolean stopRequested;

    private int sendRequest(URL url, Proxy proxy, String hostHeader) throws IOException {
        HttpURLConnection conn = null;

        try {
            logger.info(String.format("Sending request to %s with Host header %s", this.url.toString(), this.hostHeader));

            if (proxy == null) {
                conn = (HttpURLConnection) this.url.openConnection();
            } else {
                conn = (HttpURLConnection) this.url.openConnection(proxy);
            }
            conn.setRequestProperty("Host", this.hostHeader);

            conn.setConnectTimeout(15 * 1000);
            conn.setReadTimeout(60 * 1000);
            conn.setRequestMethod("GET");
            conn.connect();

            int lastStatus = conn.getResponseCode();
            logger.info(String.format("Response %d", lastStatus));
            return lastStatus;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

    }

    @Override
    public void run() {
        try {
            while (!stopRequested) {
                sendRequest(this.url, this.proxy, this.hostHeader);
                Thread.sleep(sleepTime);
            }

        } catch (Exception e) {
            Thread t = Thread.currentThread();
            t.getUncaughtExceptionHandler().uncaughtException(t, e);
        }
    }

    public void start() {
        this.workingThread.start();
    }

    public int stopAndReturnLastStatus() throws InterruptedException, IOException {
        this.stopRequested = true;
        this.workingThread.join();
        return sendRequest(this.url, this.proxy, this.hostHeader);
    }

    public LoadBalancerHTTPMonitorSimulator(URL url, Proxy proxy, String hostHeader) {
        // TODO Auto-generated constructor stub
        this.url = url;
        this.proxy = proxy;
        this.sleepTime = 15000;
        this.workingThread = new Thread(this);
        this.hostHeader = hostHeader;
        this.stopRequested = false;

    }

}
