package com.rakuten.gcs.testautomation.services.testrail;

import com.codepine.api.testrail.TestRail;
import com.codepine.api.testrail.model.Plan;
import com.codepine.api.testrail.model.Plan.Entry;
import com.mashape.unirest.http.Unirest;
import com.codepine.api.testrail.model.Run;
import com.codepine.api.testrail.model.Project;
import com.codepine.api.testrail.model.Result;
import com.codepine.api.testrail.model.ResultField;
import com.codepine.api.testrail.model.Section;
import com.rakuten.gcs.testautomation.services.IDLiteAPIs.runtest.IDLiteAPIs_RunTest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpHost;

public class TestRailIntegrationClient {

	
	
	private static TestRailIntegrationClient myself = new TestRailIntegrationClient();

    //Projects
    private static final int AUTOMATION_PROJECT_ID = 34;


    //Test Case Status IDs
    private static final int TEST_FAILED_STATUS_ID = 5;
    private static final int TEST_PASSED_STATUS_ID = 1;

    //Test Rail Authorization
    private static final String TEST_RAIL_USERNAME = "sarathkuma.rajendran@rakuten.com";
    private static final String TEST_RAIL_PASSWORD = "3!Xlsiorss";

    TestRail.Cases cases;
    TestRail testRail;
    //Plan plan;
    Project project;
    TestRail.Suites suites;
    Section sections;
    Run genericTestRun;

    List<ResultField> customResultFields;
    
    	public static Integer run;

    private TestRailIntegrationClient() {
    	
        this.testRail = TestRail.builder("https://gcsd.testrail.net", TEST_RAIL_USERNAME, TEST_RAIL_PASSWORD).applicationName("Rakuten QA").build();
        this.project = testRail.projects().get(AUTOMATION_PROJECT_ID).execute();
        this.suites = testRail.suites();
        this.cases = testRail.cases();
        
      //   run = Integer.parseInt(IDLiteAPIs_RunTest.runid.toString()); 
        genericTestRun = new Run();
        this.genericTestRun = testRail.runs().get(run).execute();
        
    }
    

    public static TestRailIntegrationClient getInstance() {
    	
        if (myself == null) {
            myself = new TestRailIntegrationClient();
        }

        return myself;
        
    }

    
    
    private void addResultToRun(String testCaseId, boolean passed, Run run) {  
    	
    	Integer caseId = Integer.parseInt(testCaseId.toString()); 
        if (passed) {
            List<ResultField> customResultFields = testRail.resultFields().list().execute();

            testRail.results().addForCase(run.getId(), caseId, new Result().setStatusId(TEST_PASSED_STATUS_ID), customResultFields).execute();
        } else {
            List<ResultField> customResultFields = testRail.resultFields().list().execute();
            testRail.results().addForCase(run.getId(), caseId, new Result().setStatusId(TEST_FAILED_STATUS_ID), customResultFields).execute();
        } 
       
    }
    
    

    public void addResultToSuite(String suite, String testCaseId, boolean passed) {

        switch (suite) {
            case "Master": 
                addResultToRun(testCaseId, passed, genericTestRun);
                break;
                default: {
                System.out.println("Suite " + suite + " not recognised within Test Rail");
            }
        }
    }

    
    
    public void finishRun() {
       
        testRail.runs().close(genericTestRun.getId()).execute();
        testRail.projects().update(project.setCompleted(true)).execute();
    }
    
}
