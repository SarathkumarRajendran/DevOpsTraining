package com.rakuten.gcs.testautomation.services.IDLiteAPIs.utils;

import net.sf.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class JsonUtils {
    public static String loadJsonFromResource(String path, String name) {

        String fullFileName = path;
        File file = new File(fullFileName);
        Scanner scanner = null;
        StringBuilder buffer = new StringBuilder();
        try {
            scanner = new Scanner(file, "utf-8");
            while (scanner.hasNextLine()) {
                buffer.append(scanner.nextLine());
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block  
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
        JSONObject jsonObject = JSONObject.fromObject(buffer.toString());
        JSONObject jsonGetLoadData = (JSONObject) jsonObject.get(name);

        return jsonGetLoadData.toString();
    }
}
