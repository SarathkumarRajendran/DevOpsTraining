package com.rakuten.gcs.testautomation.framework.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;

public class SnapshotUtils {

    final static Log logger = LogFactory.getLog(SnapshotUtils.class);
    final static String platform = System.getenv("SAUCELABS_PLATFORM_NAME");

    public static void makeSnapshotDirectory(Scenario scenario) throws IOException {

        String relativePathStr = getRelativePathString(scenario);
        Path relativePath = Paths.get(relativePathStr);
        if (Files.exists(relativePath, LinkOption.NOFOLLOW_LINKS)) {
            logger.info("Snapshot directory '" + relativePath + "' is existing, so skip to make directory");
        }
        logger.info("Create snapshot directory '" + relativePath);
        Files.createDirectories(relativePath);
    }

    public static void takeSnapshot(WebDriver driver, Scenario scenario, String pageTitle, String action) throws IOException {

        String filename = String.format(getRelativePathString(scenario) + "/%s-%s-%s.jpg", System.currentTimeMillis(), pageTitle, action);
        if (!"Android".equals(platform)) {
            logger.info("Save snapshot file: '" + filename);
            File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(file, new File(filename));
        } else {
            logger.info("Android can not take screen shots!");
        }

    }

    public static String getRelativePathString(Scenario scenario) {
        String scenarioName = scenario.getName().replaceAll("\"", "").replace(" ", "_");
        String relativePath = String.format("target/snapshot/%s/", scenarioName);
        return relativePath;
    }

    public static void removeSnapshotDirectoryIfTestPassed(Scenario scenario) throws IOException {

        String relativePathStr = getRelativePathString(scenario);
        Path relativePath = Paths.get(relativePathStr);

        if (scenario.isFailed()) {
            logger.info("Scenario failed so keep snapshot");
            return;
        } else if (!Files.exists(relativePath, LinkOption.NOFOLLOW_LINKS)) {
            logger.error("Snapshot directory '" + relativePath + "' is not existing, so skip to delete directory");
            return;
        }
        logger.info("Scenario passed so delete snapshot directory '" + relativePath);
        deleteDirectory(relativePathStr);

    }

    private static void deleteDirectory(String pathStr) {
        File dir = new File(pathStr);
        File[] files = dir.listFiles();
        if (files != null) { //some JVMs return null for empty dirs
            for (File f : files) {
                if (f.isDirectory()) {
                    deleteDirectory(f.getAbsolutePath());
                } else {
                    f.delete();
                }
            }
        }
        dir.delete();
    }

}