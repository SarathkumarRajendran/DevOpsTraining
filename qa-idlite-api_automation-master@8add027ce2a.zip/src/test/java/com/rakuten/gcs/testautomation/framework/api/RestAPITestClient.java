package com.rakuten.gcs.testautomation.framework.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.client.urlconnection.HttpURLConnectionFactory;
import com.sun.jersey.client.urlconnection.URLConnectionClientHandler;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class RestAPITestClient {

    public class ConnectionFactory implements HttpURLConnectionFactory {

        String proxyHost;
        int proxyPort;
        Proxy proxy;

        public ConnectionFactory(String proxyHost, int proxyPort) {
            this.proxyHost = proxyHost;
            this.proxyPort = proxyPort;
        }

        private void initializeProxy() {
            proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
        }

        @Override
        public HttpURLConnection getHttpURLConnection(URL url) throws IOException {
            initializeProxy();
            if (proxyHost.equals("noproxy")) {
                return (HttpURLConnection) url.openConnection();
            } else {
                return (HttpURLConnection) url.openConnection(proxy);
            }
        }

    }

    final Log logger = LogFactory.getLog(RestAPITestClient.class);
    Client client;
    Map<String, String> parameters;
    int responseHttpStatus;
    String responseBodyStr;

    public RestAPITestClient(String proxyHost, int proxyPort) {
        URLConnectionClientHandler ch = new URLConnectionClientHandler(new ConnectionFactory(proxyHost, proxyPort));
        client = new Client(ch);

        parameters = new HashMap<String, String>();
    }

    public void addBasicAuthFilter(String account, String password) {
        client.addFilter(new HTTPBasicAuthFilter(account, password));
    }

    public void init() {
        parameters.clear();
        responseHttpStatus = -1;
        responseBodyStr = null;
    }

    public void putParameter(String name, String value) {
        parameters.put(name, value);
    }

    private void setResponseValuesforCharSet(ClientResponse response) {
        responseHttpStatus = response.getStatus();
        InputStream is = response.getEntityInputStream();
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "EUC-JP"));
            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        responseBodyStr = sb.toString();
        logger.info("Returned response: status is '<" + response.getStatus() + ">'");
        logger.info("Returned response: body is '<" + responseBodyStr + ">'");
    }

    private void setResponseValues(ClientResponse response) {
        responseHttpStatus = response.getStatus();
        InputStream is = response.getEntityInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = "";

        try {
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        responseBodyStr = sb.toString();

        logger.info("Returned response: status is '<" + response.getStatus() + ">'");
        logger.info("Returned response: body is '<" + responseBodyStr + ">'");
    }

    public void requestPostToURLWithParameters(String baseURL, MediaType type) throws UnsupportedEncodingException {

        //Fix Me!: this is just sample code: https://blogs.oracle.com/enterprisetechtips/entry/consuming_restful_web_services_with
        MultivaluedMap<String, String> formData = new MultivaluedMapImpl();
        for (Map.Entry<String, String> parameter : parameters.entrySet()) {
            logger.debug("parameterName:" + parameter.getKey() + "   " + parameter.getValue());
            formData.add(parameter.getKey(), parameter.getValue());
        }
        // print parameter name and value of post formData
        for (Map.Entry<String, List<String>> parameter : formData.entrySet()) {
            logger.info("requestEntity.parameterName:" + parameter.getKey() + " = " + parameter.getValue().get(0));
        }
        WebResource resource = client.resource(baseURL);
        ClientResponse response = resource.type(type).post(ClientResponse.class, formData);
        setResponseValues(response);
    }

    public void httpRequestPostToURLWithParameters(String baseURL, MediaType type) throws UnsupportedEncodingException {
        String newUrl = null;
        BufferedReader in;
        // Fix Me!: this is just sample code:
        // https://blogs.oracle.com/enterprisetechtips/entry/consuming_restful_web_services_with
        MultivaluedMap<String, String> formData = new MultivaluedMapImpl();
        for (Map.Entry<String, String> parameter : parameters.entrySet()) {
            logger.debug("parameterName:" + parameter.getKey() + "   " + parameter.getValue());
            formData.add(parameter.getKey(), parameter.getValue());
        }
        // print parameter name and value of post formData
        for (Map.Entry<String, List<String>> parameter : formData.entrySet()) {
            logger.info("requestEntity.parameterName:" + parameter.getKey() + " = " + parameter.getValue().get(0));

            if ("easy_id".equals(parameter.getKey())) {
                newUrl = baseURL + "?easy_id=" + parameter.getValue().get(0);
            } else {
                newUrl = baseURL;
            }
            System.out.println("The parameter is " + parameter.getKey() + " = " + parameter.getValue().get(0));
        }

        try {
            WebResource resource = client.resource(newUrl);

            System.out.println("The URL is " + resource.getURI());

            ClientResponse response = resource.accept("application/xml").post(ClientResponse.class);
//            int status = response.getStatus();

            String data = response.getEntity(String.class);
//            CoreCommonSteps.resultMap.put("response", data);
        } catch (Exception e) {
            System.out.println("The URL is " + newUrl);

            newUrl = newUrl.replaceAll("　", "%81%40");
            newUrl = newUrl.replaceAll(" ", "%20");

            try {
                URL realUrl = new URL(newUrl);
                System.out.println(realUrl.toString());
                HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
                connection.setRequestProperty("accept", "*/*");
                connection.setRequestProperty("connection", "Keep-Alive");
                connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
                ((HttpURLConnection) connection).setRequestMethod("POST");
                connection.connect();
                logger.info("The responseCode is " + connection.getResponseCode());
                if (connection.getResponseCode() == 200) {
                    in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                } else {
                    in = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                }
                String line;
                String result = "";
//                while ((line = in.readLine()) != null) {
//                    result += line;
//                }

//                CoreCommonSteps.resultMap.put("response", result);
            } catch (MalformedURLException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

        }
    }

    private String urlEncode(String str, String enc) {
        String urlEncode = "";
        StringBuffer result = new StringBuffer();

        try {
            urlEncode = URLEncoder.encode(str, enc);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e.toString());
        }

        // 半角スペースは「%20」へ置換する
        for (char c : urlEncode.toCharArray()) {
            switch (c) {
                case '+':
                    result.append("%20");
                    break;
                default:
                    result.append(c);
                    break;
            }
        }

        return result.toString();
    }

    public void requestGetToURLWithParameters(String baseURL, MediaType type) throws UnsupportedEncodingException {
        UriBuilder builder = UriBuilder.fromPath(baseURL);
        for (Map.Entry<String, String> parameter : parameters.entrySet()) {
            logger.debug("parameterName:" + parameter.getKey() + "   " + parameter.getValue());
            builder.queryParam(parameter.getKey(), parameter.getValue());
        }
        String url = builder.build().toString();
        logger.info("Requesting to '<" + url + ">'");
        WebResource resource = client.resource(url);
        ClientResponse response = resource.accept(type).get(ClientResponse.class);

        setResponseValues(response);
    }

    public void requestGetToURLWithParametersSetChar(String baseURL, MediaType type) throws UnsupportedEncodingException {
        UriBuilder builder = UriBuilder.fromPath(baseURL);
        for (Map.Entry<String, String> parameter : parameters.entrySet()) {
            logger.debug("parameterName:" + parameter.getKey() + "   " + parameter.getValue());
            builder.queryParam(parameter.getKey(), parameter.getValue());
        }
        String url = builder.build().toString();
        logger.info("Requesting to '<" + url + ">'");
        WebResource resource = client.resource(url);
        ClientResponse response = resource.accept(type).get(ClientResponse.class);

        setResponseValuesforCharSet(response);
    }

    public void httpRequestGetToURLWithParametersSetChar(String baseURL, MediaType type) throws UnsupportedEncodingException {
        UriBuilder builder = UriBuilder.fromPath(baseURL);
        String newUrl = null;
        for (Map.Entry<String, String> parameter : parameters.entrySet()) {
            logger.debug("parameterName:" + parameter.getKey() + "   " + parameter.getValue());
            builder.queryParam(parameter.getKey(), parameter.getValue());
            if ("easy_id".equals(parameter.getKey())) {
                newUrl = baseURL + "?easy_id=" + parameter.getValue();
            } else {
                newUrl = baseURL;
            }
            System.out.println("The parameter is " + parameter.getKey() + " = " + parameter.getValue());
        }
        WebResource resource = client.resource(newUrl);
        System.out.println("The URL is " + resource.getURI());
        ClientResponse response = resource.accept("application/xml").get(ClientResponse.class);
//        int status = response.getStatus();
        String data = response.getEntity(String.class);
//        CoreCommonSteps.resultMap.put("response", data);
    }

    public void requestGetToURL(String url, MediaType type) {
        logger.info("Requesting to '<" + url + ">'");
        WebResource resource = client.resource(url);
        ClientResponse response = resource.accept(type).get(ClientResponse.class);

        setResponseValues(response);
    }

    public String getResponseString() throws Exception {
        if (responseBodyStr == null) {
            throw new Exception("response is null, propably you did not request yet.");
        }
        return responseBodyStr;
    }

    public int getHttpStatus() throws Exception {
        if (responseHttpStatus == -1) {
            throw new Exception("response is null, propably you did not request yet.");
        }
        return responseHttpStatus;
    }

    public WebResource resource(String newUrl) {
        // TODO Auto-generated method stub
        return null;
    }
}
