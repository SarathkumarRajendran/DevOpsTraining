package com.rakuten.gcs.testautomation.framework.web;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
//import sun.security.krb5.internal.crypto.Des;

import java.util.Arrays;

/**
 * Created by aldo.suwandi on 2015/07/22.
 */
public class CapabilityBuilder {

    public static final String[] Browser = new String[] { "firefox", "chrome", "opera", "safari", "internet explorer" };

    public static final String[] Platform = new String[] { "iOS", "Android" };

    public static final String[] OS = new String[] { "Windows 10", "Windows 8.1", "Windows 8", "Windows 7", "Windows XP", "" + "Linux", "OS X 10.11", "OS X 10.10", "OS X 10.9", "OS X 10.8", "OS X 10.6" };

    private static DesiredCapabilities capabilities;

    public static DesiredCapabilities generate(String os, String platform, String browser, String browserLocale, String version, String scenarioName) throws Exception {
        /**
         * iOS and Android handler
         */
        if (platform != null && !platform.trim().isEmpty()) {
            if (arrayCheck(Platform, platform)) {
                DeviceOption deviceOption = new DeviceOption(platform, version, os, browserLocale);
                capabilities = deviceOption.getCapabilities();
            }
            /**
             * PC and Mac handler
             */
        } else {
            if (arrayCheck(Browser, browser) && arrayCheck(OS, os)) {
                BrowserOption browserOption = new BrowserOption(browser, os, browserLocale);
                capabilities = browserOption.getCapabilities();
                capabilities.setCapability(CapabilityType.BROWSER_NAME, browser);
                capabilities.setCapability(CapabilityType.VERSION, version);
                capabilities.setCapability(CapabilityType.PLATFORM, os);
                capabilities.setCapability("timeZone", "Tokyo");
                if (os.contains("OS X")) {
                    capabilities.setCapability("screenResolution", "1600x1200");
                }
            } else {
                throw new Exception("Unsupported Browser or OS");
            }
        }
        String platformString = String.format("OS:%s broswer:%s version:%s Scenario:%s", os, browser, version, scenarioName);
        capabilities.setCapability("name", "Scenario Test - " + platformString);
        return capabilities;
    }

    private static boolean arrayCheck(String[] array, String value) {
        for (String element : array) {
            if (element.toLowerCase().equals(value.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

}
