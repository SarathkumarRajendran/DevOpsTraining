package com.rakuten.gcs.testautomation.framework.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;

public class CsvUtils {

    final static Log logger = LogFactory.getLog(CsvUtils.class);
    final static String platform = System.getenv("SAUCELABS_PLATFORM_NAME");

    public static String makeCsvDirectory(Scenario scenario) throws IOException {

        String relativePathStr = getRelativePathString(scenario);
        String csvName = "AddressBook";
        String csvDirectory = "";

        relativePathStr = String.format("target/csv/%s/", csvName);

        Path relativePath = Paths.get(relativePathStr);

        if (Files.exists(relativePath, LinkOption.NOFOLLOW_LINKS)) {
            logger.info("Csv directory '" + relativePath + "' is existing, so skip to make directory");
        }

        Files.createDirectories(relativePath);
        csvDirectory = relativePath.toString();
        logger.info("Create csv directory csvDirectory'" + csvDirectory);

        return csvDirectory;
    }

    public static String getRelativePathString(Scenario scenario) {
        String scenarioName = scenario.getName().replaceAll("\"", "").replace(" ", "_");
        String relativePath = String.format("target/snapshot/%s/", scenarioName);
        return relativePath;
    }
}