package com.rakuten.gcs.testautomation.framework.operability.steps;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;

import com.rakuten.gcs.testautomation.framework.operability.LoadBalancerHTTPMonitorSimulator;
import com.rakuten.gcs.testautomation.framework.operability.SharedOperabilityTestData;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.soap.SOAPException;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OperabilitySteps {
    final Log logger = LogFactory.getLog(OperabilitySteps.class);

    private final SharedOperabilityTestData testData;

    private String defaultNode;

    private void setDefaultNode(String defaultNode) {
        if (defaultNode == null) {
            throw new IllegalArgumentException("defaultNode should not be null");
        }

        if (this.defaultNode != null) {
            throw new IllegalStateException("Re-assignment of Default Node is not supported");
        }

        this.defaultNode = defaultNode;
    }

    private String getDefaultNode() {
        return defaultNode;
    }

    public OperabilitySteps(SharedOperabilityTestData testData) {

        this.testData = testData;
    }

    @Before
    public void setUp(Scenario scenario) throws Exception {

        if (System.getProperty("sun.net.http.allowRestrictedHeaders") == null) {
            System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
        } else {
            throw new Exception("System property sun.net.http.allowRestrictedHeaders is already set. Please make sure to unset it before running this test scneario");
        }

    }

    @After
    public void teraDown(Scenario scenario) throws MalformedURLException, SOAPException {

        System.clearProperty("sun.net.http.allowRestrictedHeaders");

    }

    @Given("^an OPS user start working on node \"(.*?)\" as a default from now on in Given clause$")
    public void an_OPS_user_start_working_on_node_as_a_default_from_now_on_in_Given_clause(String arg1) throws Throwable {
        this.setDefaultNode(arg1);
    }

    @Given("^vhost \"(.*?)\" is periodically monitored by the load balancer$")
    public void vhost_is_periodically_monitored_by_the_load_balancer(String arg1) throws Throwable {
        vhost_on_server_is_periodically_monitored_by_the_load_balancer(arg1, this.getDefaultNode());
    }

    @Given("^vhost \"(.*?)\" on node \"(.*?)\" is periodically monitored by the load balancer$")
    public void vhost_on_server_is_periodically_monitored_by_the_load_balancer(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String baseUrl = this.testData.getNodeObject(arg2).getVirtualHostBaseUrl(arg1);

        LoadBalancerHTTPMonitorSimulator simulator = new LoadBalancerHTTPMonitorSimulator(new URL(String.format("%swwwcheck.html", baseUrl)), this.testData.getProxy(), arg1);
        this.testData.putMonitorSimulators(String.format("%s%s", arg1, arg2), simulator);
        simulator.start();

    }

    //    @Given("^vhost \"(.*?)\" is S-out'ed$")
    //    public void vhost_is_S_out_ed(String arg1) throws Throwable {
    //        vhost_on_is_S_out_ed(arg1, this.testData.getDefaultNode());
    //    }
    //
    //    @Given("^vhost \"(.*?)\" on \"(.*?)\" is S-out'ed$")
    //    public void vhost_on_is_S_out_ed(String arg1, String arg2) throws Throwable {
    //
    //        HashMap<String, String> s = new HashMap<String, String>();
    //        s.put("vhostname", arg1);
    //        int returnValue = this.testData.getNodeObject(arg2).executeOneParameterizedCommandAndGetValue("RmWwwcheck", s);
    //        Assert.assertEquals(0, returnValue);
    //        returnValue = this.testData.getNodeObject(arg2).executeOneParameterizedCommandAndGetValue("TouchWwwcheckOrg", s);
    //        Assert.assertEquals(0, returnValue);
    //
    //    }

    @Then("^the load balancer considers vhost \"(.*?)\" is S-in'ed$")
    public void the_load_balancer_considers_vhost_is_S_in_ed(String arg1) throws Throwable {
        the_load_balancer_considers_vhost_on_server_is_S_in_ed(arg1, this.getDefaultNode());
    }

    @Then("^the load balancer considers vhost \"(.*?)\" on node \"(.*?)\" is S-in'ed$")
    public void the_load_balancer_considers_vhost_on_server_is_S_in_ed(String arg1, String arg2) throws Throwable {

        Assert.assertEquals(200, this.testData.getMonitorSimulator(String.format("%s%s", arg1, arg2)).stopAndReturnLastStatus());

    }

    //    @Given("^vhost \"(.*?)\" is S-in'ed$")
    //    public void vhost_is_S_in_ed(String arg1) throws Throwable {
    //        vhost_on_is_S_in_ed(arg1, this.testData.getDefaultNode());
    //    }
    //
    //    @Given("^vhost \"(.*?)\" on \"(.*?)\" is S-in'ed$")
    //    public void vhost_on_is_S_in_ed(String arg1, String arg2) throws Throwable {
    //        HashMap<String, String> s = new HashMap<String, String>();
    //        s.put("vhostname", arg1);
    //        int returnValue = this.testData.getNodeObject(arg2).executeOneParameterizedCommandAndGetValue("TouchWwwcheck", s);
    //        Assert.assertEquals(0, returnValue);
    //        returnValue = this.testData.getNodeObject(arg2).executeOneParameterizedCommandAndGetValue("RmWwwcheckOrg", s);
    //        Assert.assertEquals(0, returnValue);
    //    }

    @Then("^the load balancer considers vhost \"(.*?)\" is S-out'ed$")
    public void the_load_balancer_considers_vhost_is_S_out_ed(String arg1) throws Throwable {
        this.the_load_balancer_considers_vhost_on_server_is_S_out_ed(arg1, this.getDefaultNode());
    }

    @Then("^the load balancer considers vhost \"(.*?)\" on node \"(.*?)\" is S-out'ed$")
    public void the_load_balancer_considers_vhost_on_server_is_S_out_ed(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertEquals(404, this.testData.getMonitorSimulator(String.format("%s%s", arg1, arg2)).stopAndReturnLastStatus());
    }

    //    @When("^an OPS user logs into the node and runs \"(.*?)\" with \"(.*?)\" milliseconds time out$")
    //    public void an_OPS_user_logs_into_the_node_and_runs_with_milliseconds_time_out(String arg1, String arg2) throws Throwable {
    //        an_OPS_user_logs_into_and_runs_with_milliseconds_time_out(this.testData.getDefaultNode(), arg1, arg2);
    //    }
    //
    //    @When("^an OPS user logs into \"(.*?)\" and runs \"(.*?)\" with \"(.*?)\" milliseconds time out$")
    //    public void an_OPS_user_logs_into_and_runs_with_milliseconds_time_out(String arg1, String arg2, String arg3) throws Throwable {
    //        this.testData.getNodeObject(arg1).executeOneCommandAndGetReturnValue(arg2);
    //        if (this.testData.getNodeObject(arg1).getLastExecutionTime() >= Integer.parseInt(arg3)) {
    //            throw new Exception("Exceeded timeout");
    //        }
    //    }

    @When("^an OPS user logs into the node and runs \"(.*?)\"$")
    public void an_OPS_user_logs_into_the_node_and_runs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        this.testData.getNodeObject(this.getDefaultNode()).executeOneCommandAndGetReturnValue(arg1);

    }

    @Then("^the last command on the node finishes in \"(.*?)\" milliseconds$")
    public void the_last_command_on_the_node_finishes_in_milliseconds(String arg1) throws Throwable {
        Assert.assertTrue(this.testData.getNodeObject(this.getDefaultNode()).getLastExecutionTime() <= Integer.parseInt(arg1));
    }

    @Then("^the last command on the node returns (\\d+) as a return code$")
    public void the_last_command_on_the_node_returns_as_a_return_code(int arg1) throws Throwable {
        returns_as_a_return_code(this.getDefaultNode(), arg1);
    }

    @Then("^the last command on \"(.*?)\" returns (\\d+) as a return code$")
    public void returns_as_a_return_code(String arg1, int arg2) throws Throwable {
        Assert.assertEquals(arg2, this.testData.getNodeObject(arg1).getLastSuccessfulStatus());
    }

}
