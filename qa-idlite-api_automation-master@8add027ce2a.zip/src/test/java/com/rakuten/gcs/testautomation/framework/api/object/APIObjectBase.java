package com.rakuten.gcs.testautomation.framework.api.object;

/**
 * Created by aldosuwandi on 12/6/16.
 */
public abstract class APIObjectBase {

    protected String apiName;
    protected Object httpResponse;

    public void setHttpResponse(Object httpResponse) {
        this.httpResponse = httpResponse;
    }

    public abstract String getResponseAsString() throws Exception;
}
