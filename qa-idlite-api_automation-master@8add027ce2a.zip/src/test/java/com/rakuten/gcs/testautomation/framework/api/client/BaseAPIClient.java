package com.rakuten.gcs.testautomation.framework.api.client;

import com.rakuten.gcs.testautomation.framework.api.object.APIObjectBase;
import org.apache.http.HttpHost;

/**
 * Created by aldosuwandi on 12/6/16.
 */
public abstract class BaseAPIClient {
    protected String baseURI;
    protected HttpHost proxy;

    public BaseAPIClient() {
    }

    public BaseAPIClient(String baseURI, String proxyHost, int proxyPort) {
        this.baseURI = baseURI;
        this.proxy = new HttpHost(proxyHost, proxyPort);
    }

    public BaseAPIClient(String baseURI) {
        this.baseURI = baseURI;
    }

    public String getBaseURI() {
        return baseURI;
    }

    public void setBaseURI(String baseURI) {
        this.baseURI = baseURI;
    }

    public HttpHost getProxy() {
        return proxy;
    }

    public void setProxy(HttpHost proxy) {
        this.proxy = proxy;
    }

    public abstract void sendRequest(APIObjectBase apiObjectBase) throws Exception;

}
