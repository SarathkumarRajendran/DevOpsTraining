package com.rakuten.gcs.testautomation.framework.web;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;

public class PageElement {

    /**
     * Element Type for UNSPECIFIC type
     */
    public static final int UN_SPECIFIC_TYPE = 0;

    /**
     * Element Type for <a href="http://www.google.co.jp">Link</a>
     */
    public static final int A = 1;

    /**
     * Element Type for <b>Bold</b>
     */
    public static final int B = 2;

    /**
     * Element Type for <button type="button">A Button</button>
     */
    public static final int BUTTON = 3;

    /**
     * Element Type for <div style="color:#008886"> The div </div>
     */
    public static final int DIV = 4;

    /**
     * Element Type for <img src="/i/eg_tulip.jpg" alt="Flower" />
     */
    public static final int IMG = 5;

    /**
     * Element Type for <input type="button" value="A Button" onclick="" />
     */
    public static final int INPUT_BUTTON = 6;

    /**
     * Element Type for <input type="checkbox" name="vehicle" value="Bike" />
     */
    public static final int INPUT_CHECKBOX = 7;

    /**
     * Element Type for <input type="file" />
     */
    public static final int INPUT_FILE = 8;

    /**
     * Element Type for <input type="hidden" name="country" value="Norway" />
     */
    public static final int INPUT_HIDDEN = 9;

    /**
     * Element Type for <input type="image" src="submit.gif" alt="Submit" />
     */
    public static final int INPUT_IMAGE = 10;

    /**
     * Element Type for <input type="password" name="pwd" />
     */
    public static final int INPUT_PASSWORD = 11;

    /**
     * Element Type for <input type="radio" name="sex" value="male" />
     */
    public static final int INPUT_RADIO = 12;

    /**
     * Element Type for Radio Group
     * 
     * <pre>
     * <input type="radio" name="sex" value="male" /> Male
     * <input type="radio" name="sex" value="female" /> Female
     * </pre>
     */
    public static final int INPUT_RADIO_GROUP = 13;

    /**
     * Element Type for <input type="reset" />
     */
    public static final int INPUT_RESET = 14;

    /**
     * Element Type for <input type="submit" />
     */
    public static final int INPUT_SUBMIT = 15;

    /**
     * Element Type for <input type="text" name="email" />
     */
    public static final int INPUT_TEXT = 16;

    /**
     * Element Type for <label for="male">The Label</label>
     */
    public static final int LABEL = 17;

    /**
     * Element Type for
     * <li>list item</li>
     */
    public static final int LI = 18;

    /**
     * Element Type for
     * <ol>
     * <li>ordered</li>
     * <li>lists</li>
     * </ol>
     */
    public static final int OL = 19;

    /**
     * Element Type for
     * 
     * <pre>
     * <select>
     * <option value =""volvo"">Volvo</option>
     * <option value =""saab"">Saab</option>
     * </select>
     * </pre>
     */
    public static final int SELECT = 20;

    /**
     * Element Type for <span>some text.</span>
     */
    public static final int SPAN = 21;

    /**
     * Element Type for
     * <th>Table head</th>
     */
    public static final int TH = 22;

    /**
     * Element Type for
     * <td>Table data cell</td>
     */
    public static final int TD = 23;

    /**
     * Element Type for
     * <tr>
     * <td>Table row</td>
     * </tr>
     */
    public static final int TR = 24;

    /**
     * Element Type for <textarea rows="3" cols="20"> good morning! </textarea>"
     */
    public static final int TEXTAREA = 25;

    /**
     * Element Type for
     * <ul>
     * <li>unordered</li>
     * <li>lists</li>
     * </ul>
     */
    public static final int UL = 26;

    /**
     * Element Type for
     * <li>text</li>
     */
    public static final int TEL = 27;

    /**
     * State: "isSelected" when Check Box Or radio Button is selected
     */
    public static final String IS_SELECTED = "isSelected";

    /**
     * State: "isNotSelected" when Check Box Or radio Button is <strong>NOT</strong> selected
     */
    public static final String IS_NOT_SELECTED = "isNotSelected";

    /**
     * State: "isExist" for Is this element exist or not?
     */
    public static final String IS_EXIST = "isExist";

    /**
     * State: "isDisplayed" for Is this element displayed or not?
     */
    public static final String IS_DISPLAYED = "isDisplayed";

    /**
     * State: "isEnabled" for Is the element currently enabled or not?
     */
    public static final String IS_ENABLED = "isEnabled";

    /**
     * Attribute Name: "dimension"<br>
     * What is the width and height of the element<br>
     */
    public static final String DIMENSION = "dimension";

    /**
     * Attribute Name: "tagName"
     */
    public static final String TAG_NAME = "tagName";

    /**
     * Attribute Name: "text"
     */
    public static final String TEXT = "text";

    /**
     * Attribute Name: "color"
     */
    public static final String COLOR = "color";

    /**
     * Attribute Name: "background-color"
     */
    public static final String BACKGROUND_COLOR = "background-color";

    /**
     * Tag Name: "a"
     */
    private static final String TAG_A = "a";

    /**
     * Tag Name: "button"
     */
    private static final String TAG_BUTTON = "button";

    /**
     * Tag Name: "img"
     */
    private static final String TAG_IMG = "img";

    /**
     * Tag Name: "input"
     */
    private static final String TAG_INPUT = "input";

    /**
     * Tag Name: "select"
     */
    private static final String TAG_SELECT = "select";

    /**
     * Tag Name: "textarea"
     */
    private static final String TAG_TEXTAREA = "textarea";

    /**
     * Attribute Name: "type"
     */
    private static final String ATTR_TYPE = "type";

    /**
     * Attribute Name: "value"
     */
    private static final String ATTR_VALUE = "value";

    /**
     * Attribute Name: "src"
     */
    private static final String ATTR_SRC = "src";

    /**
     * Attribute Value: "button"
     */
    private static final String ATTR_VAL_BUTTON = "button";

    /**
     * Attribute Value: "checkbox"
     */
    private static final String ATTR_VAL_CHECKBOX = "checkbox";

    /**
     * Attribute Value: "file"
     */
    private static final String ATTR_VAL_FILE = "file";

    /**
     * Attribute Value: "hidden"
     */
    private static final String ATTR_VAL_HIDDEN = "hidden";

    /**
     * Attribute Value: "image"
     */
    private static final String ATTR_VAL_IMAGE = "image";

    /**
     * Attribute Value: "password"
     */
    private static final String ATTR_VAL_PASSWORD = "password";

    /**
     * Attribute Value: "radio"
     */
    private static final String ATTR_VAL_RADIO = "radio";

    /**
     * Attribute Value: "reset"
     */
    private static final String ATTR_VAL_RESET = "reset";

    /**
     * Attribute Value: "submit"
     */
    private static final String ATTR_VAL_SUBMIT = "submit";

    /**
     * Attribute Value: "text"
     */
    private static final String ATTR_VAL_TEXT = "text";

    /**
     * Attribute Value: "tel"
     */
    private static final String ATTR_VAL_TEL = "tel";

    /**
     * Message for NoSuchElementException
     */
    private static final String NO_SUCH_ELEMENT_MSG = "the Page Element is NOT exist.";

    /**
     * The instance for WebElement List
     */
    private List<WebElement> elementList = null;

    /**
     * The instance of WebElement
     */
    private WebElement element = null;

    /**
     * The Element Type default is UNSPECIFIC TYPE
     */
    private int type = UN_SPECIFIC_TYPE;

    /**
     * Constructs a newly {@code PageElement} object by the WebElement List and element Type.
     * 
     * @param elementList The Page Element List
     * @param type Element Type
     * @throws Exception When Element is NOT exist.
     */
    public PageElement(List<WebElement> elementList, Integer type) {
        this.elementList = elementList;

        if (elementList != null && elementList.size() > 0) {
            this.element = elementList.get(0);
        }

        this.type = type == null ? UN_SPECIFIC_TYPE : type;
    }

    /**
     * Constructs a newly {@code PageElement} object by the WebElement and element Type.
     * 
     * @param element The Page Element
     * @param type Element Type
     * @throws Exception When Element is NOT exist.
     */
    public PageElement(WebElement element, Integer type) {
        this.element = element;
        if (element != null) {
            this.elementList = new ArrayList<WebElement>();
            this.elementList.add(element);
        }

        this.type = type == null ? UN_SPECIFIC_TYPE : type;
    }

    /**
     * Get value of Default Attribute.<br>
     * If the type is set use it, otherwise get type by tag name and attribute.
     * 
     * @return
     * @throws NoSuchElementException When element is NOT exist.
     */
    public String getValueOfDefaultAttribute() throws NoSuchElementException {
        if (!this.isExist()) {
            throw new NoSuchElementException(NO_SUCH_ELEMENT_MSG);
        }

        if (this.type == UN_SPECIFIC_TYPE) {
            this.type = getTypeByTagNameAndAttribute();
        }

        return getValueOfDefaultAttribute(this.type);
    }

    /**
     * Get value of Default Attribute by element type
     * 
     * @param elementType element Type
     * @return value
     */
    public String getValueOfDefaultAttribute(int elementType) {
        if (!this.isExist()) {
            throw new NoSuchElementException(NO_SUCH_ELEMENT_MSG);
        }

        String result = "";

        switch (elementType) {

            case IMG:
            case INPUT_IMAGE:
                result = this.element.getAttribute(ATTR_SRC);
                break;

            case INPUT_BUTTON:
            case INPUT_FILE:
            case INPUT_HIDDEN:
            case INPUT_PASSWORD:
            case INPUT_RESET:
            case INPUT_SUBMIT:
            case INPUT_TEXT:
            case TEXTAREA:
                result = this.element.getAttribute(ATTR_VALUE);
                break;

            case INPUT_CHECKBOX:
            case INPUT_RADIO:
                if (this.element.isSelected()) {
                    result = IS_SELECTED;
                } else {
                    result = IS_NOT_SELECTED;
                }
                break;

            case SELECT:
                Select dropDown = new Select(this.element);
                result = dropDown.getFirstSelectedOption().getText();
                break;

            case INPUT_RADIO_GROUP:
                for (WebElement radioElement : this.elementList) {
                    if (radioElement.isSelected()) {
                        result = radioElement.getAttribute(ATTR_VALUE);
                        break;
                    }
                }
                break;

            default:
                result = this.element.getText();
        }

        return result;
    }

    /**
     * Get element type by tag name and attribute.
     * 
     * @return element type
     */
    private int getTypeByTagNameAndAttribute() {

        // default is UNSPECIFIC TYPE
        int elementType = UN_SPECIFIC_TYPE;

        String tagName = this.element.getTagName();
        String typeVal = this.element.getAttribute(ATTR_TYPE);

        // a
        if (TAG_A.equals(tagName)) {
            elementType = A;

            // button
        } else if (TAG_BUTTON.equals(tagName)) {
            elementType = BUTTON;

            // img
        } else if (TAG_IMG.equals(tagName)) {
            elementType = IMG;

            // input
        } else if (TAG_INPUT.equals(tagName)) {

            // input button
            if (ATTR_VAL_BUTTON.equals(typeVal)) {
                elementType = INPUT_BUTTON;

                // check box
            } else if (ATTR_VAL_CHECKBOX.equals(typeVal)) {
                elementType = INPUT_CHECKBOX;

                // file
            } else if (ATTR_VAL_FILE.equals(typeVal)) {
                elementType = INPUT_FILE;

                // hidden
            } else if (ATTR_VAL_HIDDEN.equals(typeVal)) {
                elementType = INPUT_HIDDEN;

                // image
            } else if (ATTR_VAL_IMAGE.equals(typeVal)) {
                elementType = INPUT_IMAGE;

                // password
            } else if (ATTR_VAL_PASSWORD.equals(typeVal)) {
                elementType = INPUT_PASSWORD;

                // radio
            } else if (ATTR_VAL_RADIO.equals(typeVal)) {
                // radio Group
                if (this.elementList.size() > 1) {
                    elementType = INPUT_RADIO_GROUP;

                    // radio Button
                } else {
                    elementType = INPUT_RADIO;
                }

                // reset
            } else if (ATTR_VAL_RESET.equals(typeVal)) {
                elementType = INPUT_RESET;

                // submit
            } else if (ATTR_VAL_SUBMIT.equals(typeVal)) {
                elementType = INPUT_SUBMIT;

                // text
            } else if (ATTR_VAL_TEXT.equals(typeVal)) {
                elementType = INPUT_TEXT;
                // tel
            } else if (ATTR_VAL_TEL.equals(typeVal)) {
                elementType = INPUT_TEXT;
            }

            // select
        } else if (TAG_SELECT.equals(tagName)) {
            elementType = SELECT;

            // textarea
        } else if (TAG_TEXTAREA.equals(tagName)) {
            elementType = TEXTAREA;
            //tel
        } else if (ATTR_VAL_TEL.equals(tagName)) {
            elementType = TEL;
        }

        return elementType;
    }

    /**
     * Input to the element.<br>
     * If the type is set use it, otherwise get type by tag name and attribute.
     * 
     * @param value The value for input
     * @return The Value Of Default Attribute after input.
     * @throws Exception
     */
    public String inputToElementBaseOnType(String value) throws Exception {
        if (!this.isExist()) {
            throw new NoSuchElementException(NO_SUCH_ELEMENT_MSG);
        }

        if (this.type == UN_SPECIFIC_TYPE) {
            this.type = getTypeByTagNameAndAttribute();
        }

        return inputToElementBaseOnType(value, this.type);
    }

    /**
     * Input to element on the basis of element's type
     * 
     * @param value The Value for input
     * @param elementType Element's type
     * @return The Value Of Default Attribute after input.
     * @throws Exception When the input is NOT permission.
     */
    public String inputToElementBaseOnType(String value, int elementType) throws Exception {
        if (!this.isExist()) {
            throw new NoSuchElementException(NO_SUCH_ELEMENT_MSG);
        }
        switch (elementType) {

            // case INPUT_FILE:
            case INPUT_PASSWORD:
            case INPUT_TEXT:
            case TEXTAREA:
            case TEL:
                this.element.clear();
                this.element.sendKeys(value);
                break;

            case INPUT_CHECKBOX:
                // Want to check it
                if (IS_SELECTED.equals(value)) {
                    // When it is NOT checked
                    if (!this.element.isSelected()) {
                        this.element.click();
                    }

                    // Want to unCheck it
                } else if (IS_NOT_SELECTED.equals(value)) {
                    // When it is checked
                    if (this.element.isSelected()) {
                        this.element.click();
                    }

                } else {
                    throw new Exception("The input value:" + value + " for checkbox is NOT permission.");
                }
                break;

            case INPUT_RADIO:
                // Want to check it
                if (IS_SELECTED.equals(value)) {
                    // When it is NOT checked
                    if (!this.element.isSelected()) {
                        this.element.click();
                    }

                } else {
                    throw new Exception("The input value:" + value + " for radio Button is NOT permission.");
                }
                break;

            case SELECT:
                Select dropDown = new Select(this.element);
                dropDown.selectByVisibleText(value);
                break;

            case INPUT_RADIO_GROUP:
                for (WebElement radioElement : this.elementList) {
                    if (radioElement.getAttribute(ATTR_VALUE).equals(value)) {
                        radioElement.click();
                        break;
                    }
                }
                break;

            default:
                throw new Exception("The input to this Element is NOT permission.");
        }

        return this.getValueOfDefaultAttribute(this.type);
    }

    /**
     * Get the value of a the given state or attribute of the element.
     * 
     * @param name The name of the state or attribute.
     * @return The state/attribute/property's current value or null if the value is not set.
     */
    public String getStateOrAttributeValue(String name) {

        if (!this.isExist() && !IS_EXIST.equals(name)) {
            throw new NoSuchElementException(NO_SUCH_ELEMENT_MSG);
        }

        String result = null;

        // isExist
        if (IS_EXIST.equals(name)) {
            result = String.valueOf(this.isExist());

            // isDisplayed
        } else if (IS_DISPLAYED.equals(name)) {
            boolean isDisplayed = this.element.isDisplayed();
            result = String.valueOf(isDisplayed);

            // isEnabled
        } else if (IS_ENABLED.equals(name)) {
            boolean isEnabled = this.element.isEnabled();
            result = String.valueOf(isEnabled);

            // isSelected
        } else if (IS_SELECTED.equals(name)) {
            boolean isSelected = this.element.isSelected();
            result = String.valueOf(isSelected);

            // dimension
            // The format of result is (%d, %d)
        } else if (DIMENSION.equals(name)) {
            result = String.valueOf(this.element.getSize());

            // tagName
        } else if (TAG_NAME.equals(name)) {
            result = this.element.getTagName();

            // text
        } else if (TEXT.equals(name)) {
            result = this.element.getText();

            // color
        } else if (COLOR.equals(name)) {
            String colorStr = this.element.getCssValue(COLOR);
            result = Color.fromString(colorStr).asHex();

            // background-color
        } else if (BACKGROUND_COLOR.equals(name)) {
            String colorStr = this.element.getCssValue(BACKGROUND_COLOR);
            result = Color.fromString(colorStr).asHex();

            // Other Attribute
        } else {
            result = this.element.getAttribute(name);
        }

        return result;
    }

    /**
     * Is the element exist or not?
     * 
     * @return Whether or not the element is exist.
     */
    public boolean isExist() {
        return this.element != null;
    }

}
