package com.rakuten.gcs.testautomation.framework.web;

//import io.appium.java_client.ios.IOSDriver;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.saucelabs.common.SauceOnDemandAuthentication;
//import io.appium.java_client.remote.MobileCapabilityType;

public class WebDriverInitializer {

    private static final String IGNORE_PROXY_STRING = "0.0.0.0/0.0.0.0:80";

    static enum BrowserType {
        Firefox
    };

    private static BrowserType getBrowserType(String browserType) throws Exception {
        if (browserType.equals("Firefox")) {
            return BrowserType.Firefox;
        }
        throw new Exception("Unknown BorwserType: " + browserType);
    }

    final static Log logger = LogFactory.getLog(WebDriverInitializer.class);

    static public WebDriver getDriver(String scenarioName, String proxyString, String browserLocale) throws Exception {
        WebDriver driver;
        DesiredCapabilities capabilities;

        boolean enableSauceConnect = "true".equals(System.getenv("ENABLE_SAUCE_CONNECT")); //set by user in jenkins
        if (enableSauceConnect) {
            logger.info("ENABLE_SAUCE_CONNECT=true is given, so using local sauce connect.");

            SauceOnDemandAuthentication authentication = new SauceOnDemandAuthentication("qeuser", "3ff01068-5283-4316-91ce-6ce27d649d87");

            String os = System.getenv("SAUCELABS_OS");  //set by user in jenkins
            String browser = System.getenv("SAUCELABS_BROWSER_NAME"); //set by user in jenkins
            String version = System.getenv("SAUCELABS_BROWSER_VERSION"); //set by user in jenkins
            String platform = System.getenv("SAUCELABS_PLATFORM_NAME"); //"iOS" "Android"
            String tunnelIdentifer = System.getenv("TUNNEL_IDENTIFIER");

            if (System.getenv("SAUCELABS_BROWSER_LOCALE") != null) {
                browserLocale = System.getenv("SAUCELABS_BROWSER_LOCALE"); //set by user in jenkins			
            }

            capabilities = CapabilityBuilder.generate(os, platform, browser, browserLocale, version, scenarioName);

            capabilities.setCapability("idleTimeout", 60);

            if (tunnelIdentifer != null) {
                capabilities.setCapability("tunnelIdentifier", tunnelIdentifer);
            }

            logger.info("Capabilities is: " + capabilities.toString());
            driver = new RemoteWebDriver(new URL("http://" + authentication.getUsername() + ":" + authentication.getAccessKey() + "@localhost:4445/wd/hub"), capabilities);

            // Notify Jenkins SauceLabs result
            String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", ((RemoteWebDriver) driver).getSessionId(), scenarioName);
            System.out.println(message);

            ((RemoteWebDriver) driver).setFileDetector(new LocalFileDetector());
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

            return driver;

        } else {
            logger.info("ENABLE_SAUCE_CONNECT=true is NOT given, so using local FireFox browser.");

            DesiredCapabilities cap = new DesiredCapabilities();
//                      System.setProperty( "webdriver.firefox.bin", "S:\\Mozilla Firefox - 43\\firefox.exe" );
            if (!ignoreProxy(proxyString)) {
                if (System.getenv("LOCAL_BROWSER_PROXY") != null) {
                    proxyString = System.getenv("LOCAL_BROWSER_PROXY"); //set by user in jenkins			
                }

                org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
                proxy.setHttpProxy(proxyString).setFtpProxy(proxyString).setSslProxy(proxyString);
                cap.setCapability(CapabilityType.PROXY, proxy);
            }
            FirefoxProfile profile = new FirefoxProfile();
            profile.setPreference(FirefoxProfile.ALLOWED_HOSTS_PREFERENCE, "localhost.localdomain");
            profile.setPreference("intl.accept_languages", browserLocale);
            /*
             * FIREMOBILESIMULATOR_OPTION type is current:carrier:currentid
             */
            String firemobilesimulatorOption = System.getenv("FIREMOBILESIMULATOR_OPTION");
            /*
             * example : firemobilesimulatorOption = "1:DC:1"
             */
            if (firemobilesimulatorOption != null) {
                String FilePath = "src/test/resources/com/rakuten/gcs/testautomation/services/jpid/web/firemobilesimulator/";
                File file = new File(FilePath + "firemobilesimulator-1.2.4-fx.xpi");
                profile.addExtension(file);
                String[] option = firemobilesimulatorOption.split(":");
                profile.setPreference("msim.current", option[0]);
                profile.setPreference("msim.current.carrier", option[1]);
                profile.setPreference("msim.current.id", option[2]);
                logger.info("FIREMOBILESIMULATOR_OPTION is not null, so using firemobilesimulator " + option[1] + " to run FireFox browser.");
                //                profile.setPreference("network.proxy.http", "dev-proxy.db.rakuten.co.jp");
                //                profile.setPreference("network.proxy.http_port", 9503);
            }
            // start download profile
            String downloadPath = System.getenv("FIREFOX_DOWNLOAD_PATH");
            if (downloadPath != null) {
                profile.setPreference("browser.download.folderList", 2);
                profile.setPreference("browser.download.dir", downloadPath);
                profile.setPreference("browser.download.alertOnEXEOpen", false);
                profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
                profile.setPreference("browser.download.manager.showWhenStarting", false);
                profile.setPreference("browser.download.manager.focusWhenStarting", false);
                profile.setPreference("browser.download.useDownloadDir", true);
                profile.setPreference("browser.helperApps.alwaysAsk.force", false);
                profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
                profile.setPreference("browser.download.manager.closeWhenDone", true);
                profile.setPreference("browser.download.manager.showAlertOnComplete", false);
                profile.setPreference("browser.download.manager.useWindow", false);
                profile.setPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false);
                profile.setPreference("pdfjs.disabled", true);
            }
            // end download profile
            FirefoxBinary binary = new FirefoxBinary();
            binary.setTimeout(60000);
            try {
                driver = new FirefoxDriver(binary, profile, cap);
            } catch (Exception e) {
                logger.info("Failed to launch Firefox", e);
                ProcessBuilder pb = new ProcessBuilder("netstat", "-na");
                pb.redirectErrorStream(true);
                Process process = pb.start();
                int ret = process.waitFor();
                printInputStream(process.getInputStream());
                throw e;
            }
            return driver;
        }
    }

    private static boolean ignoreProxy(String proxyString) {
        return proxyString.equals(IGNORE_PROXY_STRING);
    }

    public static void printInputStream(InputStream is) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        try {
            for (;;) {
                String line = br.readLine();
                if (line == null)
                    break;
                System.out.println(line);
            }
        } finally {
            br.close();
        }
    }

}
