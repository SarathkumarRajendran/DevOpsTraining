package com.rakuten.gcs.testautomation.framework.api.client;

import com.mashape.unirest.http.HttpMethod;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.request.HttpRequest;
import com.mashape.unirest.request.HttpRequestWithBody;
import com.rakuten.gcs.testautomation.framework.api.object.APIObjectBase;
import com.rakuten.gcs.testautomation.framework.api.object.RestAPIObjectBase;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RestAPIClient extends BaseAPIClient {

    private boolean isCertificateCheckEnabled = true;

    final Log logger = LogFactory.getLog(RestAPIClient.class);

    public RestAPIClient() {
    }

    public RestAPIClient(String baseURI, String proxyHost, int proxyPort) {
        super(baseURI, proxyHost, proxyPort);
    }

    public RestAPIClient(String baseURI) {
        super(baseURI);
    }

    public boolean isCertificateCheckEnabled() {
        return isCertificateCheckEnabled;
    }

    public void setCertificateCheckEnabled(boolean certificateCheckEnabled) {
        isCertificateCheckEnabled = certificateCheckEnabled;
    }

    private HttpRequest getRequestProtocol(String method, String url) throws Exception {
        switch (method.toLowerCase()) {
            case "get":
                return Unirest.get(url);
            case "post":
                return Unirest.post(url);
            case "put":
                return Unirest.put(url);
            case "delete":
                return Unirest.delete(url);
            case "head":
                return Unirest.head(url);
            case "patch":
                return Unirest.patch(url);
            case "options":
                return Unirest.options(url);
            default:
                throw new Exception(method + " not supported");
        }
    }

    private void disableSSLCheck() {
        try {
            SSLContext sslcontext = SSLContexts.custom()
                    .loadTrustMaterial(null, new TrustSelfSignedStrategy())
                    .build();
            SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslcontext,SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            CloseableHttpClient httpclient;
            if (this.proxy != null) {
                logger.info("Proxy By Custom Client : " + this.proxy);
                httpclient = HttpClients.custom()
                        .setProxy(this.proxy)
                        .setSSLSocketFactory(sslConnectionSocketFactory)
                        .build();
            } else {
                httpclient = HttpClients.custom()
                        .setSSLSocketFactory(sslConnectionSocketFactory)
                        .build();
            }
            Unirest.setHttpClient(httpclient);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sendRequest(APIObjectBase apiObjectBase) throws Exception {
        logger.info("#################################################");
        logger.info("------------------Request Start------------------");
        RestAPIObjectBase restAPIObjectBase = (RestAPIObjectBase) apiObjectBase;
        String fullURI;
        if (restAPIObjectBase.getVersion() != null && !restAPIObjectBase.getVersion().isEmpty()) {
            fullURI = this.baseURI + "/" + restAPIObjectBase.getVersion() +"/"+ restAPIObjectBase.getRoute();
        } else {
            fullURI = this.baseURI + "/" + restAPIObjectBase.getRoute();
        }
        HttpRequest httpRequest = getRequestProtocol(restAPIObjectBase.getHttpMethod().toString(), fullURI);
        /***********************************************************
         *                      Headers Part                       *
         ***********************************************************/
        if (restAPIObjectBase.getBasicAuth().size() != 0) {
            for (Map.Entry<String, String> entry : restAPIObjectBase.getBasicAuth().entrySet()) {
                String username = entry.getKey();
                String password = entry.getValue();
                httpRequest.basicAuth(username, password);
            }
        }
        if (restAPIObjectBase.getHeaders().size() != 0) {
            httpRequest.headers(restAPIObjectBase.getHeaders());
        }
        for (Map.Entry<String, String> entry : restAPIObjectBase.getQueryParams().entrySet()) {
            httpRequest.queryString(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, String> entry : restAPIObjectBase.getRouteParams().entrySet()) {
            httpRequest.routeParam(entry.getKey(), entry.getValue());
        }
        logger.info("URL : " + httpRequest.getUrl());
        if (this.proxy != null && isCertificateCheckEnabled()) {
            logger.info("Proxy : " + this.proxy);
            Unirest.setProxy(proxy);
        }
        logger.info("Method : "+restAPIObjectBase.getHttpMethod());
        logger.info("HTTP Request Headers : ");
        for (Map.Entry<String, List<String>> entry : httpRequest.getHeaders().entrySet()) {
            logger.info(entry.getKey() + " = " + entry.getValue());
        }
        HttpResponse<String> httpResponse;
        if (!isCertificateCheckEnabled()) {
            logger.info("Disabling certificate check");
            disableSSLCheck();
        }
        if (!restAPIObjectBase.getHttpMethod().equals(HttpMethod.GET)) {
            logger.info("HTTP Request Body : ");
            HttpRequestWithBody httpRequestWithBody = (HttpRequestWithBody) httpRequest;
            /***********************************************************
             *                      Body Part                          *
             ***********************************************************/
            if (restAPIObjectBase.getFields().size() != 0 || restAPIObjectBase.getFiles().size() != 0) {
                logger.info("Fields : ");
                Map<String,Object> finalFields = new HashMap<>();
                for (Map.Entry<String, Object> field : restAPIObjectBase.getFields().entrySet()) {
                    finalFields.put(field.getKey(),field.getValue());
                    logger.info(field.getKey()+" = "+field.getValue());
                }
                for (Map.Entry<String, File> fieldFile : restAPIObjectBase.getFiles().entrySet()) {
                    finalFields.put(fieldFile.getKey(),fieldFile.getValue());
                    logger.info(fieldFile.getKey()+" = "+fieldFile.getValue()+" (File Upload)");
                }
                httpRequestWithBody.fields(finalFields);
            }
            if (restAPIObjectBase.getRawBody() != null && !restAPIObjectBase.getRawBody().isEmpty()) {
                logger.info("Raw : "+restAPIObjectBase.getRawBody());
                httpRequestWithBody.body(restAPIObjectBase.getRawBody());
            }
            httpResponse = httpRequestWithBody.asString();
        } else {
            httpResponse = httpRequest.asString();
        }
        logger.info("------------------Request End------------------");
        logger.info("-----------------Response Start----------------");
        logger.info("Response : ");
        logger.info("HTTP Response Headers : ");
        for (Map.Entry<String, List<String>> entry : httpResponse.getHeaders().entrySet()) {
            logger.info(entry.getKey() + " = " + entry.getValue());
        }
        logger.info("HTTP Response Body : ");
        logger.info(httpResponse.getBody());
        logger.info("-----------------Response End----------------");
        logger.info("#################################################");
        apiObjectBase.setHttpResponse(httpResponse);
    }
}
