package com.rakuten.gcs.testautomation.framework.api.steps;

import com.rakuten.gcs.testautomation.framework.api.SoapAPIObjectBase;
import com.rakuten.gcs.testautomation.framework.api.SoapPort;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;

/**
 * Created by aldo.suwandi on 2015/08/27.
 */

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SoapApiCommonSteps {

    final Log logger = LogFactory.getLog(SoapApiCommonSteps.class);

    protected SoapPort soapPort;

    public SoapApiCommonSteps(SoapPort soapPort) {

        this.soapPort = soapPort;
    }

    @When("^the user put \"([^\"]*)\" in \"([^\"]*)\" parameter$")
    public void the_user_put_in_parameter(String arg1, String arg2) throws Throwable {
        SoapAPIObjectBase soapAPIObjectBase = this.soapPort.getSelectedOperator();
        soapAPIObjectBase.addSoapParameterWithValue(arg1, arg2);
    }

    @Then("^the user send the request$")
    public void the_user_send_the_request() throws Throwable {
        SoapAPIObjectBase soapAPIObjectBase = this.soapPort.getSelectedOperator();
        soapAPIObjectBase.executeSoapApi(this.soapPort.getSoapApiClient());
    }

    @Then("^the user receive a response with \"([^\"]*)\" in \"([^\"]*)\" parameter$")
    public void the_user_receive_a_response_with_in_parameter(String expected, String actual) throws Throwable {
        Assert.assertEquals(expected, this.soapPort.getSelectedOperator().getResponseValueFromFirstElement(actual));
    }

}
