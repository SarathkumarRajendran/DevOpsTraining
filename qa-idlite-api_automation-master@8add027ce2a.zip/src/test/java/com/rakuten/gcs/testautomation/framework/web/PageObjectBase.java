package com.rakuten.gcs.testautomation.framework.web;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rakuten.gcs.testautomation.framework.util.SnapshotUtils;

import cucumber.api.Scenario;

public class PageObjectBase {

    final Log logger = LogFactory.getLog(PageObjectBase.class);

    protected int fillInStepTimeout = 500;

    final static public String pleaseInputMeOutputElementID = "$PleaseInputMeOutputElementID";
    final static public String pleaseInputMeOutputMessageID = "$PleaseInputMeOutputMessageID";

    protected String pageURI;
    protected String pageTitle;
    protected Map<String, String> inputElements;
    protected Map<String, String> outputElements;
    protected Map<String, String> imageElements;
    protected Map<String, String> defaultInputValues;
    protected Map<String, String> expectedValidationMessages;
    protected Map<String, Integer> elementTypes;
    protected String submitButtonName;
    protected String submitButtonXPath;

    public class PageObjectException extends Exception {
        /**
         * 
         */
        private static final long serialVersionUID = 1L;

        PageObjectException(String message) {
            super(message);
        }
    }

    public PageObjectBase() {
        inputElements = new HashMap<String, String>();
        outputElements = new HashMap<String, String>();
        imageElements = new HashMap<String, String>();
        defaultInputValues = new HashMap<String, String>();
        expectedValidationMessages = new HashMap<String, String>();
        elementTypes = new HashMap<String, Integer>();
    }

    final public String getExpectedValidationMessageKeyFromValue(String value) {
        String ret = null;
        for (Map.Entry<String, String> entry : expectedValidationMessages.entrySet()) {
            logger.debug("entry.getKey()=" + entry.getKey());
            logger.debug("   value=" + value);
            logger.debug("   entry.getValue()" + entry.getValue());
            if (value.equals(entry.getValue()))
                ret = entry.getKey();
        }
        logger.debug("ret= " + ret);
        return ret;
    }

    final protected void setPageURI(String pageURI) {
        this.pageURI = pageURI;
    }

    final protected void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }

    final protected void addInputElement(String inputElementName, String defaultValue, String xpath) {
        inputElements.put(inputElementName, xpath);
        if (!defaultValue.isEmpty()) {
            defaultInputValues.put(inputElementName, defaultValue);
        }
    }

    /**
     * Add element for input with the Type, default Value And xpath
     * 
     * @param inputElementName Element Name
     * @param elementType Element Type @see PageElement
     * @param defaultValue Default Value
     * @param xpath xpath
     */
    final protected void addInputElement(String inputElementName, int elementType, String defaultValue, String xpath) {
        elementTypes.put(inputElementName, elementType);
        addInputElement(inputElementName, defaultValue, xpath);
    }

    final protected void addOutputElement(String outputElementName, String xpath) {
        outputElements.put(outputElementName, xpath);
    }

    /**
     * Add element for output with the Type And xpath
     * 
     * @param outputElementName Element Name
     * @param elementType Element Type @see PageElement
     * @param xpath xpath
     */
    final protected void addOutputElement(String outputElementName, int elementType, String xpath) {
        elementTypes.put(outputElementName, elementType);
        outputElements.put(outputElementName, xpath);
    }

    final protected void addImageElement(String imageElementName, String xpath) {
        imageElements.put(imageElementName, xpath);
    }

    final protected void addInputOutputElement(String inputOutputElementName, String defaultValue, String xpath) {
        this.addInputElement(inputOutputElementName, defaultValue, xpath);
        this.addOutputElement(inputOutputElementName, xpath);
    }

    /**
     * Add element for input/output with the Type, default Value And xpath
     * 
     * @param inputOutputElementName Element Name
     * @param elementType Element Type @see PageElement
     * @param defaultValue Default Value
     * @param xpath xpath
     */
    final protected void addInputOutputElement(String inputOutputElementName, int elementType, String defaultValue, String xpath) {
        this.addInputElement(inputOutputElementName, defaultValue, xpath);
        this.addOutputElement(inputOutputElementName, elementType, xpath);
    }

    final protected void addExpectedValidationMessage(String name, String message) throws Exception {
        if (getExpectedValidationMessageKeyFromValue(message) != null) {
            throw new Exception("Duplicate messages are provided in expectedValidationMessages." + message);
        }
        expectedValidationMessages.put(name, message);
    }

    final protected void setSubmitButton(String submitButtonName, String xpath) {
        this.submitButtonXPath = xpath;
        this.submitButtonName = submitButtonName;
    }

    /* Functions for getting page information */

    final public String getExpectedValidationMessage(String name) {
        return expectedValidationMessages.get(name);
    }

    final public Set<String> getInputElementNameList() {

        return inputElements.keySet();
    }

    final public String getDefaultValueForInputElement(String name) {
        return defaultInputValues.get(name);
    }

    final public String getPageURI() {
        return pageURI;
    }

    final public String getOutputElementXPath(String name) {
        return outputElements.get(name);
    }

    final public String getInputElementXPath(String name) {
        return inputElements.get(name);
    }

    final public Integer getSettingElementType(String name) {
        return elementTypes.get(name);
    }

    final public void checkPageTitleThenThrowExceptionForWrongTitle(WebDriver driver) throws PageObjectException {
        String actualTitle = driver.getTitle();
        if (!pageTitle.equals(actualTitle)) {
            throw new PageObjectException(String.format("The page title opened is different. <%s> is expected but <%s> is actual", pageTitle, actualTitle));
        }
    }

    final public void checkPageTitleThenThrowExceptionForWrongTitle(WebDriver driver, Scenario scenario) throws PageObjectException {
        checkPageTitleThenThrowExceptionForWrongTitle(driver, scenario, pageTitle);
    }

    final public void checkPageTitleThenThrowExceptionForWrongTitle(WebDriver driver, Scenario scenario, String expectedTitle) throws PageObjectException {
        String actualTitle = driver.getTitle();
        this.takeAScreenshot(driver, scenario, "checkTitle");
        if (!expectedTitle.equals(actualTitle)) {
            throw new PageObjectException(String.format("The page title opened is different. <%s> is expected but <%s> is actual", expectedTitle, actualTitle));
        }
    }

    final public static boolean checkNoExpectedValueInFeatureFile(String outputElement, String messageID) {
        return PageObjectBase.pleaseInputMeOutputElementID.equals(outputElement) && PageObjectBase.pleaseInputMeOutputMessageID.equals(messageID);
    }

    /* Operation on pages */
    final public void openPage(WebDriver driver) throws PageObjectException {
        driver.get(pageURI);
        checkPageTitleThenThrowExceptionForWrongTitle(driver);
    }

    /* Operation on pages */
    final public void openPage(WebDriver driver, Scenario scenario) throws PageObjectException {

        try {
            driver.get(pageURI);
            checkPageTitleThenThrowExceptionForWrongTitle(driver);
            this.takeAScreenshot(driver, scenario, "openPage");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "openPage");
            throw ex;
        }

    }

    final public void openPageWithoutCheckTitle(WebDriver driver) throws PageObjectException {
        driver.get(pageURI);
    }

    final public void putInputTextToInputElement(WebDriver driver, String inputText, String inputElementName) throws InterruptedException {
        String xpath = inputElements.get(inputElementName);
        //putBlankToInputElement(driver, inputElementName);
        Thread.sleep(fillInStepTimeout);
        driver.findElement(By.xpath(xpath)).sendKeys(inputText);
    }

    final public void putBlankToInputElement(WebDriver driver, String inputElementName) {
        String xpath = inputElements.get(inputElementName);
        driver.findElement(By.xpath(xpath)).clear();
    }

    final public void clearAndInputTextToInputElement(WebDriver driver, String inputText, String inputElementName) throws InterruptedException {
        putBlankToInputElement(driver, inputElementName);
        putInputTextToInputElement(driver, inputText, inputElementName);
    }

    final public void setDefaultValueForInputElement(WebDriver driver) throws Throwable {
        for (String propertyName : defaultInputValues.keySet()) {
            Thread.sleep(fillInStepTimeout);
            this.putInputTextToInputElement(driver, defaultInputValues.get(propertyName), propertyName);
        }
    }

    final public void setOptionToSelectElement(WebDriver driver, String selectedOption, String inputElementName) {
        String xpath = inputElements.get(inputElementName);
        WebElement selectElement = driver.findElement(By.xpath(xpath));
        Select dropDown = new Select(selectElement);
        dropDown.selectByVisibleText(selectedOption);
    }

    final public void setOptionToSelectElementByValue(WebDriver driver, String selectedOptionValue, String inputElementName) {
        String xpath = inputElements.get(inputElementName);
        WebElement selectElement = driver.findElement(By.xpath(xpath));
        Select dropDown = new Select(selectElement);
        dropDown.selectByValue(selectedOptionValue);
    }

    final public String getOutputTextFromOutputElement(WebDriver driver, String outputElementName) {
        String xpath = outputElements.get(outputElementName);
        return driver.findElement(By.xpath(xpath)).getText();
    }

    final public String getValueFromMultipleTypesElement(WebDriver driver, String outputElementName) {
        String xpath = getOutputElementXPath(outputElementName);
        Integer type = getSettingElementType(outputElementName);
        List<WebElement> webElements = waitAndFindElementBys(driver, By.xpath(xpath));
        //List<WebElement> webElements = driver.findElements(By.xpath(xpath));

        PageElement pageElement = new PageElement(webElements, type);

        return pageElement.getValueOfDefaultAttribute();
    }

    final public String getAttributeFromMultipleTypesElement(WebDriver driver, String elementName, String attributeName) {
        String xpath = getOutputElementXPath(elementName);
        if (xpath == null) {
            xpath = getInputElementXPath(elementName);
        }
        Integer type = getSettingElementType(elementName);
        List<WebElement> webElements = driver.findElements(By.xpath(xpath));

        PageElement pageElement = new PageElement(webElements, type);

        return pageElement.getStateOrAttributeValue(attributeName);
    }

    final public String getSrcFromImageElement(WebDriver driver, String outputElementName) {
        String xpath = imageElements.get(outputElementName);
        WebElement webElement = waitAndFindElementBy(driver, By.xpath(xpath));
        //WebElement webElement = driver.findElement(By.xpath(xpath));
        return webElement.getAttribute("src");
    }

    final public String getOutputValueFromOutputElement(WebDriver driver, String outputElementName) {
        String xpath = outputElements.get(outputElementName);
        return driver.findElement(By.xpath(xpath)).getAttribute("value");
    }

    final public void executeJavaScript(WebDriver driver, String scriptString) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript(scriptString);
    }

    final public String getStringByJavaScript(WebDriver driver, String scriptString) {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        return (String) jse.executeScript(scriptString);
    }

    final public String getOutputClassFromOutputElement(WebDriver driver, String outputElementName) {
        String xpath = outputElements.get(outputElementName);
        return driver.findElement(By.xpath(xpath)).getAttribute("class");
    }

    final public String getOutputHrefFromOutputELement(WebDriver driver, String outputElementName) {
        String xpath = outputElements.get(outputElementName);
        return driver.findElement(By.xpath(xpath)).getAttribute("href");
    }

    final public String getOutputCssFromOutputElement(WebDriver driver, String outputElementName, String cssName) {
        String xpath = outputElements.get(outputElementName);
        return driver.findElement(By.xpath(xpath)).getCssValue(cssName);
    }

    final public String getOptionToSelectElement(WebDriver driver, String inputElementName) {
        String selValue = "";
        String xpath = inputElements.get(inputElementName);
        WebElement selectElement = driver.findElement(By.xpath(xpath));
        Select dropDown = new Select(selectElement);
        selValue = dropDown.getFirstSelectedOption().getText();
        return selValue;
    }

    final public List<String> getAllValuOfPullDown(WebDriver driver, String inputElementName) {
        String xpath = inputElements.get(inputElementName);
        WebElement selectElement = driver.findElement(By.xpath(xpath));
        Select dropDown = new Select(selectElement);
        List<WebElement> selValue = dropDown.getOptions();

        List<String> selectText = new ArrayList<String>();
        for (WebElement option : selValue) {
            selectText.add(option.getText());
        }
        return selectText;
    }

    final public String getNotNullOutputElementName(WebDriver driver) {
        NoSuchElementException ee = null;
        for (String outputElementName : outputElements.keySet()) {
            logger.debug("Try" + outputElementName);
            String xpath = outputElements.get(outputElementName);
            try {
                driver.findElement(By.xpath(xpath)).getText();
            } catch (NoSuchElementException e) {
                ee = e;
                continue;
            }
            logger.debug("FoundOutputElementName = " + outputElementName);
            return outputElementName;
        }
        throw ee;
    }

    final public void submitAForm(WebDriver driver) throws PageObjectException {
        driver.findElement(By.xpath(submitButtonXPath)).submit();
        checkPageTitleThenThrowExceptionForWrongTitle(driver);
    }

    final public void submitAFormWithoutCheckTitle(WebDriver driver) throws PageObjectException {
        driver.findElement(By.xpath(submitButtonXPath)).submit();
    }

    final public void submitAForm(WebDriver driver, Scenario scenario) throws PageObjectException {
        this.takeAScreenshot(driver, scenario, "submitAForm-before");
        try {
            driver.findElement(By.xpath(submitButtonXPath)).submit();
            checkPageTitleThenThrowExceptionForWrongTitle(driver);
            this.takeAScreenshot(driver, scenario, "submitAForm-after");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "submitAForm-after");
            throw ex;
        }
    }

    final public void submitAFormWithoutCheckTitle(WebDriver driver, Scenario scenario) throws PageObjectException {
        this.takeAScreenshot(driver, scenario, "submitAFormWithoutCheckTitle-before");
        try {
            driver.findElement(By.xpath(submitButtonXPath)).submit();
            this.takeAScreenshot(driver, scenario, "submitAFormWithoutCheckTitle-after");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "submitAFormWithoutCheckTitle-after");
            throw ex;
        }
    }

    final public String getOutputPlaceholderFromOutputElement(WebDriver driver, String outputElementName) {
        String xpath = outputElements.get(outputElementName);
        return driver.findElement(By.xpath(xpath)).getAttribute("placeholder");
    }

    final public void clickButton(WebDriver driver, String buttonElementName) throws PageObjectException {
        String xpath = inputElements.get(buttonElementName);
        driver.findElement(By.xpath(xpath)).click();
        checkPageTitleThenThrowExceptionForWrongTitle(driver);
    }

    final public void clickButtonWithoutCheckTitle(WebDriver driver, String buttonElementName) throws PageObjectException {
        String xpath = inputElements.get(buttonElementName);
        driver.findElement(By.xpath(xpath)).click();
    }

    final public void clickButton(WebDriver driver, Scenario scenario, String buttonElementName) throws PageObjectException {
        this.takeAScreenshot(driver, scenario, "clickButton-before");
        String xpath = inputElements.get(buttonElementName);
        try {
            driver.findElement(By.xpath(xpath)).click();
            this.takeAScreenshot(driver, scenario, "clickButton-after");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "clickButton-after");
            throw ex;
        }
        checkPageTitleThenThrowExceptionForWrongTitle(driver);
    }

    final public void clickButtonWithoutCheckTitle(WebDriver driver, Scenario scenario, String buttonElementName) throws PageObjectException {
        this.takeAScreenshot(driver, scenario, "clickButtonWithoutCheckTitle-before");
        String xpath = inputElements.get(buttonElementName);
        try {
            waitAndFindElementBy(driver, By.xpath(xpath)).click();
            //driver.findElement(By.xpath(xpath)).click();
            this.takeAScreenshot(driver, scenario, "clickButtonWithoutCheckTitle-after");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "clickButtonWithoutCheckTitle-after");
            throw ex;
        }
    }

    final public void clickButtonAndSwitchFrame(WebDriver driver, Scenario scenario, String buttonElementName, String frameName) throws PageObjectException {
        this.takeAScreenshot(driver, scenario, "clickButtonAndChangeWindow-before");
        String xpath = inputElements.get(buttonElementName);
        try {
            driver.findElement(By.xpath(xpath)).click();
            driver.switchTo().frame(frameName);
            this.takeAScreenshot(driver, scenario, "clickButtonAndChangeWindow-after");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "clickButtonAndChangeWindow-after");
            throw ex;
        }
    }

    final public void clickButtonAndChangeWindow(WebDriver driver, Scenario scenario, String buttonElementName) throws PageObjectException {
        this.takeAScreenshot(driver, scenario, "clickButtonAndChangeWindow-before");
        String xpath = inputElements.get(buttonElementName);
        try {
            driver.findElement(By.xpath(xpath)).click();
            this.changeWindow(driver);
            this.takeAScreenshot(driver, scenario, "clickButtonAndChangeWindow-after");
        } catch (Exception ex) {
            this.takeAScreenshot(driver, scenario, "clickButtonAndChangeWindow-after");
            throw ex;
        }
    }

    final public void fillinTheForm(WebDriver driver, String elementName, String elementValue) throws InterruptedException {
        for (String inputElementName : getInputElementNameList()) {
            if (elementName.equals(inputElementName)) {
                putInputTextToInputElement(driver, elementValue, elementName);
            } else {
                String defaultValue = getDefaultValueForInputElement(inputElementName);
                putInputTextToInputElement(driver, defaultValue, inputElementName);
            }
        }
    }

    final public void clickRadioButtonElementByText(WebDriver driver, String myDesiredValue) {
        driver.findElement(By.xpath("//label[text()[contains(.,'" + myDesiredValue + "')]]")).click();
    }

    final public void clickSelectElementByText(WebDriver driver, String myDesiredValue) {
        driver.findElement(By.xpath("//li[text()[contains(.,'" + myDesiredValue + "')]]")).click();
    }

    final public void checkTheVisibilityOfOutputElement(WebDriver driver, String targetOutputElementName) throws IOException {
        logger.info("Try to get the value of " + targetOutputElementName);
        String xpath = outputElements.get(targetOutputElementName);
        logger.info("xpath of this element is  " + xpath);
        List<WebElement> elements = driver.findElements(By.xpath(xpath));
        for (WebElement element : elements) {
            // takeAScreenshot(driver);
            logger.info("                 tagName     = " + element.getTagName());
            logger.info("                 text        = " + element.getText());
            logger.info("                 isDisplayed = " + element.isDisplayed());

            WebDriverWait wait = new WebDriverWait(driver, 10);
            try {
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
            } catch (Exception e) {
                logger.info("Exception occurred while waiting for an element becoming visible");
            }
            logger.info("                 tagName     = " + element.getTagName());
            logger.info("                 text        = " + element.getText());
            logger.info("                 isDisplayed = " + element.isDisplayed());

            //takeAScreenshot(driver);    
        }
    }

    final public void takeAScreenshot(WebDriver driver) throws IOException {
        File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file, new File("./screenshot" + System.currentTimeMillis() + ".jpg"));
    }

    final public void takeAScreenshot(WebDriver driver, Scenario scenario, String action) {

        try {
            SnapshotUtils.takeSnapshot(driver, scenario, pageTitle, action);
        } catch (IOException e) {
            logger.error("Failed to take a snapshot", e);
        }
    }

    protected String getBusinessLogicResultByKeyword(WebDriver driver, String keyword) throws Throwable {
        return null;
    }

    final public String getBusinessLogicResultOrOutputElementValueByKeywordOrOutputElementName(WebDriver driver, String outputElementNameOrBusinessKeyword) throws Throwable {
        logger.info("getBusinessLogicResultOrOutputElementValueByKeywordOrOutputElementName()");
        logger.info(outputElementNameOrBusinessKeyword);

        String logicValue = getBusinessLogicResultByKeyword(driver, outputElementNameOrBusinessKeyword);

        if (logicValue != null) {
            return logicValue;

        } else if (hasOutputElement(outputElementNameOrBusinessKeyword)) {
            return getValueFromMultipleTypesElement(driver, outputElementNameOrBusinessKeyword);

        } else if (hasImageElement(outputElementNameOrBusinessKeyword)) {
            return getSrcFromImageElement(driver, outputElementNameOrBusinessKeyword);

        } else {
            throw new Exception("Output Element keyword is not defined. keyword = " + outputElementNameOrBusinessKeyword);
        }
    }

    protected void operateKeyword(WebDriver driver, String keyword, String value) throws Throwable {
        throw new Exception("Any BusinessLogic is not implemented.");
    }

    public String inputToMultipleTypesElement(WebDriver driver, String inputElementName, String value) throws Exception {
        String xpath = inputElements.get(inputElementName);
        Integer type = elementTypes.get(inputElementName);
        List<WebElement> webElements = waitAndFindElementBys(driver, By.xpath(xpath));
        //List<WebElement> webElements = driver.findElements(By.xpath(xpath));
        PageElement pageElement = new PageElement(webElements, type);

        Thread.sleep(fillInStepTimeout);
        return pageElement.inputToElementBaseOnType(value);
    }

    final public void inputToMultipleTypesElementOrOperateKeyword(WebDriver driver, String keyOrElementName, String value) throws Throwable {

        value = changeDescriptionToValueForInput(keyOrElementName, value);

        if (hasInputElement(keyOrElementName)) {
            inputToMultipleTypesElement(driver, keyOrElementName, value);

        } else {
            operateKeyword(driver, keyOrElementName, value);
        }
    }

    public void inputTextOrOperateKeywordWithValue(WebDriver driver, String inputElementNameOrKeyword, String value) throws Throwable {
        if (hasInputElement(inputElementNameOrKeyword)) {
            putInputTextToInputElement(driver, value, inputElementNameOrKeyword);
        } else {
            operateKeyword(driver, inputElementNameOrKeyword, value);
        }
    }

    public void prepareThenOpenPage(WebDriver driver, Map<String, PageObjectBase> pageObjectMap, Scenario scenario, List<String> parameters) throws Throwable {
        throw new Exception("notImplemented !!!");
    }

    public void prepareThenOpenPage(WebDriver driver, Map<String, PageObjectBase> pageObjectMap, Scenario scenario, Map<String, String> parameters) throws Throwable {
        throw new Exception("notImplemented !!!");
    }

    public void prepareThenOpenPageByDifferentMethod(WebDriver driver, Map<String, PageObjectBase> pageObjectMap, Scenario scenario, String methodName, Map<String, String> parameters) throws Throwable {
        throw new Exception("notImplemented !!!");
    }

    final private boolean hasOutputElement(String outputElementName) {
        return outputElements.containsKey(outputElementName);
    }

    final private boolean hasInputElement(String inputElementName) {
        return inputElements.containsKey(inputElementName);
    }

    final private boolean hasImageElement(String imageElementName) {
        return imageElements.containsKey(imageElementName);
    }

    final public void clickCheckButtonElementByText(WebDriver driver, String myDesiredValue) {
        driver.findElement(By.xpath("//label[text()[contains(.,'" + myDesiredValue + "')]]")).click();
    }

    final public void clickCheckButtonElementByXpath(WebDriver driver, String checkElementName) {
        String xpath = this.getInputElementXPath(checkElementName);
        driver.findElement(By.xpath(xpath)).click();
    }

    /**
     * change current window object
     */
    final public void changeWindow(WebDriver driver) {
        String currentHandle;
        try {
            currentHandle = driver.getWindowHandle();
        } catch (NoSuchWindowException e) {
            currentHandle = "";
        }
        for (String handle : driver.getWindowHandles()) {
            if (handle.equals(currentHandle)) {
                continue;
            } else {
                driver.switchTo().window(handle);
            }
        }
    }

    public String changeDescriptionToValue(String elementName, String description) {
        return description;
    }

    public void expectResponseAPI(Map<String, Object> params) throws Throwable {
        throw new Exception("No API pageObject !!!");
    }

    public void testAPI(String memberId, String testId, Map<String, Object> params) throws Throwable {
        throw new Exception("No API pageObject !!!");
    }

    protected String changeDescriptionToValueForInput(String elementName, String description) {
        return description;
    }

    private WebElement waitAndFindElementBy(WebDriver driver, By byObj) {
        /* wait the element start */
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(byObj));
        /* wait the element end */
        return driver.findElement(byObj);
    }

    private List<WebElement> waitAndFindElementBys(WebDriver driver, By byObj) {
        /* wait the element start */
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(byObj));
        /* wait the element end */
        return driver.findElements(byObj);
    }

}