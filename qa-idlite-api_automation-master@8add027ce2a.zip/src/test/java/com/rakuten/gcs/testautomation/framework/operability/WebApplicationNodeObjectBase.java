package com.rakuten.gcs.testautomation.framework.operability;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import org.apache.commons.io.output.NullOutputStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public abstract class WebApplicationNodeObjectBase {

    final static Log logger = LogFactory.getLog(WebApplicationNodeObjectBase.class);

    protected String sshPrivateKeyFile;
    protected String user;
    protected String hostName;
    protected int sshConnectionTimeout;

    private JSch jsch;

    protected HashMap<String, String> actualCommands;
    protected HashMap<String, Integer> commandTimeouts;

    protected HashMap<String, String> virtualHosts;

    private long lastExecutionTime;

    public long getLastExecutionTime() {
        return lastExecutionTime;
    }

    private int lastSucessfulStatus;

    public int getLastSuccessfulStatus() {
        return lastSucessfulStatus;
    }

    static {
    }

    private WebApplicationNodeObjectBase() {
        this.actualCommands = new HashMap<String, String>();
        this.commandTimeouts = new HashMap<String, Integer>();
        this.virtualHosts = new HashMap<String, String>();
    }

    public WebApplicationNodeObjectBase(String sshPrivateKeyFile, String user, String hostName, int sshConnectionTimeout) throws JSchException {
        this();

        this.sshPrivateKeyFile = sshPrivateKeyFile;
        this.user = user;
        this.hostName = hostName;
        this.sshConnectionTimeout = sshConnectionTimeout;

        this.lastExecutionTime = -1;
        this.lastSucessfulStatus = -1;

        this.jsch = new JSch();
        this.jsch.addIdentity(this.sshPrivateKeyFile);
        this.jsch.setKnownHosts("~/.ssh/known_hosts");

    }

    protected void addCommand(String commandKey, String actualCommand, int commandTimeout) {
        this.actualCommands.put(commandKey, actualCommand);
        this.commandTimeouts.put(commandKey, commandTimeout);
    }

    protected void setVirtualHostBaseUrl(String vhostKey, String virtualHostBaseURLs) {
        this.virtualHosts.put(vhostKey, virtualHostBaseURLs);
    }

    public String getVirtualHostBaseUrl(String vhostKey) {
        return this.virtualHosts.get(vhostKey);
    }

    public int executeOneCommandAndGetReturnValue(String commandKey) throws Exception {

        // FIXME: Add timeout feature to avoid command runs forever if the command doesnt finish.

        String actualCommand = this.actualCommands.get(commandKey);

        logger.info(String.format("Executing command: %s", actualCommand));

        Session session = createSessionAndConnect(this.user, this.hostName);

        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand(actualCommand);
        channel.setErrStream(NullOutputStream.NULL_OUTPUT_STREAM);
        channel.setOutputStream(NullOutputStream.NULL_OUTPUT_STREAM);
        long startTime = System.nanoTime();
        channel.connect(this.sshConnectionTimeout);

        // get stdout
        InputStream in = channel.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(in));

        String line;
        logger.info("Notice: here starts a loop without timeout. If you found following is stopping long time, please abort the job if nessary.");
        logger.info("======== SSH Command Start ========");
        while (((line = br.readLine()) != null) && (!channel.isClosed())) {
            logger.info(line);
        }
        logger.info("======== SSH Command End ========");
        logger.info(String.format("exit-status: %s", channel.getExitStatus()));

        //        byte[] tmp = new byte[1024];
        //        while (true) {
        //            while (in.available() > 0) {
        //                int i = in.read(tmp, 0, 1024);
        //                if (i < 0)
        //                    break;
        //            }
        //            if (channel.isClosed()) {
        //                logger.info(String.format("exit-status: %s", channel.getExitStatus()));
        //                break;
        //            }
        //        }

        this.lastExecutionTime = (System.nanoTime() - startTime) / 1000000L;
        this.lastSucessfulStatus = channel.getExitStatus();
        return this.lastSucessfulStatus;

    }

    private Session createSessionAndConnect(String user, String hostName) throws JSchException {
        Session session = this.jsch.getSession(user, hostName);
        session.setTimeout(this.sshConnectionTimeout);
        session.setConfig("StrictHostKeyChecking", "yes");

        try {
            session.connect();
        } catch (JSchException e) {
            if (e.getMessage().contains("HostKey")) {
                logger.warn("Host key verification failed. Test framework is retrying to connect without verification.");
                logger.warn(e.getMessage());
                session.disconnect();
                session = jsch.getSession(this.user, this.hostName);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();
            } else {
                throw e;
            }
        }
        return session;
    }

}
