package com.rakuten.gcs.testautomation.framework.featuregenerator;

public class SimpleValidationTextPattern extends ValidationTextPattern {

    final static String SIMPLE_VALIDATION_TEXT_PATTERN = "src/test/resources/com/rakuten/gcs/testautomation/viewpoint/simple_validation_text.pattern";
    final static String SIMPLE_VALIDATION_FEATURE_FILE_SUFFIX = "-simple_text_validation.feature";

    public SimpleValidationTextPattern() throws Exception {
        super(SIMPLE_VALIDATION_TEXT_PATTERN, SIMPLE_VALIDATION_FEATURE_FILE_SUFFIX);
    }

    public SimpleValidationTextPattern(String featureFile) throws Exception {
        super(featureFile, SIMPLE_VALIDATION_FEATURE_FILE_SUFFIX);
    }

}
