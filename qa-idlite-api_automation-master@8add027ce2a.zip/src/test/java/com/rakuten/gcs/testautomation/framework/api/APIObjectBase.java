package com.rakuten.gcs.testautomation.framework.api;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.gargoylesoftware.htmlunit.javascript.host.dom.Document;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class APIObjectBase {

    @SuppressWarnings("serial")
    public class APIObjectBaseException extends Exception {
        public APIObjectBaseException(String message) {
            super(message);
        }
    }

    final Log logger = LogFactory.getLog(APIObjectBase.class);

    final static public String pleaseInputMeOutputElementID = "$PleaseInputMeOutputElementID";
    final static public String pleaseInputMeOutputMessageID = "$PleaseInputMeOutputMessageID";

    protected RestAPITestClient client;
    public String apiName;
    protected String baseURI;
    protected Map<String, String> parametersWithDefaultValue;
    protected MediaType inputMediaType;
    protected String method = "GET";

    protected Map<String, String> outputElements;
    protected Map<String, String> expectedValidationMessages;
    protected String responseBody;
    private DocumentContext dcx;

    protected Map<String, String> soapRequestParams;
    protected Map<String, String> soapResponseParams;
   // protected SoapAPITestClient soapAPITestClient;

    class JsonObjectParseException extends Exception {
        JsonObjectParseException(String message) {
            super(message);
        }
    }

    public APIObjectBase(String apiName, String proxyHost, int proxyPort) {
        parametersWithDefaultValue = new HashMap<String, String>();
        outputElements = new HashMap<String, String>();
        client = new RestAPITestClient(proxyHost, proxyPort);
        this.apiName = apiName;
    }

    public APIObjectBase(String methodName, String endpoint, String namespace) {
        soapRequestParams = new HashMap<String, String>();
        soapResponseParams = new HashMap<String, String>();
       // soapAPITestClient = new SoapAPITestClient(methodName, endpoint, namespace);
    }

    final protected void setSoapWsdlUrl(String wsdlUrl) {
      //  soapAPITestClient.setWsdlUrl(wsdlUrl);
    }

    final protected void setBasicAuth(String account, String password) {
        client.addBasicAuthFilter(account, password);
    }

    final protected void setURIBase(String uriBase) {
        this.baseURI = uriBase;
    }

    final protected void setRequestMethod(String requestMethod) {
        this.method = requestMethod;
    }

    final public void reSetInlineURIBase(String patern, String value) {
        if (this.baseURI.contains(patern)) {
            this.baseURI = this.baseURI.replace(patern, value);
        }
    }

    final protected void setInputMediaType(MediaType type) {
        this.inputMediaType = type;
        ;
    }

    final protected void addParameter(String parameterName, String defaultValue) {
        parametersWithDefaultValue.put(parameterName, defaultValue);
    }

    final protected void addSoapParameter(String parameterName, String defaultValue) {
        soapRequestParams.put(parameterName, defaultValue);
    }

    final protected void addSoapTreeParameter(String parameterName, String defaultValue) {
       // soapAPITestClient.soapRequestTreeParams.put(parameterName, defaultValue);
    }

    final private void requestByMethods() throws UnsupportedEncodingException, APIObjectBaseException {
        if ("GET".equals(method)) {
            client.requestGetToURLWithParameters(baseURI, inputMediaType);
        } else if ("POST".equals(method)) {
            client.requestPostToURLWithParameters(baseURI, inputMediaType);
        } else {
            throw new APIObjectBaseException("Only GET method is supported for requestWithParameterStr()");
        }
    }

    final private void requestByMethodsSetChar() throws UnsupportedEncodingException, APIObjectBaseException {
        if ("GET".equals(method)) {
            client.requestGetToURLWithParametersSetChar(baseURI, inputMediaType);
        } else if ("POST".equals(method)) {
            client.requestPostToURLWithParameters(baseURI, inputMediaType);
        } else {
            throw new APIObjectBaseException("Only GET method is supported for requestWithParameterStr()");
        }
    }

    final private void httpRequestByMethodsSetChar() throws UnsupportedEncodingException, APIObjectBaseException {
        if ("GET".equals(method)) {
            client.httpRequestGetToURLWithParametersSetChar(baseURI, inputMediaType);
        } else if ("POST".equals(method)) {
            client.httpRequestPostToURLWithParameters(baseURI, inputMediaType);

        } else {
            throw new APIObjectBaseException("Only GET method is supported for requestWithParameterStr()");
        }
    }

    final public void requestWithGivenValueForAParameterAndDefaultToOthers(String parameterName, String parameterValue) throws UnsupportedEncodingException, APIObjectBaseException {
        client.init();
        for (String name : parametersWithDefaultValue.keySet()) {
            logger.debug("name = " + name);
            if (parameterName.equals(name)) {
                client.putParameter(name, parameterValue);
            } else {
                String defaultValue = parametersWithDefaultValue.get(name);
                client.putParameter(name, defaultValue);
            }
        }
        requestByMethods();
    }

    final public void requestWithGivenValueForAParameterAndDefaultToOthersSetChar(String parameterName, String parameterValue) throws UnsupportedEncodingException, APIObjectBaseException {
        client.init();
        for (String name : parametersWithDefaultValue.keySet()) {
            logger.debug("name = " + name);
            if (parameterName.equals(name)) {
                client.putParameter(name, parameterValue);
            } else {
                String defaultValue = parametersWithDefaultValue.get(name);
                client.putParameter(name, defaultValue);
            }
        }
        requestByMethodsSetChar();
    }

    final public void httpRequestWithGivenValueForAParameterAndDefaultToOthersSetChar(String parameterName, String parameterValue) throws UnsupportedEncodingException, APIObjectBaseException {

        client.init();
        for (String name : parametersWithDefaultValue.keySet()) {
            logger.debug("name = " + name);
            if (parameterName.equals(name)) {
                client.putParameter(name, parameterValue);
            } else {
                String defaultValue = parametersWithDefaultValue.get(name);
                client.putParameter(name, defaultValue);
            }
        }
        httpRequestByMethodsSetChar();
    }

    final public void requestWithParameterStr(String parameterStr) throws Exception {
        client.init();
        String[] parameterStrings = parameterStr.split("&");
        for (String paramCombined : parameterStrings) {
            String[] paramSeparated = paramCombined.split("=");
            if (paramSeparated.length != 2) {
                throw new Exception("Invalid param. " + paramCombined);
            }
            client.putParameter(paramSeparated[0], paramSeparated[1]);
        }
        requestByMethods();
    }

    final public void reqeustToBaseURIWithDefaultParameters() throws APIObjectBaseException, UnsupportedEncodingException {
        client.init();
        for (String name : parametersWithDefaultValue.keySet()) {
            String defaultValue = parametersWithDefaultValue.get(name);
            client.putParameter(name, defaultValue);
        }
        requestByMethods();
    }

    final public void requestToBaseURI() throws UnsupportedEncodingException, APIObjectBaseException {
        client.init();
        if ("GET".equals(method)) {
            client.requestGetToURL(baseURI, inputMediaType);
        } else {
            throw new APIObjectBaseException("Only GET method is supported for requestToBaseURI() ");
        }
    }

    final public JsonObject getResponseAsJsonObject() throws JsonSyntaxException, Exception {
        JsonParser parser = new JsonParser();
        JsonObject obj = (JsonObject) parser.parse(client.getResponseString());
        return obj;
    }

    final public String getResponseAsString() throws JsonSyntaxException, Exception {
        return client.getResponseString();
    }


    final public String getTopLevelFieldInJsonResponseAsString(String fieldName) throws JsonSyntaxException, Exception {
        JsonObject obj = getResponseAsJsonObject();
        return obj.get(fieldName).getAsString();
    }

    final public int getLastHttpStatus() throws Exception {
        return client.getHttpStatus();
    }

    final public void setJsonParseResponse(String responseBody) {
        expectedValidationMessages = new HashMap<String, String>();
        this.responseBody = responseBody;

        if ("".equals(responseBody) || responseBody == null) {
            responseBody = "{}";
        }
        dcx = JsonPath.parse(responseBody);
    }

    final public String getJsonTextValue(String name) {
        String xpath = outputElements.get(name);

        if (dcx.read(xpath) == null) {
//            return PremiumConstants.PREMIUM_NULL_VALUE;
        }

        return dcx.read(xpath).toString();
    }

    // final public class JavaReadXml {
    private Document doc = null;

    public void init(String responseBody) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        doc = (Document) db.parse(new File(responseBody));
        System.out.println("==============" + doc);
    }

    // }

    final public void addOutputElement(String outputElementName, String xpath) {
        outputElements.put(outputElementName, xpath);
    }

    final protected void setSoapRequestParams(Map<String, String> requestParams) {
        soapRequestParams = requestParams;
    }

    final protected void addSoapResponseParams(String soapResponseParamName) {
        soapResponseParams.put(soapResponseParamName, null);
    }

    final public String getSoapResponseParamValue(String soapResponseParamName) {
        return soapResponseParams.get(soapResponseParamName);
    }

   

    public void setSoapResponseToMapList() throws JsonSyntaxException, Exception {
        throw new APIObjectBaseException("assertValue Exception!");
    }

    public void assertValue(String responseKey, String responseValue) throws APIObjectBaseException {
        throw new APIObjectBaseException("assertValue Exception!");
    }

    public void setParameter(String parameterName, String parameterValue) throws APIObjectBaseException {
        throw new APIObjectBaseException("assertValue Exception!");
    }

   
    public void clearSoapRequestParams() {
        if (soapRequestParams != null) {
            soapRequestParams.clear();
        }
    }

    


    public boolean containsKeySoapRequestParams(String key) {
        return soapRequestParams.containsKey(key);

    }

    public boolean containsValueSoapRequestParams(String value) {
        return soapRequestParams.containsValue(value);
    }

    public void removeSoapRequestParams(String key) {
        if (soapRequestParams.containsKey(key)) {
            soapRequestParams.remove(key);
        }
    }

    public void resetSoapRequestParams(String key, String value) {
        if (soapRequestParams.containsKey(key)) {
            soapRequestParams.put(key, value);
        }
    }

    public void clearRequestParams() {
        if (parametersWithDefaultValue != null) {
            parametersWithDefaultValue.clear();
        }
    }

    public void jsonFileAssertValue() throws APIObjectBaseException {
        throw new APIObjectBaseException("assertValue Exception!");
    }
}
