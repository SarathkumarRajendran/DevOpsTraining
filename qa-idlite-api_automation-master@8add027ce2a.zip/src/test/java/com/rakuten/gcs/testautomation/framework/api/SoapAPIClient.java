package com.rakuten.gcs.testautomation.framework.api;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

/**
 * Created by aldo.suwandi on 2015/08/20.
 */
public class SoapAPIClient {

    final static Log logger = LogFactory.getLog(SoapAPIClient.class);

    protected String serverUrl;

    private URL url;
    private Proxy proxy;

    public SoapAPIClient(String proxyServer, int proxyPort) throws SOAPException {
        this.proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyServer, proxyPort));
    }

    public SoapAPIClient(String proxyServer, int proxyPort, final String proxyUsername, final String proxyPassword) throws MalformedURLException, SOAPException {
        this(proxyServer, proxyPort);
        Authenticator.setDefault(new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                if (proxyUsername == null || proxyPassword == null)
                    return null;
                return new PasswordAuthentication(proxyUsername, proxyPassword.toCharArray());
            }
        });
    }

    public static String getSOAPMessageAsString(SOAPMessage soapMessage) {
        try {
            TransformerFactory tff = TransformerFactory.newInstance();
            Transformer tf = tff.newTransformer();
            tf.setOutputProperty(OutputKeys.INDENT, "yes");
            tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            Source sc = soapMessage.getSOAPPart().getContent();
            ByteArrayOutputStream streamOut = new ByteArrayOutputStream();
            StreamResult result = new StreamResult(streamOut);
            tf.transform(sc, result);
            String strMessage = streamOut.toString();
            return "\n" + strMessage.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
        } catch (Exception e) {
            System.out.println("Exception in getSOAPMessageAsString " + e.getMessage());
            return null;
        }

    }

    public URL getUrl() {
        return url;
    }

    public Proxy getProxy() {
        return proxy;
    }

    private void createUrl(String serverUrl) throws MalformedURLException {
        this.serverUrl = serverUrl;
        this.url = new URL(null, serverUrl, new URLStreamHandler() {
            protected URLConnection openConnection(URL url) throws IOException {
                URL clone = new URL(url.toString());
                URLConnection urlConnection = null;
                if (proxy.address().toString().equals("0.0.0.0/0.0.0.0:80")) {
                    urlConnection = clone.openConnection();
                } else {
                    urlConnection = clone.openConnection(proxy);
                    urlConnection.setConnectTimeout(99999);
                    urlConnection.setReadTimeout(99999);
                }
                return urlConnection;
            }
        });
    }

    public SOAPBody createSoapRequest(String serverUrl, SOAPMessage soapMessage) throws SOAPException, IOException {
        this.createUrl(serverUrl);
        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
        final SOAPConnection soapConnection = soapConnectionFactory.createConnection();
        SOAPMessage soapResponse = soapConnection.call(soapMessage, this.url);
        logger.info("\n----------------------BEGIN RESPONSE ENVELOPE-----------------------\n" + getSOAPMessageAsString(soapResponse) + "\n-----------------------END RESPONSE ENVELOPE------------------------\n");
        SOAPBody soapBody = soapResponse.getSOAPBody();
        soapConnection.close();
        return soapBody;
    }
}