package com.rakuten.gcs.testautomation.framework.api;

import java.io.IOException;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScheme;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.AuthState;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.ExecutionContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

/**
 * Simple class to launch a jenkins build
 */
public class JenkinsPreemptive {

    public JenkinsPreemptive(String jenkinsUrl, Map<String, String> params) {

        // Credentials
        // username
        String username = "qeuser";
        // Build token
        String buildToken = "1f62dfac9d19abff74b95bbb3a103af5";

        // Create your httpclient
        DefaultHttpClient client = new DefaultHttpClient();
        // set proxy
        HttpHost proxy = new HttpHost("dev-proxy.db.rakuten.co.jp", 17011);
        client.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);

        // Then provide the right credentials
        client.getCredentialsProvider().setCredentials(new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT), new UsernamePasswordCredentials(username, buildToken));

        // Generate BASIC scheme object and stick it to the execution context
        BasicScheme basicAuth = new BasicScheme();
        BasicHttpContext context = new BasicHttpContext();
        context.setAttribute("preemptive-auth", basicAuth);

        // Add as the first (because of the zero) request interceptor
        // It will first intercept the request and preemptively initialize the
        // authentication scheme if there is not
        client.addRequestInterceptor(new PreemptiveAuth(), 0);

        // You get request that will start the build
        String jobUrl;
        if (params == null || params.isEmpty()) {
            jobUrl = jenkinsUrl + "/build?token=" + buildToken;

        } else {
            jobUrl = jenkinsUrl + "/buildWithParameters?token=" + buildToken;

            for (Map.Entry<String, String> entry : params.entrySet()) {
                jobUrl += "&" + entry.getKey() + "=" + entry.getValue();
            }
        }

        System.out.println("Jenkins job build URL:" + jobUrl);

        HttpPost postObj = new HttpPost(jobUrl);

        try {
            // Execute your request with the given context
            HttpResponse response = client.execute(postObj, context);
            System.out.println("Jenkins job build Response status:" + response.getStatusLine().getStatusCode());
            HttpEntity entity = response.getEntity();
            EntityUtils.consume(entity);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Preemptive authentication interceptor
     */
    static class PreemptiveAuth implements HttpRequestInterceptor {

        public void process(HttpRequest request, HttpContext context) throws HttpException, IOException {
            // Get the AuthState
            AuthState authState = (AuthState) context.getAttribute(ClientContext.TARGET_AUTH_STATE);

            // If no auth scheme available yet, try to initialize it
            // preemptively
            if (authState.getAuthScheme() == null) {
                AuthScheme authScheme = (AuthScheme) context.getAttribute("preemptive-auth");
                CredentialsProvider credsProvider = (CredentialsProvider) context.getAttribute(ClientContext.CREDS_PROVIDER);
                HttpHost targetHost = (HttpHost) context.getAttribute(ExecutionContext.HTTP_TARGET_HOST);
                if (authScheme != null) {
                    Credentials creds = credsProvider.getCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()));
                    if (creds == null) {
                        throw new HttpException("No credentials for preemptive authentication");
                    }
                    authState.setAuthScheme(authScheme);
                    authState.setCredentials(creds);
                }
            }

        }

    }
}
