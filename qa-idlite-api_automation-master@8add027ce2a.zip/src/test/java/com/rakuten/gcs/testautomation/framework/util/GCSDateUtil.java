package com.rakuten.gcs.testautomation.framework.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * 日付に関するユーティリティです。
 *
 * @author ts-shinji.iwasaki
 */
public class GCSDateUtil {

    /** Date Pattern(日付パターン) ： yyyy年M月d日 */
    public static final String NENGAPPI = "yyyy年M月d日";
    /** Date Pattern(日付パターン) ： yyyy/M */
    public static final String NENGAPPI_YYYYM = "yyyy/M";
    /** Date Pattern(日付パターン) ： yyyy/MM */
    public static final String NENGAPPI_YYYYMM = "yyyy/MM";
    /** Date Pattern(日付パターン) ： yyyy/M/d */
    public static final String NENGAPPI_YYYYMD = "yyyy/M/d";
    /** Date Pattern(日付パターン) ： yyyy/MM/dd */
    public static final String NENGAPPI_YYYYMMDD = "yyyy/MM/dd";
    /** Date Pattern(日付パターン) ： yyyy年M月d日 HH:mm */
    public static final String NENGAPPI_TIME = "yyyy年M月d日 HH:mm";
    /** Date Pattern(日付パターン) ： yyyy/M/d/ HH:mm */
    public static final String NENGAPPI_M_TIME = "yyyy/M/d HH:mm";
    /** Date Pattern(日付パターン) ： M月d日 */
    public static final String GAPPI = "M月d日";
    /** Date Pattern(日付パターン) ： MM/dd */
    public static final String MM_DD = "MM/dd";
    /** Date Pattern(日付パターン) ： MM/dd */
    public static final String M_D = "M/d";
    /** Date Pattern(日付パターン) ： yyyyMMdd */
    public static final String YYYYMMDD = "yyyyMMdd";
    /** Date Pattern(日付パターン) ： yyyy/MM/dd */
    public static final String YYYY_MM_DD_SLASH = "yyyy/MM/dd";
    /** Date Pattern(日付パターン) ： yyyy-MM */
    public static final String YYYY_MM = "yyyy-MM";
    /** Date Pattern(日付パターン) ： yyyyMM */
    public static final String YYYYMM = "yyyyMM";
    /** Date Pattern(日付パターン) ： yyyy */
    public static final String YYYY = "yyyy";
    /** Date Pattern(日付パターン) ： M */
    public static final String M = "M";
    /** Date Pattern(日付パターン) ： MM */
    public static final String MM = "MM";
    /** Date Pattern(日付パターン) ： d */
    public static final String D = "d";
    /** Date Pattern(日付パターン) ： dd */
    public static final String DD = "dd";
    /** Date Pattern(日付パターン) ： yyyy-MM-dd-HH-mm-ss */
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd-HH-mm-ss";
    /** Date Pattern(日付パターン) ： yyyy/MM/dd HH:mm:ss */
    public static final String YYYY_MM_DD_HH_MM_SS_2 = "yyyy/MM/dd HH:mm:ss";
    /** Date Pattern(日付パターン) ： yyyy-MM-dd */
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    /** Date Pattern(日付パターン) : yyyy-MM-dd HH:mm:ss */
    public static final String YYYY_MM_DD_HH_MM_SS_3 = "yyyy-MM-dd HH:mm:ss";
    /** Date Pattern(日付パターン) ： yyyyMMddHHmmssSSS */
    public static final String YYYYMMDDHHMMSSSSS = "yyyyMMddHHmmssSSS";
    /** Date Pattern(日付パターン) ： yyyyMMddHHmmss */
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    /** Date Pattern(日付パターン) ： yyMMddHHmmss */
    public static final String YYMMDDHHMMSS = "yyMMddHHmmss";
    /** Date Pattern(日付パターン) ： yyMM */
    public static final String YYMM = "yyMM";
    /** Date Pattern(日付パターン) ： yyMMdd */
    public static final String YYMMDD = "yyMMdd";
    /** Date Pattern(日付パターン) ： yyMMddHHmm */
    public static final String YYMMDDHHMM = "yyMMddHHmm";
    /** Date Pattern(日付パターン) ： yy/MM/dd */
    public static final String YY_MM_DD_SLASH = "yy/MM/dd";
    /** Date Pattern(日付パターン) : yyyy-MM-dd'T'HH:mm:ss */
    public static final String YYYY_MM_DD_T_HH_MM_SS_3 = "yyyy-MM-dd'T'HH:mm:ss";
    /** Date Pattern(日付パターン) : yyyyMMddHHmm */
    public static final String YYYYMMDDHHMM = "yyyyMMddHHmm";
    /** Date Pattern(日付パターン) ： HH:MM:ss */
    public static final String HHMMSS = "HH:mm:ss";

    private static final long ONE_DATE_TIME_MILLIS = 1000 * 60 * 60 * 24;

    /** new()インスタンス生成抑止 */
    private GCSDateUtil() {
    }

    /**
     * The time now（Date Type）(現在日時取得 （Date型）)
     *
     * @return Date Time（Date Type）(日時 （Date型）)
     */
    public static Date getDate() {
        return new Date(System.currentTimeMillis());
    }

    /**
     * The time now（Calendar Type）(現在日時取得 （Calendar型）)
     *
     * @return Date Time（Calendar Type）(日時 （Calendar型）)
     */
    public static Calendar getCalendar() {
        return Calendar.getInstance(TimeZone.getDefault());
    }

    /**
     * Change date type to string type(「Date型 ⇒ String型」変換)
     *
     * @param date
     *            Date Time(Date Type)(日付 （Date型）)
     * @param pattern
     *            パターン
     * @return Date Time(String Type)(日付 （String型）)
     */
    public static String toString(Date date, String pattern) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(date);
    }

    /**
     * Change date type to string type(「Date型 ⇒ String型」変換)
     *
     * @param date
     *            Date Time(Date Type)(日付 （Date型）)
     * @param pattern
     *            パターン
     * @param timezone
     *            タイムゾーン
     * @return Date Time(String Type)(日付 （String型）)
     */
    public static String toString(Date date, String pattern, TimeZone timezone) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        sdf.setTimeZone(timezone);
        return sdf.format(date);
    }

    /**
     * Change string type to date type(「String型 ⇒ Date型」変換)
     *
     * @param date
     *            Date Time(String Type)(日付 （String型）)
     * @param pattern
     *            パターン
     * @return Date Time(Date Type)(日付 （Date型）)
     */
    public static Date toDate(String date, String pattern) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        sdf.setLenient(false);
        try {
            return sdf.parse(date);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Change string type to date type(「String型 ⇒ Date型」変換)
     *
     * @param date
     *            Date Time(String Type)(日付 （String型）)
     * @param pattern
     *            パターン
     * @param timezone
     *            タイムゾーン
     * @return Date Time(Date Type)(日付 （Date型）)
     */
    public static Date toDate(String date, String pattern, TimeZone timezone) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        sdf.setTimeZone(timezone);
        sdf.setLenient(false);
        try {
            return sdf.parse(date);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Add date(日付加算)
     *
     * @param date
     *            日付
     * @param field
     *            フィールド （Calendar.YEARなど、Calendar定数）
     * @param amount
     *            加算量
     * @return Date after add a date(加算後日付)
     */
    public static Date add(Date date, int field, int amount) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(field, amount);
        return cal.getTime();
    }

    /**
     * Change date type to string type(「Date型 ⇒ String型」変換 （MySQL DATETIME型）)
     *
     * @param date
     *            日付 （Date型）
     * @param pattern
     *            パターン
     * @return Date Time(String Type)日付 （String型）)
     */
    public static String toStringMySqlDateTime(Date date) {
        return toString(date, YYYY_MM_DD_HH_MM_SS_3);
    }

    /**
     * change JST to UTC(UTCの日付に変換する)
     *
     * @param orgDate
     *            JST Date(元の日付（日本時間）)
     * @return UTC Date(UTCの日付)
     * @throws Exception
     */
    public static Date toUtcDate(Date orgDate) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(orgDate);
        cal.add(Calendar.MILLISECOND, cal.get(Calendar.ZONE_OFFSET) * -1);
        return new Date(cal.getTimeInMillis());

    }

    /**
     * change UTC to JST(日本時間の日付に変換する)
     *
     * @param orgDate
     *            UTCの日付 【注意】Date型のTimeZoneは日本であること
     * @return JST Date(日本時間の日付)
     * @throws Exception
     */
    public static Date toJpnDate(Date orgDate) throws Exception {
        Calendar cal = Calendar.getInstance();
        cal.setTime(orgDate);
        cal.add(Calendar.MILLISECOND, cal.get(Calendar.ZONE_OFFSET));
        return new Date(cal.getTimeInMillis());
    }

    /**
     * Calculate the date difference between the number of days(日付の差が何日あるかを算出して返す。)
     *
     * @param from
     * @param to
     * @return difference between the number of days(差(日数))
     */
    public static long difference(Date from, Date to) {
        if (from == null || to == null) {
            return -1;
        }
        if (from.getTime() > to.getTime()) {
            return -1;
        }
        long diff = (to.getTime() - from.getTime()) / ONE_DATE_TIME_MILLIS;
        return diff;
    }

}
