package com.rakuten.gcs.testautomation.framework.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class GCSFileUtils {

    final static Log logger = LogFactory.getLog(GCSFileUtils.class);

    /**
     * Created and write a csv file.
     * 
     * @param csvName file name
     * @param csvPath file path
     * @param contentList content of csv file
     * @throws IOException
     */
    public static void createAndWriteCsvFile(String csvName, String csvPath, List<List<String>> contentList) throws IOException {
        logger.info("Start write csv file!");

        File path = new File(csvPath);
        if (!path.exists()) {
            path.mkdirs();
        }

        File file = new File(path, csvName);
        if (file.exists()) {
            file.delete();
        }
        file.createNewFile();

        List<String[]> arrList = new ArrayList<String[]>();
        for (List<String> row : contentList) {
            arrList.add(row.toArray(new String[row.size()]));
        }

        CSVWriter writer = new CSVWriter(new FileWriter(file), ',');
        writer.writeAll(arrList);
        writer.close();
        logger.info("Start write csv file!");
    }

    /**
     * Read a csv file.
     * 
     * @param csvName
     * @param csvPath
     * @return if file is not exists , return null.
     * @throws IOException
     */
    public static List<List<String>> readCsvFile(String csvName, String csvPath) throws IOException {
        logger.info("Start read csv file!");

        File path = new File(csvPath);
        if (!path.exists()) {
            logger.info("csvPath:" + csvPath + " not exists!");
            return null;
        }

        File file = new File(path, csvName);
        if (!file.exists()) {
            logger.info("csvfile:" + csvName + " not exists!");
            return null;
        }

        CSVReader reader = new CSVReader(new FileReader(file.getAbsoluteFile()));
        List<String[]> arrList = reader.readAll();

        List<List<String>> fileList = new ArrayList<List<String>>();
        for (String[] row : arrList) {
            fileList.add(Arrays.asList(row));
        }

        reader.close();
        logger.info("End read csv file!");
        return fileList;
    }

    /**
     * Created and write in txt file.
     * 
     * @param txtName file name
     * @param txtPath file path
     * @param contentsList
     * @throws IOException
     */
    public static void createAndWriteTxtFile(String txtName, String txtPath, List<String> contentsList) throws IOException {
        logger.info("Start write text file!");

        File path = new File(txtPath);
        if (!path.exists()) {
            path.mkdirs();
        }

        File file = new File(path, txtName);
        if (file.exists()) {
            file.delete();
        }
        file.createNewFile();

        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);

        for (String row : contentsList) {
            bw.write(row);
            bw.newLine();
            bw.flush();
        }

        bw.close();
        fw.close();
        logger.info("End write text file!");
    }

    /**
     * Read file as text.
     * 
     * @param txtName file name
     * @param txtPath file path
     * @return Return file content as List. If file not exists , return null.
     * @throws IOException
     */
    public static List<String> readTxtFile(String txtName, String txtPath) throws IOException {
        logger.info("Start read text file!");

        List<String> fileList = new ArrayList<String>();
        File path = new File(txtPath);
        if (!path.exists()) {
            logger.info("file path:" + txtPath + " not exists!");
            return null;
        }

        File file = new File(path, txtName);
        if (!file.exists()) {
            logger.info("text file:" + txtName + " not exists!");
            return null;
        }

        BufferedReader reader = new BufferedReader(new FileReader(file.getAbsoluteFile()));
        String line = null;
        while ((line = reader.readLine()) != null) {
            fileList.add(line);
        }

        reader.close();
        logger.info("End write text file!");
        return fileList;
    }
}