package com.rakuten.gcs.testautomation.framework.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

/**
 * String utility(文字列ユーティリティ)
 * 
 * @author ts-hiroshi.kurokawa
 * @author ts-yuichi.ichimura
 */
public class GCSStringUtil {

    /** Regular expression - FULL_WIDTH_CHAR(正規表現 - 全角文字) */
    private static final Pattern FULL_WIDTH_CHAR = Pattern.compile("^[^ -~｡-ﾟ]*$");
    /** Regular expression - HALF_WIDTH_CHAR(正規表現 - 半角文字) */
    private static final Pattern HALF_WIDTH_CHAR = Pattern.compile("^[ -~｡-ﾟ]*$");

    /** Decimal format - 9 after the decimal point(小数フォーマット - 小数９桁) */
    private static final DecimalFormat DECIMAL_FMT_09 = new DecimalFormat("#.#########");
    /** Decimal format - 10 after the decimal point(小数フォーマット - 小数１０桁) */
    private static final DecimalFormat DECIMAL_FMT_10 = new DecimalFormat("#.##########");

    private static final char[] NARROW_LOWER_KANA = { 'ｧ', 'ｨ', 'ｩ', 'ｪ', 'ｫ', 'ｬ', 'ｭ', 'ｮ', 'ｯ' };
    private static final char[] NARROW_UPPER_KANA = { 'ｱ', 'ｲ', 'ｳ', 'ｴ', 'ｵ', 'ﾔ', 'ﾕ', 'ﾖ', 'ﾂ' };

    private static final char VOICED_SOUND_MARK = '゛';
    private static final char SEMI_VOICED_SOUND_MARK = '゜';
    private static final String SPACE = "　| ";

    private static final Map<Character, Character> HALF_TO_FULL_WIDTH_SING_MAP;
    private static final Map<Character, Character> HALF_TO_FULL_WIDTH_KATAKANA_MAP;
    private static final Map<Character, Character> UPPER_KATAKANA_MAP;
    private static final Map<Character, Character> FULL_WIDTH_HYPEN_MINUS_MAP;

    static {
        HALF_TO_FULL_WIDTH_SING_MAP = new HashMap<Character, Character>();
        HALF_TO_FULL_WIDTH_SING_MAP.put('(', '（');
        HALF_TO_FULL_WIDTH_SING_MAP.put(')', '）');
        HALF_TO_FULL_WIDTH_SING_MAP.put(',', '，');
        HALF_TO_FULL_WIDTH_SING_MAP.put('/', '／');
        HALF_TO_FULL_WIDTH_SING_MAP.put('\\', '￥');
        HALF_TO_FULL_WIDTH_SING_MAP.put('｢', '「');
        HALF_TO_FULL_WIDTH_SING_MAP.put('｣', '」');

        HALF_TO_FULL_WIDTH_KATAKANA_MAP = new HashMap<Character, Character>();
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｱ', 'ア');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｲ', 'イ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｳ', 'ウ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｴ', 'エ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｵ', 'オ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｶ', 'カ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｷ', 'キ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｸ', 'ク');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｹ', 'ケ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｺ', 'コ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｻ', 'サ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｼ', 'シ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｽ', 'ス');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｾ', 'セ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｿ', 'ソ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾀ', 'タ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾁ', 'チ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾂ', 'ツ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾃ', 'テ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾄ', 'ト');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾅ', 'ナ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾆ', 'ニ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾇ', 'ヌ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾈ', 'ネ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾉ', 'ノ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾊ', 'ハ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾋ', 'ヒ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾌ', 'フ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾍ', 'ヘ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾎ', 'ホ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾏ', 'マ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾐ', 'ミ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾑ', 'ム');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾒ', 'メ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾓ', 'モ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾔ', 'ヤ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾕ', 'ユ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾖ', 'ヨ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾗ', 'ラ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾘ', 'リ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾙ', 'ル');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾚ', 'レ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾛ', 'ロ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾜ', 'ワ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｦ', 'ヲ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾝ', 'ン');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｧ', 'ア');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｨ', 'イ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｩ', 'ウ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｪ', 'エ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｫ', 'オ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｬ', 'ヤ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｭ', 'ユ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｮ', 'ヨ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｯ', 'ツ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ｰ', 'ー');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾞ', '゛');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ﾟ', '゜');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ヰ', 'イ');
        HALF_TO_FULL_WIDTH_KATAKANA_MAP.put('ヱ', 'エ');

        UPPER_KATAKANA_MAP = new HashMap<Character, Character>();
        UPPER_KATAKANA_MAP.put('ｧ', 'ｱ');
        UPPER_KATAKANA_MAP.put('ｨ', 'ｲ');
        UPPER_KATAKANA_MAP.put('ｩ', 'ｳ');
        UPPER_KATAKANA_MAP.put('ｪ', 'ｴ');
        UPPER_KATAKANA_MAP.put('ｫ', 'ｵ');
        UPPER_KATAKANA_MAP.put('ｬ', 'ﾔ');
        UPPER_KATAKANA_MAP.put('ｭ', 'ﾕ');
        UPPER_KATAKANA_MAP.put('ｮ', 'ﾖ');
        UPPER_KATAKANA_MAP.put('ｯ', 'ﾂ');
        UPPER_KATAKANA_MAP.put('ァ', 'ア');
        UPPER_KATAKANA_MAP.put('ィ', 'イ');
        UPPER_KATAKANA_MAP.put('ゥ', 'ウ');
        UPPER_KATAKANA_MAP.put('ェ', 'エ');
        UPPER_KATAKANA_MAP.put('ォ', 'オ');
        UPPER_KATAKANA_MAP.put('ャ', 'ヤ');
        UPPER_KATAKANA_MAP.put('ュ', 'ユ');
        UPPER_KATAKANA_MAP.put('ョ', 'ヨ');

        UPPER_KATAKANA_MAP.put('ッ', 'ツ');
        UPPER_KATAKANA_MAP.put('ヮ', 'ワ');
        UPPER_KATAKANA_MAP.put('ヵ', 'カ');
        UPPER_KATAKANA_MAP.put('ヶ', 'ケ');

        FULL_WIDTH_HYPEN_MINUS_MAP = new HashMap<Character, Character>();
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u30FC', '\uFF0D'); // Long tone[ー] U+30FC(長音[ー] U+30FC)
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u002D', '\uFF0D'); // HALF_WIDTH_Hyphen(minus)[-](半角ハイフン(マイナス)[-])
                                                           // U+002D
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2010', '\uFF0D'); // FULL_WIDTH_Hyphen[‐] U+2010(全角ハイフン[‐] U+2010)
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\uFF70', '\uFF0D'); // HALF_WIDTH_Katakana of long[ｰ](半角カタカナの長音[ｰ])
                                                           // U+FF70
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2011', '\uFF0D'); // NON-BREAKING
                                                           // HYPHEN[‑] U+2011
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2012', '\uFF0D'); // FIGURE DASH[‒]
                                                           // U+2012
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2013', '\uFF0D'); // EN DASH[–] U+2013
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2014', '\uFF0D'); // EM DASH[—] U+2014
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2015', '\uFF0D'); // HORIZONTAL BAR[―]
                                                           // U+2015
        FULL_WIDTH_HYPEN_MINUS_MAP.put('\u2212', '\uFF0D'); // MINUS SIGN[−]
                                                           // U+2212
    }

    /**
     * Empty words check(also empty handling null)(空文字チェック （nullも空文字扱い）)
     * 
     * @param input
     *            Determination target string(判定対象文字列)
     * @param trim
     *            Trim implementation necessity （true : trim、false : Not trim）(トリム実施要否 （true : トリムする、false : トリムしない）)
     * @return judgment result(判定結果)
     */
    public static boolean isEmpty(String input, boolean trim) {

        if (input == null) {
            return true;
        }

        if (trim) {
            input = input.trim();
        }

        if (input.length() == 0) {
            return true;
        }

        return false;
    }

    /**
     * Empty words check(also empty handling null): Trim implementation fixed(空文字チェック （nullも空文字扱い） : トリム実施固定)
     * 
     * @param input
     *            Determination target string(判定対象文字列)
     * @return judgment result(判定結果)
     */
    public static boolean isEmpty(String input) {
        return isEmpty(input, true);
    }

    /**
     * Returns the length of the string(null returns 0)(文字列の数を返す（nullも空文字扱い）)
     * 
     * @param str
     * @return
     */
    public static int length(final String str) {
        return ((str == null) ? 0 : str.length());
    }

    /**
     * 「Date->String」Type conversion return null when null(「Date->String」型変換 ※ nullの場合はそのまま)
     * 
     * @param arg
     *            Converted time stamp(変換対象タイムスタンプ)
     * @return Conversion after's string(変換後文字列)
     */
    public static String dateToString(Date arg) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        return arg == null ? null : sdf.format(arg);
    }

    /**
     * The null character string is converted into empty(「null⇒空文字」変換)
     * 
     * @param s
     *            String before conversion(変換前文字列)
     * @return String after conversion(変換後文字列)
     */
    public static String nullToBlank(String s) {
        return s == null ? "" : s;
    }

    /**
     * 「Integer->String」Type conversion return null when null(「Integer->String」型変換 ※ nullの場合はそのまま)
     * 
     * @param arg
     *            Integer before conversion(変換前文字列)変換対象Integer
     * @return String after conversion(変換後文字列)
     */
    public static String integerToString(Integer arg) {
        return arg == null ? null : String.valueOf(arg);
    }

    /**
     * 「Byte->String」Type conversion return null when null(「Byte->String」型変換 ※ nullの場合はそのまま)
     * 
     * @param arg
     *            Byte before conversion(変換前文字列)変換対象Byte
     * @return String after conversion(変換後文字列)
     */
    public static String byteToString(Byte arg) {
        return arg == null ? null : String.valueOf(arg);
    }

    /**
     * 「String -> Integer」 ※return null when null, In addition to digital returns null
     * (「String -> Integer」 ※ nullの場合はそのまま 数字以外の文字列が渡された場合ははnullを返す。)
     * 
     * @param str
     * @return
     */
    public static Integer stringToInteger(String str) {
        Integer result = null;
        try {
            result = (str == null ? null : Integer.valueOf(str));
        } catch (Exception e) {
        }
        return result;
    }

    /**
     * 「BigDecimal->String」Type conversion 9 after the decimal point return null when null
     * (「BigDecimal->String」型変換(小数9桁) ※ nullの場合はそのまま)
     * 
     * @param arg
     *            BigDecimal before conversion(変換対象BigDecimal)
     * @return String after conversion(変換後文字列)
     */
    public static String bigDecimalToString_9(BigDecimal arg) {
        return arg == null ? null : DECIMAL_FMT_09.format(arg);
    }

    /**
     * 「BigDecimal->String」Type conversion 10 after the decimal point return null when null
     * (「BigDecimal->String」型変換(小数10桁) ※ nullの場合はそのまま)
     * 
     * @param arg
     *            BigDecimal before conversion(変換対象BigDecimal)
     * @return String after conversion(変換後文字列)
     */
    public static String bigDecimalToString_10(BigDecimal arg) {
        return arg == null ? null : DECIMAL_FMT_10.format(arg);
    }

    /**
     * 「String -> Byte」※return null when null, In addition to digital returns null
     * (「String -> Byte」 ※ nullの場合はそのまま 数字以外の文字列が渡された場合ははnullを返す。)
     * 
     * @param str
     * @return
     */
    public static Byte stringToByte(String str) {
        Byte result = null;
        try {
            result = (str == null ? null : Byte.valueOf(str));
        } catch (Exception e) {
        }
        return result;
    }

    /**
     * 「String -> Long」 ※return null when null, In addition to digital returns null
     * (「String -> Long」 ※ nullの場合はそのまま 数字以外の文字列が渡された場合ははnullを返す。)
     * 
     * @param str
     * @return Long
     */
    public static Long stringToLong(String str) {
        Long result = null;
        try {
            result = (str == null) ? null : Long.valueOf(str);
        } catch (Exception e) {
        }
        return result;
    }

    /**
     * 「Long->String」Type conversion return null when null(「Long->String」型変換 ※ nullの場合はそのまま)
     * 
     * @param arg
     *            Long before conversion(変換対象Long)
     * @return String after conversion(変換後文字列)
     */
    public static String longToString(Long arg) {
        return arg == null ? null : String.valueOf(arg);
    }

    /**
     * fill 0 before the string(前0埋め。)
     * 
     * @param input
     *            processed string(処理対象文字列。)
     * @param length
     *            the length of the expected(O埋め後の桁数。)
     * @return the string of the expected(前0埋め後の文字列。)
     */
    public static String addFrontZero(String input, int length) {

        // when null change it to empty character strings(NULLは空文字に置き換える)
        if (input == null) {
            input = "";
        }

        String strBuf = input.trim();
        // length greater than or equal expectations length return string(長さが指定桁より長い場合はそのまま返す)
        if (strBuf.length() >= length) {
            return input;
        }

        while (strBuf.length() < length) {
            strBuf = "0" + strBuf;
        }
        return strBuf;
    }

    /**
     * delete 0 when it at the begin(前0削除。)
     * 
     * @param input
     *            processed string(処理対象文字列。)
     * @return the string has been deleted 0 when it at the begin(前0埋め後の文字列。)
     */
    public static String deleteFrontZero(String input) {
        if (input != null) {
            boolean loop = true;
            while (loop) {
                if (input.startsWith("0")) {
                    StringBuffer sb = new StringBuffer(input);
                    sb.delete(0, 1);
                    input = sb.toString();
                } else {
                    break;
                }
            }
        }
        return input;
    }

    /**
     * fill blank after the string(後ろスペース埋め。)
     * 
     * @param input
     *            processed string(処理対象文字列。)
     * @param length
     *            the length of the expected(スペース埋め後の桁数。)
     * @return the string of the expected(後ろスペース埋め後の文字列。)
     */
    public static String addEndSpace(String input, int length) {

        // when null change it to empty character strings(NULLは空文字に置き換える)
        if (input == null) {
            input = "";
        }

        String strBuf = input.trim();
        // length greater than or equal expectations length return string(長さが指定桁より長い場合はそのまま返す)
        if (strBuf.length() >= length) {
            return input;
        }

        StringBuffer sb = new StringBuffer(strBuf);
        for (int i = 0; i < (length - strBuf.length()); i++) {
            sb.append(" ");
        }
        return sb.toString();
    }

    /**
     * Check weather is full width char(全角判定)
     * 
     * @param arg
     *            対象文字列
     * @return 判定結果
     */
    public static boolean isFullWidthChar(String arg) {
        return FULL_WIDTH_CHAR.matcher(arg).matches();
    }

    /**
     * Check weather is half width char(半角判定)
     * 
     * @param arg
     *            target string(対象文字列)
     * @return the determination result(判定結果)
     */
    public static boolean isHalfWidthChar(String arg) {
        return HALF_WIDTH_CHAR.matcher(arg).matches();
    }

    /**
     * <PRE>
     * FULL_WIDTH_CHAR:2byte, HALF_WIDTHCHAR:1byte(バイト数をカウント。 全角文字：2byte、半角文字：1byteとして1文字づつカウントして結果を返す。)
     * 【注意】
     * UTF-8エンコード後の文字列だと、通常のString.getBytes()で全角文字が3byte換算されるため、
     * このような対応をしている。
     * UTF-8エンコードは、リクエストXML内に日本語などマルチバイト文字が含まれている場合の文字化け対応で、
     * 現状必須となっている。
     * </PRE>
     * 
     * @param arg
     *            target string(対象文字列)
     * @return number of bytes(バイト数)
     */
    public static int countBytes(String arg) {
        int cnt = 0;
        if (arg == null) {
            return cnt;
        }
        for (Character c : arg.toCharArray()) {
            if (isHalfWidthChar(c.toString())) {
                cnt += 1;
            } else {
                cnt += 2;
            }
        }
        return cnt;
    }

    /**
     * <PRE>
     * 指定文字数を超過する場合、文字列を指定文字数まで切り取って返却する。
     * 注意点。文字数で見ているため、2バイト文字を含む文字列をバイト数で切り取りたい場合は利用できない。
     * </PRE>
     * 
     * @param org
     *            target string(対象文字列)
     * @param roundLength
     *            max length(指定文字数)
     * @return the string of the expected(処理後文字列)
     */
    public static String roundSimpleString(String org, int roundLength) {
        if (GCSStringUtil.isEmpty(org)) {
            return "";
        } else if (org.length() <= roundLength) {
            return org;
        } else {
            return org.substring(0, roundLength);
        }
    }

    /**
     * string concatenation(指定したデリミタで文字列を結合)
     * 
     * @param delimiter
     * @param strings
     * @return
     */
    public static String getDelimitedString(final String delimiter, final String... strings) {
        return StringUtils.join(strings, delimiter);
    }

    /**
     * whether string is small HALF_WIDTH_Kana(半角カナ小文字判定)
     * 
     * @param c
     * @return
     */
    public static boolean isNarrowLowerKana(final char c) {
        return (c >= NARROW_LOWER_KANA[0] && c <= NARROW_LOWER_KANA[NARROW_LOWER_KANA.length - 1]);
    }

    /**
     * change small HALF_WIDTH_Kana to big HALF_WIDTH_Kana(「半角カナ小文字→半角カナ大文字」変換)
     * 
     * @param c
     * @return
     */
    public static char toNarrowUpperKana(final char c) {
        return isNarrowLowerKana(c) ? NARROW_UPPER_KANA[c - NARROW_LOWER_KANA[0]] : c;
    }

    /**
     * delete all the blank(半角スペース、全角スペースを取り除きます。)
     * 
     * @param str
     * @return
     */
    public static String replaceSpace(final String str) {
        if (isEmpty(str)) {
            return "";
        }
        return str.replaceAll(SPACE, "");
    }

    /**
     * 対象の横線記号を全角マイナス[－](U+FF0D)に変換します。 対象は以下のとおり。
     * 
     * <pre>
     * ・長音[ー] U+30FC
     * ・半角ハイフン(マイナス)[-] U+002D
     * ・全角ハイフン[‐] U+2010
     * ・半角カタカナの長音[ｰ] U+FF70
     * ・NON-BREAKING HYPHEN[‑] U+2011 ※1
     * ・FIGURE DASH[‒] U+2012 ※1
     * ・EN DASH[–] U+2013 ※1
     * ・EM DASH[—] U+2014 ※2
     * ・HORIZONTAL BAR[―] U+2015
     * ・MINUS SIGN[−] U+2212 ※3
     * </pre>
     * 
     * ※1 UTF-8のみ使用可能<br>
     * ※2 元の文字コードがSJIS/EUC-JP/ISO-2022-JPのダッシュ[U+2015]の場合、javaからの読込み時にU+2014
     * に置き換わる<br>
     * ※3 元の文字コードがSJIS/EUC-JP/ISO-2022-JPのマイナス記号[U+2212]の場合、javaからの読込み時にU+
     * FF0Dに置き換わる<br>
     * 
     * ※注意※：U+FF0DはUTF-8/Windows-31J/MS932でしか使用出来ません。<br>
     * 他の文字コードに変換する場合、そのままでは?になります。別の文字に置き換えが必要です。<br>
     * 
     * @param str
     * @return
     */
    public static String toFullWidthHypenMinus(final String str) {
        if (isEmpty(str)) {
            return "";
        }

        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < sb.length(); i++) {
            final char c = sb.charAt(i);
            if (FULL_WIDTH_HYPEN_MINUS_MAP.containsKey(c)) {
                sb.setCharAt(i, FULL_WIDTH_HYPEN_MINUS_MAP.get(c));
            }
        }
        return sb.toString();
    }

    /**
     * 全角ピリオドに変換します<br>
     * 対象は、半角ピリオド(.)、半角中点(･)、中点(・)
     * 
     * @param str
     * @return
     */
    public static String toFullWidthPeriod(final String str) {
        if (isEmpty(str)) {
            return "";
        }
        return str.replaceAll("\\.|･|・", "．");
    }

    /**
     * change string to Big_FULL_WIDTH_Alphabet(全角大文字の英字に変換します。)
     * 
     * @param str
     * @return
     */
    public static String toFullWidthAlphabet(final String str) {
        StringBuilder sb = new StringBuilder(str.toUpperCase());
        for (int i = 0; i < sb.length(); i++) {
            final char c = sb.charAt(i);
            if ('A' <= c && c <= 'Z') {
                sb.setCharAt(i, (char) (c - 'A' + 'Ａ'));
            }
        }
        return sb.toString();
    }

    /**
     * change string to FULL_WIDTH_Figure(全角数字に変換します。)
     * 
     * @param str
     * @return
     */
    public static String toFullWidthNum(final String str) {
        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < sb.length(); i++) {
            final char c = sb.charAt(i);
            if ('0' <= c && c <= '9') {
                sb.setCharAt(i, (char) (c - '0' + '０'));
            }
        }
        return sb.toString();
    }

    /**
     * change HALF_WIDTH_Symbols to FULL_WIDTH_Symbols(特定の半角記号を全角記号に変換します。)
     * 
     * @param str
     * @return
     */
    public static String toFullWidthSign(final String str) {
        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < sb.length(); i++) {
            final char c = sb.charAt(i);
            if (HALF_TO_FULL_WIDTH_SING_MAP.containsKey(c)) {
                sb.setCharAt(i, HALF_TO_FULL_WIDTH_SING_MAP.get(c));
            }
        }
        return sb.toString();
    }

    /**
     * change string to FULL_WIDTH_Katakana(全角カタカナに変換します。)
     * 
     * @param str
     * @return
     */
    public static String toFullWidthKatakana(final String str) {
        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < sb.length(); i++) {
            final char c = sb.charAt(i);
            if (HALF_TO_FULL_WIDTH_KATAKANA_MAP.containsKey(c)) {
                sb.setCharAt(i, HALF_TO_FULL_WIDTH_KATAKANA_MAP.get(c));
            }
        }
        return sb.toString();
    }

    /**
     * change small kana to big kana(「カナ小文字→カナ大文字」変換)
     * 
     * @param str
     * @return
     */
    public static String toUpperKana(final String str) {
        StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < sb.length(); i++) {
            final char c = sb.charAt(i);
            if (UPPER_KATAKANA_MAP.containsKey(c)) {
                sb.setCharAt(i, UPPER_KATAKANA_MAP.get(c));
            }
        }
        return sb.toString();
    }

    /**
     * 
     * 全角カタカナと後ろに出現する濁点と半濁点の2文字を、１文字に変換して返す。
     * 
     * @param str
     * @return
     */
    public static String mergeKatakanaVoicedSoundMark(final String str) {
        if (length(str) <= 1) {
            return str;
        } else {
            StringBuilder sb = new StringBuilder(str);
            for (int i = 1; i < sb.length(); i++) {
                final char targetChar = sb.charAt(i);

                if (VOICED_SOUND_MARK == targetChar || SEMI_VOICED_SOUND_MARK == targetChar) {
                    final char beforeChar = sb.charAt(i - 1);
                    final char mergedChar = mergeChar(beforeChar, targetChar);

                    if (beforeChar != mergedChar) {
                        sb.setCharAt(i - 1, mergedChar);
                        sb.deleteCharAt(i);
                    }
                }
            }
            return sb.toString();
        }
    }

    private static char mergeChar(final char c1, final char c2) {
        if (VOICED_SOUND_MARK == c2) {
            if ("カキクケコサシスセソタチツテトハヒフヘホウ".indexOf(c1) > -1) {
                switch (c1) {
                    case 'カ':
                        return 'ガ';
                    case 'キ':
                        return 'ギ';
                    case 'ク':
                        return 'グ';
                    case 'ケ':
                        return 'ゲ';
                    case 'コ':
                        return 'ゴ';
                    case 'サ':
                        return 'ザ';
                    case 'シ':
                        return 'ジ';
                    case 'ス':
                        return 'ズ';
                    case 'セ':
                        return 'ゼ';
                    case 'ソ':
                        return 'ゾ';
                    case 'タ':
                        return 'ダ';
                    case 'チ':
                        return 'ヂ';
                    case 'ツ':
                        return 'ヅ';
                    case 'テ':
                        return 'デ';
                    case 'ト':
                        return 'ド';
                    case 'ハ':
                        return 'バ';
                    case 'ヒ':
                        return 'ビ';
                    case 'フ':
                        return 'ブ';
                    case 'ヘ':
                        return 'ベ';
                    case 'ホ':
                        return 'ボ';
                    case 'ウ':
                        return 'ヴ';
                }
            }
        } else if (SEMI_VOICED_SOUND_MARK == c2) {
            if ("ハヒフヘホ".indexOf(c1) > -1) {
                switch (c1) {
                    case 'ハ':
                        return 'パ';
                    case 'ヒ':
                        return 'ピ';
                    case 'フ':
                        return 'プ';
                    case 'ヘ':
                        return 'ペ';
                    case 'ホ':
                        return 'ポ';
                }
            }
        }
        return c1;
    }

    /**
     * <p>
     * Removes double quote from both ends of this String, <br>
     * handling {@code null} by returning {@code null}.
     * </p>
     * 
     * <pre>
     * trimDoubleQuote(null)            = null
     * trimDoubleQuote("")              = ""
     * trimDoubleQuote(""")             = """
     * trimDoubleQuote("""")            = ""
     * trimDoubleQuote(""    "")        = "    "
     * trimDoubleQuote(""abc"")         = "abc"
     * trimDoubleQuote(""    abc    "") = "    abc    "
     * </pre>
     * 
     * @param str the String to be trimmed, may be null
     * @return the trimmed string, {@code null} if null String input
     */
    public static String trimDoubleQuote(String str) {
        if (str != null && str.length() >= 2 && str.matches("^\"(.*?)\"$")) {
            str = str.substring(1, str.length() - 1);
        }
        return str;
    }
}
