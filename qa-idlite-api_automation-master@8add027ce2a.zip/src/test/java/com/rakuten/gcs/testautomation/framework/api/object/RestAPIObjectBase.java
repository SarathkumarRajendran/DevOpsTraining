package com.rakuten.gcs.testautomation.framework.api.object;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.mashape.unirest.http.HttpMethod;
import com.mashape.unirest.http.HttpResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

public class RestAPIObjectBase extends APIObjectBase {

    final Log logger = LogFactory.getLog(RestAPIObjectBase.class);
    protected String route;
    protected Map<String, Object> fields;
    protected Map<String, File> files;
    protected Map<String, String> queryParams;
    protected Map<String, String> routeParams;
    protected String rawBody;

    protected Map<String, String> headers;
    protected Map<String, String> basicAuth;
    protected HttpMethod httpMethod;
    protected String version;

    public RestAPIObjectBase(String apiName) {
        fields = new HashMap<>();
        files = new HashMap<>();
        headers = new HashMap<>();
        queryParams = new HashMap<>();
        routeParams = new HashMap<>();
        basicAuth = new HashMap<>();
        this.apiName = apiName;
    }

    public RestAPIObjectBase(String apiName, HttpMethod httpMethod) {
        fields = new HashMap<>();
        files = new HashMap<>();
        headers = new HashMap<>();
        queryParams = new HashMap<>();
        routeParams = new HashMap<>();
        basicAuth = new HashMap<>();
        this.apiName = apiName;
        this.httpMethod = httpMethod;
    }

    public RestAPIObjectBase(String apiName, HttpMethod httpMethod, String route) {
        fields = new HashMap<>();
        files = new HashMap<>();
        headers = new HashMap<>();
        queryParams = new HashMap<>();
        routeParams = new HashMap<>();
        basicAuth = new HashMap<>();
        this.apiName = apiName;
        this.httpMethod = httpMethod;
        this.route = route;
    }

    public RestAPIObjectBase(String apiName, HttpMethod httpMethod, String route, String version) {
        fields = new HashMap<>();
        files = new HashMap<>();
        headers = new HashMap<>();
        queryParams = new HashMap<>();
        routeParams = new HashMap<>();
        basicAuth = new HashMap<>();
        this.apiName = apiName;
        this.httpMethod = httpMethod;
        this.route = route;
        this.version = version;
    }

    public void setHttpMethod(HttpMethod httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void addField(String parameterName, String value) {
        fields.put(parameterName, value);
    }

    public void addHeader(String parameterName, String value) {
        headers.put(parameterName, value);
    }

    public void addQueryParam(String parameterName, String value) {
        queryParams.put(parameterName, value);
    }

    public void addRouteParam(String parameterName, String value) {
        routeParams.put(parameterName, value);
    }

    public void addFile(String parameterName, File file) {
        files.put(parameterName, file);
    }

    public Map<String, Object> getFields() {
        return fields;
    }

    public Map<String, File> getFiles() {
        return files;
    }

    public Map<String, String> getQueryParams() {
        return queryParams;
    }

    public Map<String, String> getRouteParams() {
        return routeParams;
    }

    public void setRawBody(String rawBody) {
        this.rawBody = rawBody;
    }

    public String getRawBody() {
        return rawBody;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public HttpMethod getHttpMethod() {
        return httpMethod;
    }

    public void setBasicAuth(String username, String password) {
        if (this.basicAuth.size() != 0) {
            this.basicAuth.clear();
        }
        this.basicAuth.put(username, password);
    }

    public Map<String, String> getBasicAuth() {
        return basicAuth;
    }

    public String getResponseAsString() throws Exception {
        if (httpResponse == null) {
            throw new Exception("HTTP Request has not been made yet!");
        } else {
            HttpResponse<String> response = (HttpResponse<String>) httpResponse;
            return response.getBody();
        }
    }

    public String getJSONResponseByJSONPath(String jsonPath) throws Exception {
        String json = this.getResponseAsString();
        Object document = Configuration.defaultConfiguration().jsonProvider().parse(json);
        return String.valueOf(JsonPath.read(document, jsonPath));
    }

    public String getXMLResponseByXPath(String xpathExpression) throws Exception {
        Document doc = this.getResponseAsXmlObject();
        XPathFactory xPathfactory = XPathFactory.newInstance();
        XPath xpath = xPathfactory.newXPath();
        XPathExpression expr = xpath.compile(xpathExpression);
        return String.valueOf(expr.evaluate(doc, XPathConstants.STRING));
    }

    public int getHttpStatus() throws Exception {
        if (httpResponse == null) {
            throw new Exception("HTTP Request has not been made yet!");
        } else {
            HttpResponse<String> response = (HttpResponse<String>) httpResponse;
            return response.getStatus();
        }
    }

    final public Document getResponseAsXmlObject() throws Exception {
        try {
            String xml = getResponseAsString();
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new InputSource(new StringReader(xml)));
            doc.getDocumentElement().normalize();
            return doc;
        } catch (Exception e) {
            logger.error("Unable to get XML from this string " + getResponseAsString());
            throw e;
        }
    }
}
