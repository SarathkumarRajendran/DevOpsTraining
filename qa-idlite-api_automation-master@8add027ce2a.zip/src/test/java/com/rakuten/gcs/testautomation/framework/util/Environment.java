package com.rakuten.gcs.testautomation.framework.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by aldosuwandi on 12/6/16.
 */
public class Environment {

    private ClassLoader classLoader = getClass().getClassLoader();

    private Properties properties;

    final static Log logger = LogFactory.getLog(Environment.class);

    private static Environment instance = null;

    public static Environment getInstance(String configFile) {
        if (instance == null) {
            try {
                instance = new Environment(configFile);
            } catch (IOException e) {
                logger.error("Unable to find " + configFile + " trying to read from env variable");
                instance = new Environment();
            }
        }
        return instance;
    }

    private Environment() {
    };

    private Environment(String configFile) throws IOException {
        properties = new Properties();
        InputStream inputStream = null;
        inputStream = new FileInputStream(new File(classLoader.getResource(configFile).getFile()));
        properties.load(inputStream);
    }

    public String getProperty(String key) {
        String result = null;
        if (this.properties != null) {
            result = this.properties.getProperty(key);
        }
        if (result == null) {
            return Property.get(key);
        } else {
            return result;
        }
    }

    public String getPropertyOrDefault(String key, String defaultValue) {
        String value = this.getProperty(key);
        if (value != null && !value.isEmpty()) {
            return this.getProperty(key);
        } else {
            return defaultValue;
        }
    }
}
