package com.rakuten.gcs.testautomation.framework.api;

import org.apache.commons.lang3.text.WordUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

/**
 * Created by aldo.suwandi on 2015/08/24.
 */

public abstract class SoapAPIObjectBase {

    final static Log logger = LogFactory.getLog(SoapAPIObjectBase.class);

    protected String endpointURL;

    protected SOAPMessage soapMessage;

    private SOAPPart soapPart;

    private SOAPEnvelope envelope;

    protected SOAPBody soapRequestBody;

    protected SOAPBody soapResponseBody;

    protected String operatorName;

    protected SOAPElement rootElement;

    private String actionUrl;

    public SoapAPIObjectBase() throws MalformedURLException, SOAPException {
        prepareSoapRequestMessage();
        this.soapRequestBody = this.envelope.getBody();
    }

    public SOAPEnvelope getEnvelope() {
        return envelope;
    }

    public void addNamespaceDeclaration(String soap, String s) throws SOAPException {
        this.getEnvelope().addNamespaceDeclaration(soap, s);
        this.actionUrl = s;
    }

    private SOAPMessage makeSoapMessage() throws SOAPException, IOException {
        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", actionUrl + getOperatorName());
        soapMessage.saveChanges();
        logger.info("\n----------------------BEGIN REQUEST ENVELOPE-----------------------\n" + SoapAPIClient.getSOAPMessageAsString(soapMessage) + "\n-----------------------END REQUEST ENVELOPE------------------------\n");
        return soapMessage;
    }

    public SOAPBody getSoapRequestBody() {
        return soapRequestBody;
    }

    public void setRootElement(String rootElementName, String nameSpace) throws SOAPException {
        this.rootElement = this.getSoapRequestBody().addChildElement(rootElementName, nameSpace);
    }

    public SOAPElement getRootElement() {
        return this.rootElement;
    }

    public SOAPBody getSoapResponseBody() {
        return soapResponseBody;
    }

    public void addSoapParameterWithValue(String name, String value) throws SOAPException {
        this.getRootElement().addChildElement(name).addTextNode(value);
    }

    public String getResponseValueFromFirstElement(String localName) throws Exception {
        try {
            return this.getSoapResponseBody().getElementsByTagName(localName).item(0).getTextContent();
        } catch (NullPointerException ex) {
            logger.error("Element tag not found");
            throw new Exception("Element tag not found", ex);
        }
    }

    public void executeSoapApi(SoapAPIClient soapApiClient) throws SOAPException, IOException {
        this.soapResponseBody = soapApiClient.createSoapRequest(endpointURL, makeSoapMessage());
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public void setEndpointURL(String endpointURL) {
        this.endpointURL = endpointURL;
    }

    private void prepareSoapRequestMessage() throws SOAPException {
        MessageFactory messageFactory = MessageFactory.newInstance();
        soapMessage = messageFactory.createMessage();
        soapPart = soapMessage.getSOAPPart();
        envelope = soapPart.getEnvelope();
    }

    public void addNewNode(String name) throws SOAPException {
        this.soapRequestBody.addChildElement(name);
    }

}
