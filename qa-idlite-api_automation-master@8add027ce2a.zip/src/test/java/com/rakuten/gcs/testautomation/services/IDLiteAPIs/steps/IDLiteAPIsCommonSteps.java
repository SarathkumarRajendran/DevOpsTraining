package com.rakuten.gcs.testautomation.services.IDLiteAPIs.steps;

import java.net.URLEncoder;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpHost;
import org.junit.Assert;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.http.utils.Base64Coder;
import com.rakuten.gcs.testautomation.services.IDLiteAPIs.runtest.IDLiteAPIs_RunTest;
import com.rakuten.gcs.testautomation.services.IDLiteAPIs.utils.JsonUtils;
import com.rakuten.gcs.testautomation.services.testrail.SharedStorage;
import com.rakuten.gcs.testautomation.services.testrail.CommonModel;
import com.rakuten.gcs.testautomation.services.testrail.TestRailIntegrationClient;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.sf.json.JSONObject;

public class IDLiteAPIsCommonSteps {


	final static Log logger = LogFactory.getLog(IDLiteAPIsCommonSteps.class);

	private String jsonPath = "src/test/resources/com/rakuten/gcs/testautomation/services/IDLiteAPI/json/";

	// request
	private String requestBody;

	// proxy
	private String proxy_host;
	private int proxy_port;

	// endpoint
	private String endpoint_idLite;
	private String endpoint_rid_stg;
	private String endpoint_omniClient;
	private String endpoint_IDLiteAPIClient;
	private String endpoint_akita;
	private String endpoint_cat;
	private String endpoint_rid;
	private String fakeProviderUrl;
	private String fakeProvider02Url;
	private String deactivation_Url;

	// authorization
	private String authorization_viber_stg;
	private String authorization_blackbox_stg;
	private String authorization_message_stg;
	private String authorization_provider;
	private String authorization_idLite;
	private String authorizatioin_rid;

	// response
	private HttpResponse<String> postRes;

	private String memberUuid;
	private String memberUUID_idlite;
	private String memberId;
	private String email;
	private String easyId;
	private String authToken;
	private String migrationToken;
	private String masterToken;
	private String refreshToken;
	private String exchangeToken;
	private String exchangeToken_akita;
	private String exchangeToken_idlite;
	private String exchangeToken_idlite_idliteAPI;
	private String exchangeToken_ridAudience;
	private String OTP;
	private String idToken;
	private String subject;
	private String foreignId;
	private String foreignId_1;
	private String generateForeignId;
	private String generatefakeProviderPhone;
	private String generatefakeProviderEmail;
	private String easyId_idlite1;
	private String ridEmail;
	private String idlitetoFullemail;
	
	private String provider01_Phone;
	private String provider01_Name;
	private long rid_Phone;
	
	//decode and encode variables
		private String base64DecodedHeader;
		private String base64DecodedBody;
		private String base64DecodedSignature;	
		private String base64EncodedHeader;
		private String base64EncodedBody;
		private String base64EncodedSignature;	
		private String jwtHeader;
		private String jwtpayloadbody;
		private String jwtSignature;
		
	@Before
	public void setUp() {

		// TODO get proxy from environment variable.
		if (System.getenv("DEV_PROXY_HOST") != null) {
			this.proxy_host = System.getenv("DEV_PROXY_HOST");
		} else {
			this.proxy_host = "dev-proxy.db.rakuten.co.jp";
		}
		if (System.getenv("DEV_PROXY_PORT") != null) {
			this.proxy_port = Integer.parseInt(System.getenv("DEV_PROXY_PORT"));
		} else {
			this.proxy_port = 9502;
		}
		
		// TODO get endpoint from environment variable
		if (System.getenv("env_IDLite") != null) {
			this.endpoint_idLite = System.getenv("env_IDLite");
		} else {
			this.endpoint_idLite = "https://qa.idlite.gipdog.net/";
		}
		
		
		if (System.getenv("env_CAT") !=null)
        {
        	this.endpoint_IDLiteAPIClient = System.getenv("env_CAT");
        	logger.info("end point : "+endpoint_IDLiteAPIClient);
        }
        else {
        	this.endpoint_IDLiteAPIClient = "http://localhost:9090/api/v1/";
        	this.endpoint_omniClient = "http://localhost:9070/api/v1/";
        }
        
        
		if (System.getenv("env_RID") != null) {
			this.endpoint_rid_stg = System.getenv("env_RID");
		} else {
			this.endpoint_rid_stg = "https://rid-stg-idlite-jp.gipdog.net";
		}

		if (System.getenv("env_AKITA") != null) {
			this.endpoint_akita = System.getenv("env_AKITA");
		} else {
			this.endpoint_akita = "https://stg-akita-api.account.rakuten.com";
		}
		
		if (System.getenv("env_Fakeprovider") != null) {
			this.fakeProviderUrl = System.getenv("env_Fakeprovider");
		} else {
			//this.fakeProviderUrl = "http://fake-provider:3000/idtoken?subject=";
			this.fakeProviderUrl = "http://localhost:3000/idtoken?subject=";
		}
		
		if (System.getenv("env_Fakeprovider02") != null) {
			this.fakeProvider02Url = System.getenv("env_Fakeprovider02");
		} else {
			this.fakeProvider02Url = "http://localhost:4000/idtoken?subject=";
		}
		
		if (System.getenv("env_Deactivation") != null) {
			this.deactivation_Url = System.getenv("env_Deactivation");
		} else {
			this.deactivation_Url = "https://dev-deactivate.idlite.gipdog.net/linkedIdentity/";
		}
		
		if (System.getenv("AUTHORIZATION_BLACKBOX_STG") != null) {
			this.authorization_blackbox_stg = System.getenv("AUTHORIZATION_BLACKBOX_STG");
		} else {
			this.authorization_blackbox_stg = "Basic dGVzdF9jbGllbnQ6dGVzdF9jbGllbnRfc2Vj";
		}
		
		
	}


	@Given("^I setup the proxy as default$")
	public void iSetupTheProxyAsDefault() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
	}	

	@When("^I load requestbody from json file \"([^\"]*)\" profile \"([^\"]*)\"$")
	public void iLoadRequestbodyFromJsonFileProfile(String jsonName, String profileName) throws Throwable {
		// set requestbody from json
		Map<String, String> headers = new HashMap<String, String>();
		String URL="";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		if (profileName.contains("CATmulti") && profileName.contains("idlite")) {
			if(this.endpoint_IDLiteAPIClient.contains("https://cat.")) {
				logger.info("Set proxy"+ this.proxy_host+" : "+this.proxy_port);
				this.authorization_blackbox_stg = "Basic cmlkX2NsaWVudDpyaWRfY2xpZW50X3NlY3JldA==";
				headers.put("Authorization", this.authorization_blackbox_stg);
			}else if(this.endpoint_IDLiteAPIClient.contains("localhost")) {
				Unirest.setProxy(null);
				logger.info("For Localhost, We don't need set proxy!");
			}
			 URL = this.endpoint_IDLiteAPIClient + "multi";
			logger.info("request URL:" + URL);
		}
		
		if (profileName.contains("CATmulti") && profileName.contains("omni")) {
			if(this.endpoint_IDLiteAPIClient.contains("https://cat.")) {
				logger.info("Set proxy"+ this.proxy_host+" : "+this.proxy_port);
				this.authorization_blackbox_stg = "Basic cmlkX2NsaWVudDpyaWRfY2xpZW50X3NlY3JldA==";
				headers.put("Authorization", this.authorization_blackbox_stg);
			}else if(this.endpoint_IDLiteAPIClient.contains("localhost")) {
				Unirest.setProxy(null);
				logger.info("For Localhost, We don't need set proxy!");
			}
			 URL = this.endpoint_omniClient + "multi";
			logger.info("request URL:" + URL);
		}
		
		if (this.requestBody.contains("$From")) {
			if (this.requestBody.contains("$Frommultimaster")) {
				this.requestBody = this.requestBody.replace("$Frommultimaster", this.masterToken);
			}
			else if(this.requestBody.contains("$Frommultirefresh")) {
				this.requestBody = this.requestBody.replace("$Frommultirefresh", this.refreshToken);
			}
			else if(this.requestBody.contains("$FromidToken")) {
				this.requestBody = this.requestBody.replace("$FromidToken", this.idToken);
			}
			else if(this.requestBody.contains("$Fromridcreate")) {
				this.requestBody = this.requestBody.replace("$Fromridcreate", this.ridEmail);
			}
			else if(this.requestBody.contains("$FromidLiteEmail")) {
				this.requestBody = this.requestBody.replace("$FromidLiteEmail", this.idlitetoFullemail);
			}
			
		}
		
		headers.put("Content-Type", "application/json");
		logger.info("headers --> "+headers);
		logger.info("Read Request Body: " + this.requestBody);
		this.postRes = Unirest.post(URL).headers(headers).body(this.requestBody).asString();
	
	logger.info("Read Response Body: " + this.postRes.getBody());
	}
	
	@When("^I load requestbody from json file for revoke \"([^\"]*)\" profile \"([^\"]*)\"$")
	public void iLoadRequestbodyFromJsonFileProfileforrevoke(String jsonName, String profileName) throws Throwable {
		// set requestbody from json
		Map<String, String> headers = new HashMap<String, String>();
		String URL="";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		
		if (profileName.contains("CATRevoke") && profileName.contains("idlite")) {
			if(this.endpoint_IDLiteAPIClient.contains("https://cat.")) {
				logger.info("Set proxy"+ this.proxy_host+" : "+this.proxy_port);
				
			}else if(this.endpoint_IDLiteAPIClient.contains("localhost")) {
				Unirest.setProxy(null);
				logger.info("For Localhost, We don't need set proxy!");
			}
			 URL = this.endpoint_IDLiteAPIClient + "revoke";
			logger.info("request URL:" + URL);
		}
		
		if (this.requestBody.contains("$From")) {
			if (this.requestBody.contains("$Frommultimaster")) {
				this.requestBody = this.requestBody.replace("$Frommultimaster", this.masterToken);
			}
			
		}
		
		headers.put("Content-Type", "application/json");
		logger.info("headers --> "+headers);
		logger.info("Read Request Body: " + this.requestBody);
		this.postRes = Unirest.put(URL).headers(headers).body(this.requestBody).asString();
	
	logger.info("Read Response Body: " + this.postRes.getBody());
	}
	@When("^I load idlite auth endpoint with requestbody from json file \"([^\"]*)\" profile \"([^\"]*)\"$")
	public void iLoadRequestbodyforIDLiteAuthFromJsonFileProfile(String jsonName, String profileName) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL = "";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		if (profileName != null && profileName.contains("idlite_auth")) {
			
			URL = this.endpoint_idLite + "api/v1/auth";
			logger.info("request URL:" + URL);
		}
		
		logger.info("request URL:" + URL);
		
			if (this.requestBody.contains("$FromidToken")) {			
					this.requestBody = this.requestBody.replace("$FromidToken", this.idToken);
			}
			
			headers.put("Content-Type", "application/json");
			headers.put("x-device-signature", "Fake mydevice");
			headers.put("forwarded", "for=192.168.1.1");
			headers.put("X-Client-Signature", "test");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.post(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);

	}
	
	@When("^I load idlite update endpoint with requestbody from json file \"(.*?)\" profile \"(.*?)\"$")
	public void i_load_idlite_update_endpoint_with_requestbody_from_json_file_profile(String jsonName, String profileName) throws Throwable {
		Thread.sleep(8000);
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL = "";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		if (profileName != null && profileName.contains("idLite_progress")) {
			
			URL = this.endpoint_idLite + "api/v1/members/me";
			logger.info("request URL:" + URL);
		}
		
		long systemTime = System.currentTimeMillis();
		 this.idlitetoFullemail = "test_" + String.valueOf(systemTime) + "@test.com";
	
		 Random rand = new Random(); 
	        int random = rand.nextInt(90000000)+10000000;
	        
	        String username = "testuser" + random;
	        
			if (this.requestBody.contains("$Frommultiexchange")) {
					this.requestBody = this.requestBody.replace("$Frommultiexchange", this.exchangeToken);
			}
			if (this.requestBody.contains("$FromrandomEmail")) {
				this.requestBody = this.requestBody.replace("$FromrandomEmail", this.idlitetoFullemail);
			}
			if (this.requestBody.contains("$FromrandomUser")) {
				this.requestBody = this.requestBody.replace("$FromrandomUser", username);
			}
			
			headers.put("Content-Type", "application/json");
			headers.put("x-device-signature", "Fake mydevice");
			headers.put("forwarded", "for=192.168.1.1");
			headers.put("X-Client-Signature", "test");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.patch(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
		
	}
	
	@When("^I load requestbody from json file for merge account \"(.*?)\" profile \"(.*?)\"$")
	public void i_load_requestbody_from_json_file_for_merge_account_profile(String jsonName, String profileName) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL = "";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		if (profileName != null && profileName.contains("idLite_merge")) {
			
			URL = this.endpoint_idLite + "api/v1/members/me/merge-target";
			logger.info("request URL:" + URL);
		}
		
			if (this.requestBody.contains("$FrommultiExchangeIDLite")) {
					this.requestBody = this.requestBody.replace("$FrommultiExchangeIDLite", this.exchangeToken_idlite);
			}
			if (this.requestBody.contains("$FrommultiExchangeProgressed")) {
				this.requestBody = this.requestBody.replace("$FrommultiExchangeProgressed", this.exchangeToken_idlite_idliteAPI);
			}
			if (this.requestBody.contains("$FrommultiExchange")) {
				this.requestBody = this.requestBody.replace("$FrommultiExchange", this.exchangeToken);
			}
			
			
			headers.put("Content-Type", "application/json");
			headers.put("x-device-signature", "Fake mydevice");
			headers.put("forwarded", "for=192.168.1.1");
			headers.put("X-Client-Signature", "test");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.put(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
		
	}
	
	@Then("^I check response code equals to \"([^\"]*)\"$")
	public void iCheckResponseCodeEqualsTo(String responseCode) throws Throwable {
		//int status = this.postRes.getStatus();
		Assert.assertEquals(Integer.parseInt(responseCode), this.postRes.getStatus());
	}	
	
	@Then("^I save the value of \"([^\"]*)\"$")
	public void isaveSomereSponseValue(String paramaterName) throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		if (paramaterName.equals("authToken")) {
			this.authToken = jsonObject.getString(paramaterName);
			logger.info("authToken is:" + this.authToken);
		}
		if (paramaterName.equals("migrationToken")) {
			this.migrationToken = jsonObject.getString(paramaterName);
			logger.info("migrationToken is:" + this.migrationToken);
		}
		if (paramaterName.equals("masterToken")) {
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody()).getJSONObject("artifacts")
					.getJSONObject("token::master");
			this.masterToken = jsonobject.getString("token");
			logger.info("masterToken is:" + this.masterToken);
		}
		if (paramaterName.equals("master_token")) {
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody()).getJSONObject("master_token");
			this.masterToken = jsonobject.getString("token");
			logger.info("master_token is:" + this.masterToken);
		}
		if (paramaterName.equals("refreshToken")) {
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody()).getJSONObject("artifacts")
					.getJSONObject("token::refresh");
			this.refreshToken = jsonobject.getString("token");
			logger.info("refreshToken is:" + this.refreshToken);
		}
		if (paramaterName.equals("exchangeToken")) {
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody()).getJSONObject("artifacts")
					.getJSONObject("token::exchange");
			this.exchangeToken = jsonobject.getString("token");
			//this.authToken = this.exchangeToken;
			logger.info("exchangeToken:" + this.exchangeToken);
		}
		if (paramaterName.equals("memberId")) {
			this.memberId = jsonObject.getString(paramaterName);
			logger.info("memberId is:"+this.memberId);
		}
		if (paramaterName.equals("memberUuid")) {
			this.memberUuid = jsonObject.getString(paramaterName);
			logger.info("memberUuid is:"+this.memberUuid);
		}
		if (paramaterName.equals("subjects")) {
			this.subject = jsonObject.getString(paramaterName);
			logger.info("Subject is:"+this.subject);
		}
		if (paramaterName.equals("foreignId")) {
			this.foreignId = jsonObject.getString(paramaterName);
			logger.info("foreignId is:"+this.foreignId);
		}
		if (paramaterName.equals("email")) {
			this.email = jsonObject.getString(paramaterName);
			logger.info("Email is:"+this.email);
		}
		if (paramaterName.equals("easyId")) {
			this.easyId = jsonObject.getString(paramaterName);
			logger.info("easyId is:"+this.easyId);
		}
		
	}
	
	@Then("^I verify phone \"(.*?)\" and providername \"(.*?)\" are returned correctly for \"(.*?)\"$")
	public void i_verify_phone_and_providername_are_returned_correctly_for(String phone, String providername, String accountType) throws Throwable {
	    if(accountType.equals("idlite")) {
	    	JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody());
			this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(0).getString("phoneNumber");
			logger.info("phone number is:"+this.provider01_Phone);

			if(this.provider01_Phone.equals(String.valueOf(this.generatefakeProviderPhone))){
				this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("providerNames").get(0).toString();
				logger.info("provider name is:"+this.provider01_Name);	
			}
			else {
				this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(1).getString("phoneNumber");
				logger.info("phone number is:"+this.provider01_Phone);
				this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(1).getJSONArray("providerNames").get(0).toString();
				logger.info("provider name is:"+this.provider01_Name);
			}
			Assert.assertEquals("Phone number doesn't match for idlite", String.valueOf(this.generatefakeProviderPhone), this.provider01_Phone);
			Assert.assertEquals("Provider name doesn't match for idlite", "fakeidprovider", this.provider01_Name);
	    }
	    else if(accountType.equals("idlite2")) {
	    	JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody());
			this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(0).getString("phoneNumber");
			logger.info("phone number is:"+this.provider01_Phone);

			if(this.provider01_Phone.equals(String.valueOf(this.generatefakeProviderPhone))){
				this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("providerNames").get(1).toString();
				logger.info("provider name is:"+this.provider01_Name);	
			}
			else {
				this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(1).getString("phoneNumber");
				logger.info("phone number is:"+this.provider01_Phone);
				this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(1).getJSONArray("providerNames").get(1).toString();
				logger.info("provider name is:"+this.provider01_Name);
			}
			Assert.assertEquals("Phone number doesn't match for idlite", String.valueOf(this.generatefakeProviderPhone), this.provider01_Phone);
			Assert.assertEquals("Provider name doesn't match for idlite", "fakeidprovider02", this.provider01_Name);
	    }
	    else if(accountType.equals("rid")) {
	    	JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody());
			this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(0).getString("phoneNumber");
			logger.info("phone number is:"+this.provider01_Phone);

			if(this.provider01_Phone.equals(String.valueOf(this.rid_Phone))){
				this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(0).getString("providerNames");
				logger.info("provider name is:"+this.provider01_Name);	
			}
			else {
				this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(1).getString("phoneNumber");
				logger.info("phone number is:"+this.provider01_Phone);
				this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(1).getString("providerNames");
				logger.info("provider name is:"+this.provider01_Name);
			}
			Assert.assertEquals("Phone number doesn't match for rid", String.valueOf(this.rid_Phone), this.provider01_Phone);
			Assert.assertEquals("Provider name doesn't match for rid", "null", this.provider01_Name);	
	    }
	    
	}

	
	@Then("^I verify \"(.*?)\" and \"(.*?)\" are returned correctly$")
	public void i_verify_and_are_returned_correctly(String phone, String provider) throws Throwable {
	
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody());
			this.provider01_Phone = jsonobject.getJSONArray("phones").getJSONObject(0).getString("phoneNumber");
			logger.info("phone number is:"+this.provider01_Phone);

			this.provider01_Name = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("providerNames").get(0).toString();
			logger.info("provider name is:"+this.provider01_Name);
			
			Assert.assertEquals("Phone number doesn't match", String.valueOf(this.generatefakeProviderPhone), this.provider01_Phone);
			Assert.assertEquals("Provider name doesn't match", "fakeidprovider", this.provider01_Name);
	}
	
	@Then("^I verify phone type \"(.*?)\" and \"(.*?)\" are returned correctly$")
	public void i_verify_phoneType_returned_correctly(String phonetype1, String phonetype2) throws Throwable {
	
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody());
			String fullAccountPhoneType = null;
			String idLitePhoneType = null;
			
			if(phonetype1.equalsIgnoreCase("home")) {
			 fullAccountPhoneType = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(0).toString();
			logger.info("Full Account phone type is :"+ fullAccountPhoneType);
			 idLitePhoneType = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(1).toString();
			logger.info("IDLite Account phone type is :"+ idLitePhoneType);
			}
			else if(phonetype1.equalsIgnoreCase("work")) {
				 fullAccountPhoneType = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(1).toString();
				logger.info("Full Account phone type is :"+ fullAccountPhoneType);
				 idLitePhoneType = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(0).toString();
				logger.info("IDLite Account phone type is :"+ idLitePhoneType);
			}
			
			Assert.assertEquals("Full Account Phone type doesn't match", phonetype1, fullAccountPhoneType);
			Assert.assertEquals("IDlite Account phone type doesn't match", phonetype2, idLitePhoneType);
	}
	
	@Then("^I verify phone types \"(.*?)\" \"(.*?)\" and \"(.*?)\" are returned correctly$")
	public void i_verify_phone_types_and_are_returned_correctly(String phonetype1, String phonetype2, String phonetype3) throws Throwable {
	   
		JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody());
		
		String fullAccountPhoneType1 = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(0).toString();
		logger.info("Full Account phone type is :"+ fullAccountPhoneType1);
		String fullAccountPhoneType2 = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(2).toString();
		logger.info("Full Account phone type is :"+ fullAccountPhoneType2);
		 String idLitePhoneType = jsonobject.getJSONArray("phones").getJSONObject(0).getJSONArray("type").get(1).toString();
		logger.info("IDLite Account phone type is :"+ idLitePhoneType);
		
		Assert.assertEquals("Full Account Phone type doesn't match", phonetype1, fullAccountPhoneType1);
		Assert.assertEquals("Full Account Phone type doesn't match", phonetype3, fullAccountPhoneType2);
		Assert.assertEquals("IDlite Account phone type doesn't match", phonetype2, idLitePhoneType);
		
	}
	@Then("^I save the value of \"(.*?)\" of rid audience$")
	public void i_save_the_value_of_of_rid_audience(String paramaterName) throws Throwable {
		
		if (paramaterName.equals("exchangeToken")) {
			JSONObject jsonobject = JSONObject.fromObject(this.postRes.getBody()).getJSONObject("artifacts")
					.getJSONObject("token::exchange");
			this.exchangeToken_ridAudience = jsonobject.getString("token");
			//this.authToken = this.exchangeToken;
			logger.info("exchangeToken for rid audience is :" + this.exchangeToken_ridAudience);
		}
	}

	
	@Then("^I save the value of \"(.*?)\" for future verification$")
	public void i_save_the_value_of_for_future_verification(String paramaterName) throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		if (paramaterName.equals("foreignId")) {
			this.foreignId = jsonObject.getString(paramaterName);
			this.foreignId_1=this.foreignId;
			logger.info("foreignId is:"+this.foreignId);
		}
	}
	
	@Then("^I wait for the token to get expired$")
	public void i_wait_for_the_token_to_get_expired() throws Throwable {
		Thread.sleep(70000);
	}
	
	@Then("^I wait for revoke session$")
	public void i_wait_for_revoke_session() throws Throwable {
		Thread.sleep(2000);
	}

	@When("^I get idlite user identity by current foreignid with bearer exchange token$")
	public void i_get_idlite_user_identity_by_current_foreignid_with_bearer_exchange_token() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		String URL = this.endpoint_rid_stg + "/v1/idlite/providers/fakeidprovider/members/" + this.generateForeignId;
		
		logger.info("get request URL: " + URL);
		
		Map<String, String> headers = new HashMap<String, String>();
		this.authorization_idLite = "Bearer " +  this.exchangeToken_idlite_idliteAPI;
		headers.put("Authorization", this.authorization_idLite);
		headers.put("X-Client-UserAgent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)");
		headers.put("X-Client-IP", "127.0.0.1");
		headers.put("Content-Type", "application/json");
		logger.info("headers --> "+headers);

		this.postRes = Unirest.get(URL).headers(headers).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}
	
	@When("^I get idlite2 user identity by current foreignid with bearer exchange token$")
	public void i_get_idlite2_user_identity_by_current_foreignid_with_bearer_exchange_token() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		String URL = this.endpoint_rid_stg + "/v1/idlite/providers/fakeidprovider02/members/" + this.generateForeignId;
		
		logger.info("get request URL: " + URL);
		
		Map<String, String> headers = new HashMap<String, String>();
		this.authorization_idLite = "Bearer " +  this.exchangeToken_idlite_idliteAPI;
		headers.put("Authorization", this.authorization_idLite);
		headers.put("X-Client-UserAgent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)");
		headers.put("X-Client-IP", "127.0.0.1");
		headers.put("Content-Type", "application/json");
		logger.info("headers --> "+headers);

		this.postRes = Unirest.get(URL).headers(headers).asString();
		
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}
	
	@When("^I get idlite_2 user identity by current foreignid with bearer exchange token$")
	public void i_get_idlite_2_user_identity_by_current_foreignid_with_bearer_exchange_token() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		String URL = this.endpoint_rid_stg + "/v1/idlite/providers/fakeidprovider02/members/" + this.generateForeignId;
		
		logger.info("get request URL: " + URL);
		
		Map<String, String> headers = new HashMap<String, String>();
		this.authorization_idLite = "Bearer " +  this.exchangeToken_idlite_idliteAPI;
		headers.put("Authorization", this.authorization_idLite);
		headers.put("X-Client-UserAgent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)");
		headers.put("X-Client-IP", "127.0.0.1");
		headers.put("Content-Type", "application/json");
		logger.info("headers --> "+headers);

		this.postRes = Unirest.get(URL).headers(headers).asString();
		
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}
	
	@When("^I get idlite user profile by using Akita API$")
	public void i_get_idlite_user_profile_by_using_Akita_API() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Thread.sleep(20000);
		String URL = this.endpoint_akita + "/v1/members/" + this.memberUuid + "/profile";
		
		logger.info("get request URL: " + URL);
		
		Map<String, String> headers = new HashMap<String, String>();
		String authorization_akita = "Bearer " +  this.exchangeToken_akita;
		headers.put("Authorization", authorization_akita);
		headers.put("X-Client-IP", "127.0.0.1");
		logger.info("headers --> "+headers);

		this.postRes = Unirest.get(URL).headers(headers).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}

	@Then("^I verify foreignid returned is same$")
	public void i_verify_foreignid_returned_is_same() throws Throwable {
	    Assert.assertEquals("foreignid value matches", this.foreignId, this.foreignId_1);
	    logger.info("Foreign ID matches");
	}

	@Then("^I verify email or phone is updated with new value$")
	public void i_verify_email_or_phone_is_updated_with_new_value() throws Throwable {
		 Assert.assertEquals("foreignid value matches", this.foreignId, this.foreignId_1);
		    logger.info("Foreign ID matches");
	} 
	
	@When("^I get user information by current memberId with bearer exchange token$")
	public void i_get_user_information_by_current_memberId_with_bearer_exchange_token() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		// String URL = this.authorization_viber_stg + "/r/linkage/" + memberId;
				String URL = "https://rid-stg-us.gipdog.net/v1/members/$memberUuid/profile";
				if (URL.contains("$memberUuid")) {
					URL =  URL.replace("$memberUuid", this.memberUuid);
				}
				logger.info("get request URL: " + URL);
				
				Map<String, String> headers = new HashMap<String, String>();
				this.authorizatioin_rid = "Bearer " +  this.exchangeToken;
				headers.put("Authorization", this.authorizatioin_rid);
				headers.put("X-Client-UserAgent", "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)");
				headers.put("X-Client-IP", "127.0.0.1");
				headers.put("Content-Type", "application/json");
				logger.info("headers --> "+headers);

				this.postRes = Unirest.get(URL).headers(headers).asString();
				logger.info("Read Response Body: " + this.postRes.getBody());
				Unirest.setProxy(null);
				
	}

	@When("^I load requestbody from json file for RID \"(.*?)\" profile \"(.*?)\"$")
	public void i_load_requestbody_from_json_file_for_RID_profile(String jsonName, String profileName) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL="";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		if (profileName != null && profileName.contains("rid")) {
			 URL = this.endpoint_rid + "/oAuth/tokens?grant_type=client_credentials";
			logger.info("request URL:" + URL);
		}
			
			headers.put("Content-Type", "application/json");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.post(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}

	@When("^I load requestbody from json file for RID create member \"(.*?)\" profile \"(.*?)\"$")
	public void i_load_requestbody_from_json_file_for_RID_create_member_profile(String jsonName, String profileName) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL="";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		
		long systemTime = System.currentTimeMillis();
		 this.ridEmail = "test_" + String.valueOf(systemTime) + "@rakuten.com";
		
		if (this.requestBody.contains("$random")) {
				this.requestBody = this.requestBody.replace("$random", this.ridEmail);
			}
					
		if (profileName != null && profileName.contains("rid")) {
			 URL = this.endpoint_rid_stg + "/v1/members";
			logger.info("request URL:" + URL);
		}
			this.authorizatioin_rid = "Bearer " +  this.authToken;
			headers.put("Authorization", this.authorizatioin_rid);
			
			headers.put("Content-Type", "application/json");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.post(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}
	
	@When("^I load requestbody from json file for rid update phone \"(.*?)\" profile \"(.*?)\"$")
	public void i_load_requestbody_from_json_file_for_RID_updatephone(String jsonName, String profileName) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL="";
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
	
		if (this.requestBody.contains("$Fromfakepropviderphone")) {
				this.requestBody = this.requestBody.replace("$Fromfakepropviderphone", String.valueOf(this.generatefakeProviderPhone));
			}
		else if(this.requestBody.contains("$FromPhone")) {
			Random rand1 = new Random();
			  this.rid_Phone = rand1.nextInt (900000000) + 1000000000;
			this.requestBody = this.requestBody.replace("$FromPhone", String.valueOf(this.rid_Phone));
		}
					
		if (profileName != null && profileName.contains("rid")) {
			 URL = this.endpoint_rid_stg + "/v1/members/" + this.memberUuid + "/profile";
			logger.info("request URL:" + URL);
		}
			this.authorizatioin_rid = "Bearer " +  this.exchangeToken;
			headers.put("Authorization", this.authorizatioin_rid);
			
			headers.put("Content-Type", "application/json");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.put(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}

	@When("^I delete user information by member id$")
	public void i_delete_user_information_by_member_id() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL=this.endpoint_rid_stg + "/v1/members/"+ this.memberUuid + "?hardDelete=true";
	
				this.authorization_blackbox_stg = "Bearer " + this.authToken;
				headers.put("Authorization", this.authorization_blackbox_stg);
				headers.put("Content-Type", "application/json");
				logger.info("request URL:" + URL);
				
			logger.info("headers --> "+headers);
			this.postRes = Unirest.delete(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());  
		Unirest.setProxy(null);
	}
	
	@When("^I delete merged full account by calling RID delete api with authtoken$")
	public void i_delete_merged_full_account_by_calling_RID_delete_api_with_authtoken() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL=this.endpoint_rid_stg + "/v1/members/"+ this.memberUuid + "?hardDelete=true";
	
				headers.put("Authorization", "Bearer " + this.authToken);
				headers.put("Content-Type", "application/json");
				logger.info("request URL:" + URL);
				
			logger.info("headers --> "+headers);
			this.postRes = Unirest.delete(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());  
		Unirest.setProxy(null);
	}

	@When("^I get idToken from fakeprovider with subject only$")
	public void i_get_idToken_from_fakeprovider_with_subject_only() throws Throwable {
		Random rand = new Random(); 
		 double randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid;    
      String URL = this.fakeProviderUrl + this.generateForeignId;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with subject and phone number$")
	public void i_get_idToken_from_fakeprovider_with_subject_phone() throws Throwable {
//		Random rand = new Random(); 
//		 long randomid = rand.nextInt(9000000) + 1000000;
//        
        //this.generateForeignId = "oneapp"+randomid;  
        
        UUID uuid = UUID.randomUUID();
        this.generateForeignId = uuid.toString();
        
        Random rand1 = new Random();
        int phone1 = rand1.nextInt (900) + 100;
        int phone2 = rand1.nextInt (900) + 100;
        int phone3 = rand1.nextInt (9000) + 1000;
	    this.generatefakeProviderPhone = "81" + String.valueOf(phone1) + String.valueOf(phone2) + String.valueOf(phone3);
	    
       String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from another fakeprovider with different subject and same phone number$")
	public void i_get_idToken_from_another_fakeprovider_with_differentsubject_samephone() throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid; 
        
       String URL = this.fakeProvider02Url + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true&issuer=https://fakeidprovider02.dev.idlite.gipdog.net&aud=cat" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from another fakeprovider with different subject and different phone number$")
	public void i_get_idToken_from_another_fakeprovider_with_differentsubject_differentphone() throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid; 
        
        Random rand1 = new Random();
		  this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
        
       String URL = this.fakeProvider02Url + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true&issuer=https://fakeidprovider02.dev.idlite.gipdog.net&aud=cat" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from another fakeprovider with same subject and different phone$")
	public void i_get_idToken_from_another_fakeprovider_with_samesubject_differentPhone() throws Throwable {
		
		Random rand1 = new Random();
		  this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
	    
       String URL = this.fakeProvider02Url + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true&issuer=https://fakeidprovider02.dev.idlite.gipdog.net&aud=cat" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from another fakeprovider with same subject and same phone$")
	public void i_get_idToken_from_another_fakeprovider_with_samesubject_samePhone() throws Throwable {
		
       String URL = this.fakeProvider02Url + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true&issuer=https://fakeidprovider02.dev.idlite.gipdog.net&aud=cat" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and same phone$")
	public void i_get_idToken_from_fakeprovider_with_samesubject_samePhone() throws Throwable {
		
       String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	
	@When("^I get idToken from fakeprovider with different subject and same phone$")
	public void i_get_idToken_from_fakeprovider_with_differentSubject_samePhone() throws Throwable {
		
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid;  
        
       String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and different phone$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_different_phone() throws Throwable {
		
		Random rand1 = new Random();
		  this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
	    
       String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and same email$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_same_email() throws Throwable {
		
		String URL = this.fakeProviderUrl + this.generateForeignId + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with different subject and same email$")
	public void i_get_idToken_from_fakeprovider_with_different_subject_and_same_email() throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid; 
		
		String URL = this.fakeProviderUrl + this.generateForeignId + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ; 
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and different email$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_different_email() throws Throwable {
		
		 long systemTime = System.currentTimeMillis();
			this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
			
		String URL = this.fakeProviderUrl + this.generateForeignId + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ; 
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from another fakeprovider with same subject and same email$")
	public void i_get_idToken_from_another_fakeprovider_with_same_subject_and_same_email() throws Throwable {
		
		String URL = this.fakeProvider02Url + this.generateForeignId + "&email=" + this.generatefakeProviderEmail + "&email_verified=true&issuer=https://fakeidprovider02.dev.idlite.gipdog.net&aud=cat" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I unlink idlite account using idToken$")
	public void i_unlink_idlite_account_using_idToken() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		String URL = this.deactivation_Url + this.idToken ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.delete(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		//this.idToken = this.postRes.getBody();
		Unirest.setProxy(null);
		
	}
	
	@When("^I get idToken from fakeprovider with subject and email$")
	public void i_get_idToken_from_fakeprovider_with_subject_email() throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid;  
        
        long systemTime = System.currentTimeMillis();
		this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
	    
       String URL = this.fakeProviderUrl + this.generateForeignId + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with subject phone and email$")
	public void i_get_idToken_from_fakeprovider_with_subject_phone_email() throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
        
        this.generateForeignId = "oneapp"+randomid;  
        
        Random rand1 = new Random();
        this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
        
        long systemTime = System.currentTimeMillis();
		this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
	    
       String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with subject as \"(.*?)\"$")
	public void i_get_idToken_from_fakeprovider_with_subject_as(String subject) throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
	    
        this.foreignId = subject + randomid;
        this.generateForeignId = URLEncoder.encode(subject,"UTF-8") + randomid; 
        
        Random rand1 = new Random();
        this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
	    
        long systemTime = System.currentTimeMillis();
		this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
	    
      String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
		
	}
	
	@When("^I get idToken from fakeprovider with subject and \"(.*?)\"$")
	public void i_get_idToken_from_fakeprovider_with_subject_and(String email) throws Throwable {
		Random rand = new Random(); 
		 long randomid = rand.nextInt(9000000) + 1000000;
	    
        this.generateForeignId = "oneapp"+randomid;  
        
        
        String URL = this.fakeProviderUrl + this.generateForeignId + "&email=" + email + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
		
	}
	
	@When("^I get idToken from fakeprovider with same subject and adding phone$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_adding_phone() throws Throwable { 
        
        Random rand1 = new Random();
	    this.generatefakeProviderPhone = "81" + rand1.nextInt (99999) * 100000;
	    
      String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and adding email$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_adding_email() throws Throwable {
	
        
        long systemTime = System.currentTimeMillis();
		this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
	    
     String URL = this.fakeProviderUrl + this.generateForeignId + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}

	@When("^I get idToken from fakeprovider with same subject and adding email, phone$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_adding_email_phone() throws Throwable {
		 Random rand1 = new Random();
		  this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
		    
		long systemTime = System.currentTimeMillis();
		this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
	    
     String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and updated email$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_updated_email() throws Throwable {
		
		long systemTime = System.currentTimeMillis();
		this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
	    
		String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
	    
		logger.info("get request URL: " + URL);
		
		this.postRes = Unirest.get(URL).asString();
		logger.info("Read Response Body: " + this.postRes.getBody());
		this.idToken = this.postRes.getBody();
	}
	
	@When("^I get idToken from fakeprovider with same subject and updated phone$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_updated_phone() throws Throwable {
		
		 Random rand1 = new Random();
		  this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
		    
		    String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
		    
			logger.info("get request URL: " + URL);
			
			this.postRes = Unirest.get(URL).asString();
			logger.info("Read Response Body: " + this.postRes.getBody());
			this.idToken = this.postRes.getBody();
			
	}
	
	@When("^I get idToken from fakeprovider with same subject and updated email, phone$")
	public void i_get_idToken_from_fakeprovider_with_same_subject_and_updated_email_phone() throws Throwable {
		 Random rand1 = new Random();
		  this.generatefakeProviderPhone = "81" + rand1.nextInt (900000000) + 1000000000;
		    
		    long systemTime = System.currentTimeMillis();
			this.generatefakeProviderEmail = "test_" + String.valueOf(systemTime) + "@test.com";
		    
				String URL = this.fakeProviderUrl + this.generateForeignId + "&phone_number=" + this.generatefakeProviderPhone + "&phone_number_verified=true" + "&email=" + this.generatefakeProviderEmail + "&email_verified=true" ;
		    
			logger.info("get request URL: " + URL);
			
			this.postRes = Unirest.get(URL).asString();
			logger.info("Read Response Body: " + this.postRes.getBody());
			this.idToken = this.postRes.getBody();
	}
	
	
	@Then("^I verify the email is updated to new value$")
	public void i_verify_the_email_is_updated_to_new_value() throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		
		String email_updatedvalue = jsonObject.getString("email");
		
		Assert.assertEquals("email is updated with new value ", this.email, email_updatedvalue); 
	}
	
	@Then("^I verify mergeable flag is set as false$")
	public void i_verify_mergeable_is_updated_to_false() throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		
		String mergeableValue = jsonObject.getString("mergeable");
		
		Assert.assertEquals("Mergeable flag is updated as false ", "false", mergeableValue); 
	}
	
	@Then("^I verify profile details are updated$")
	public void i_verify_profile_details_are_updated() throws Throwable {
	   
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		
		String email_updatedvalue = jsonObject.getString("email");	
		String firstname_updatedvalue = jsonObject.getString("firstName");	
		String lastname_updatedvalue = jsonObject.getString("lastName");	
		String firstnamekana_updatedvalue = jsonObject.getString("firstNameKana");	
		String lastnamekana_updatedvalue = jsonObject.getString("lastNameKana");	
		
		Assert.assertEquals("email is updated with new value ", this.idlitetoFullemail, email_updatedvalue); 
		Assert.assertEquals("firstName is updated with new value ", "John", firstname_updatedvalue); 
		Assert.assertEquals("lastName is updated with new value ", "Smith", lastname_updatedvalue); 
		Assert.assertEquals("firstNameKana is updated with new value ", "ジョン", firstnamekana_updatedvalue); 
		Assert.assertEquals("lastNameKana is updated with new value ", "スミス", lastnamekana_updatedvalue); 
		
	}
	
	@Then("^I verify foreignId is present$")
	public void i_verify_foreignId_is_present() throws Throwable {
		boolean foreignId = false;
		
		if(this.subject.contains(this.generateForeignId)) {
			foreignId=true;
		}
		Assert.assertTrue("foreignId presents in the subject", foreignId);		
	}

	@Then("^I verify merged account \"(.*?)\" is present$")
	public void i_verify_merged_account_is_present(String arg1) throws Throwable {
		boolean mergedEasyId = false;
		
		if(this.subject.contains(this.easyId)) {
			mergedEasyId=true;
		}
		Assert.assertTrue("Merged account easyId presents in the subject", mergedEasyId);	
	}

	@Then("^I verify eid rid gid is present$")
	public void i_verify_eid_rid_gid_is_present() throws Throwable {
		boolean eid = false;
		boolean rid = false;
		boolean gid = false;
		
		if(this.subject.contains("eid:")) {
			eid=true;
		}
		Assert.assertTrue("eid presents in the subject for linkage found", eid);
		
		if(this.subject.contains("rid:")) {
			rid=true;
		}
		Assert.assertTrue("rid presents in the subject for linkage found", rid);
		
		if(this.subject.contains("gid:")) {
			gid=true;
		}
		Assert.assertTrue("gid presents in the subject for linkage found", gid);
		
	}
	

	@Then("^I save the value of \"(.*?)\" for RID and AKITA$")
	public void i_save_the_value_of_for_RID_and_AKITA(String paramaterName) throws Throwable {
		//JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		if (paramaterName.equals("exchangeToken")) {
			if(this.postRes.getBody().contains("tokens::exchange")) {
				JSONObject jsonObjectResponse = JSONObject.fromObject(this.postRes.getBody());
				this.exchangeToken = String.valueOf(JSONObject.fromObject(jsonObjectResponse.getJSONObject("artifacts").getJSONArray("tokens::exchange").get(0)).get("token"));
				this.exchangeToken_akita = String.valueOf(JSONObject.fromObject(jsonObjectResponse.getJSONObject("artifacts").getJSONArray("tokens::exchange").get(1)).get("token"));
				
				logger.info("exchangeToken value for rid is  :" + this.exchangeToken);
				logger.info("exchangeToken value for akita is  :" + this.exchangeToken_akita);
				}
		}
		
	}

	@Then("^I verify email username password are set autogenerated as \"(.*?)\" \"(.*?)\" \"(.*?)\"$")
	public void i_verify_email_username_password_are_set_autogenerated_as(String emailValue, String usernameValue, String passwordValue) throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		
		String emailAutogenerated = jsonObject.getString("emailAutogenerated");
		String usernameAutogenerated = jsonObject.getString("usernameAutogenerated");
		String passwordAutogenerated = jsonObject.getString("passwordAutogenerated");
		Assert.assertEquals("emailAutogenerated is set as " + emailValue, emailValue, emailAutogenerated);
		Assert.assertEquals("usernameAutogenerated is set as " + usernameValue , usernameValue, usernameAutogenerated);
		Assert.assertEquals("passwordAutogenerated is set as " + passwordValue, passwordValue, passwordAutogenerated);
	}
	
	
	@Then("^I verify \"(.*?)\" and \"(.*?)\" matches with ldlite account$")
	public void i_verify_and_matches_with_ldlite_account(String easyId, String email) throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());
		
		String email_akitaProfile = jsonObject.getString("email");
		String easyId_akitaProfile = jsonObject.getString("easyId");
		
		Assert.assertEquals("email matches with idlite account", this.email.toLowerCase(), email_akitaProfile); 
		Assert.assertEquals("easyId matches with idlite account", this.easyId, easyId_akitaProfile); 
	}
	
	@Then("^I verify the resposne body contains target memberuuid and \"(.*?)\"$")
	public void i_verify_the_resposne_body_contains_target_memberuuid_and(String provider) throws Throwable {
		JSONObject jsonObject = JSONObject.fromObject(this.postRes.getBody());		
		String subject = jsonObject.getString("subjects");
		
		boolean memberuuid = false;
		boolean fakeidprovider = false;
		
		if(subject.contains(this.memberUuid)) {
			memberuuid=true;
		}
		Assert.assertTrue("target membneruuid matches ", memberuuid);	
		
		if(subject.contains(provider)) {
			fakeidprovider=true;
		}
		Assert.assertTrue("fakeidprovider matches ", fakeidprovider);	
		
	}
	
	@Then("^I save \"(.*?)\" for further steps$")
	public void i_save_for_further_steps(String paramaterName) throws Throwable {
		if (paramaterName.equals("easyId")) {
			this.easyId_idlite1 = this.easyId;
		}
		if (paramaterName.equals("exchangeToken")) {
			this.exchangeToken_idlite = this.exchangeToken;
			logger.info("idlite account exchange token is:" + this.exchangeToken_idlite);
		}
		if (paramaterName.equals("exchangeToken_idlite")) {
			this.exchangeToken_idlite_idliteAPI = this.exchangeToken;
			logger.info("idlite account exchange token is:" + this.exchangeToken_idlite_idliteAPI);
		}
		if (paramaterName.equals("memberUuid_idlite")) {
			this.memberUUID_idlite = this.memberUuid;
			logger.info("idlite account memberuuid  is:" + this.memberUUID_idlite);
		}
	}

	@Then("^I verify new easyId is created$")
	public void i_verify_new_easyId_is_created() throws Throwable {
	   
		Assert.assertNotEquals(this.easyId_idlite1, this.easyId);
	}
	
	@When("^I load requestbody from json file for authToken \"(.*?)\" profile \"(.*?)\"$")
	public void i_load_requestbody_from_json_file_for_authToken_profile(String jsonName, String profileName) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + jsonName, profileName);
		
			String URL = this.endpoint_rid_stg + "/v1/oAuth/tokens?grant_type=client_credentials";
			logger.info("request URL:" + URL);
		
			
			headers.put("Content-Type", "application/json");
			logger.info("headers --> "+headers);
			logger.info("Read Request Body: " + this.requestBody);
			this.postRes = Unirest.post(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}

	

	@When("^I delete merged full account by calling RID delete api$")
	public void i_delete_merged_full_account_by_calling_RID_delete_api() throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));

		Map<String, String> headers = new HashMap<String, String>();
		String URL=this.endpoint_rid_stg + "/v1/members/"+ this.memberUuid + "?hardDelete=true";
	
				this.authorization_blackbox_stg = "Bearer " + this.exchangeToken;
				headers.put("Authorization", this.authorization_blackbox_stg);
				headers.put("Content-Type", "application/json");
				logger.info("request URL:" + URL);
				
			logger.info("headers --> "+headers);
			this.postRes = Unirest.delete(URL).headers(headers).body(this.requestBody).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}
	
	
	@Then("^I decode the idtoken value to header payload and signature$")
	public void i_decode_the_idtoken_value_to_header_payload_and_signature() throws Throwable {
		
		String jwtToken = this.idToken;
		if (this.idToken.startsWith("eyJra")) {
			System.out.println("------------ Decode JWT ------------");
			String[] split_string = jwtToken.split("\\.");
			this.base64DecodedHeader = split_string[0];
			this.base64DecodedBody = split_string[1];
			this.base64DecodedSignature = split_string[2];

			System.out.println("~~~~~~~~~ JWT Header ~~~~~~~");
			Base64 base64Url = new Base64(true);
			this.jwtHeader = new String(base64Url.decode(this.base64DecodedHeader));
			System.out.println("JWT Header : " + jwtHeader);

			System.out.println("~~~~~~~~~ JWT Body ~~~~~~~");
			this.jwtpayloadbody = new String(base64Url.decode(this.base64DecodedBody));
			System.out.println("JWT Body : " + jwtpayloadbody);

			
		}
		
	}
	
	@Then("^I change \"(.*?)\" value and encode it again$")
	public void i_change_value_and_encode_it_again(String arg1) throws Throwable {
	    
		if(arg1.equals("iss")) {
			String changedIssuerbody = this.jwtpayloadbody.replace("idlite", "test");
			this.base64DecodedBody = changedIssuerbody;
			
			Base64 base64Url = new Base64(true);
			this.base64EncodedBody = base64Url.encodeToString(this.base64DecodedBody.getBytes());
			logger.info("changed body is: " + base64DecodedBody);
			logger.info("Encoded changed body is: " + base64EncodedBody);
			
			this.idToken = this.base64DecodedHeader + "." + this.base64EncodedBody + "." + 	this.base64DecodedSignature;
			
			logger.info("idtoken after changing issuer is: " + this.idToken);
		}
		//String kid = "";
		
		if(arg1.equals("kid")) {			
			StringBuilder changedkidheader = new StringBuilder(this.base64DecodedHeader);			
			changedkidheader.replace(20, 30, "cyao6enh6a");			
			this.base64DecodedHeader = changedkidheader.toString();			
			logger.info("changed header is: " + this.base64DecodedHeader);			
			this.idToken = this.base64DecodedHeader + "." + this.base64DecodedBody + "." + 	this.base64DecodedSignature;			
			logger.info("idtoken after changing kid is: " + this.idToken);
		}		
		
		if(arg1.equals("signature")) {			
			this.base64DecodedSignature = this.base64DecodedSignature + "qwerty";
			logger.info("changed signature is: " + this.base64DecodedSignature);			
			this.idToken = this.base64DecodedHeader + "." + this.base64DecodedBody + "." + 	this.base64DecodedSignature;			
			logger.info("idtoken after changing signature is: " + this.idToken);
		}		
	}
	@When("^I verify eid rid gid is not present$")
	public void iVerifyeidIsNotPresent() throws Throwable {
		
		boolean eid = false;
		
		if(this.subject.contains("eid:")) {
			eid=true;
		}
		Assert.assertFalse("eid is not present in the subject for linkage not found", eid);	
		
	}

	
	@When("^I get  service linkage using serviceUuid \"(.*?)\"$")
	public void i_get_service_linkage_using_serviceUuid(String serviceUuid) throws Throwable {
		Unirest.setProxy(new HttpHost(this.proxy_host, this.proxy_port));
		Map<String, String> headers = new HashMap<String, String>();
		String URL=this.endpoint_rid_stg + "/v1/members/"+ this.memberUuid + "/services/" + serviceUuid;
	
				this.authorization_blackbox_stg = "Bearer " + this.authToken;
				headers.put("Authorization", this.authorization_blackbox_stg);
				headers.put("Content-Type", "application/json");
				logger.info("request URL:" + URL);
				
			logger.info("headers --> "+headers);
			this.postRes = Unirest.get(URL).headers(headers).asString();
		
		logger.info("Read Response Body: " + this.postRes.getBody());
		Unirest.setProxy(null);
	}

//
//	@After
//    public void afterScenario(Scenario scenario) throws UnirestException {
//		System.out.println(scenario.getStatus());
//		String scenarioName = scenario.getName();
//		String testcaseid = scenarioName.substring(scenarioName.length()-6, scenarioName.length()-1);
//		Unirest.setProxy(new HttpHost("dev-proxy.db.rakuten.co.jp", 9502));
//		
//		Map<String, String> headers = new HashMap<String, String>();
//		String URL = "https://gcsd.testrail.net/index.php?/api/v2/add_result_for_case/" + IDLiteAPIs_RunTest.runid + "/" + testcaseid;
//		logger.info("request URL:" + URL);
//
//		headers.put("Content-Type", "application/json");
//		headers.put("Authorization", "Basic c2FyYXRoa3VtYS5yYWplbmRyYW5AcmFrdXRlbi5jb206MyFYbHNpb3Jzcw==");
//		logger.info("request URL:" + URL);		
//		logger.info("headers --> "+headers);
//		
//        if (!scenario.isFailed()) {
//    		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + "happyPath/IDLiteAPIs.json", "testrail_updateStatusPassed");
//				logger.info("Read Request Body: " + requestBody);
//			postRes = Unirest.post(URL).headers(headers).body(requestBody).asString();        	
//        }
//        else if(scenario.isFailed()) {        	
//    		this.requestBody = JsonUtils.loadJsonFromResource(this.jsonPath + "happyPath/IDLiteAPIs.json", "testrail_updateStatusFailed");
//				logger.info("Read Request Body: " + requestBody);
//			postRes = Unirest.post(URL).headers(headers).body(requestBody).asString(); 
//        }
//        Unirest.setProxy(null);
//    }

   
}
