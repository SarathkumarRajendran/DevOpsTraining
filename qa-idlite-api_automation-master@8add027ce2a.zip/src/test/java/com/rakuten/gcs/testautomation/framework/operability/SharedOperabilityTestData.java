package com.rakuten.gcs.testautomation.framework.operability;

import java.net.Proxy;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SharedOperabilityTestData {

    final Log logger = LogFactory.getLog(SharedOperabilityTestData.class);

    private final Map<String, WebApplicationNodeObjectBase> nodeObjects;
    private final Map<String, LoadBalancerHTTPMonitorSimulator> monitorSimulators;

    private Proxy proxy;

    public SharedOperabilityTestData() {
        this.nodeObjects = new HashMap<String, WebApplicationNodeObjectBase>();
        this.monitorSimulators = new HashMap<String, LoadBalancerHTTPMonitorSimulator>();
        this.proxy = Proxy.NO_PROXY;

        // TODO Auto-generated constructor stub
    }

    public void putNodeObject(String key, WebApplicationNodeObjectBase nodeObject) {
        this.nodeObjects.put(key, nodeObject);
    }

    public WebApplicationNodeObjectBase getNodeObject(String key) {
        return this.nodeObjects.get(key);
    }

    public void putMonitorSimulators(String key, LoadBalancerHTTPMonitorSimulator simulator) {
        this.monitorSimulators.put(key, simulator);
    }

    public LoadBalancerHTTPMonitorSimulator getMonitorSimulator(String key) {
        return this.monitorSimulators.get(key);
    }

    public void setProxy(Proxy proxy) {
        this.proxy = proxy;
    }

    public Proxy getProxy() {
        return proxy;
    }

}
