package com.rakuten.gcs.testautomation.framework.web;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * Created by aldo.suwandi on 2015/07/22.
 */
public class BrowserOption {

    private String capabilityName;

    private Object capabilityOption;

    private DesiredCapabilities capabilities;

    public BrowserOption(String browserName, String os, String browserLocale) {
        switch (browserName) {
            case "firefox": {
                capabilities = DesiredCapabilities.firefox();
                FirefoxProfile profile = new FirefoxProfile();
                profile.setPreference(FirefoxProfile.ALLOWED_HOSTS_PREFERENCE, "localhost.localdomain");
                profile.setPreference("intl.accept_languages", browserLocale);
                capabilities.setCapability(FirefoxDriver.PROFILE, profile);
                break;
            }
            case "chrome": {
                capabilities = DesiredCapabilities.chrome();
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--lang=" + browserLocale);
                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                break;
            }
            case "internet explorer": {
                capabilities = DesiredCapabilities.internetExplorer();
                if (("Windows 8.1".equals(os) || "Windows 8".equals(os)) && "ja".equals(browserLocale)) {
                    capabilities.setCapability("prerun", "http://stg-wrcoretools101z.stg.jp.local:28080/data/ConfigureWin8-IE-ja.exe");
                }
                break;
            }
            case "opera": {
                capabilities = DesiredCapabilities.opera();
                break;
            }
            case "safari": {
                capabilities = DesiredCapabilities.safari();
                break;
            }
        }
    }

    public DesiredCapabilities getCapabilities() {
        return capabilities;
    }

    public void setCapabilities(DesiredCapabilities capabilities) {
        this.capabilities = capabilities;
    }
}
