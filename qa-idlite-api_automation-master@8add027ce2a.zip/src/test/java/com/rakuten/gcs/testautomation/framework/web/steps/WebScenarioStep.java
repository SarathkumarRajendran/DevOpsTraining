package com.rakuten.gcs.testautomation.framework.web.steps;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.rakuten.gcs.testautomation.framework.util.GCSStringUtil;
import com.rakuten.gcs.testautomation.framework.web.PageObjectBase;
import com.rakuten.gcs.testautomation.framework.web.PageObjectBase.PageObjectException;
import com.rakuten.gcs.testautomation.framework.web.SharedTestScenarioData;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WebScenarioStep {

    final Log logger = LogFactory.getLog(WebScenarioStep.class);

    private SharedTestScenarioData testData;

    public WebScenarioStep(SharedTestScenarioData testData) {
        this.testData = testData;
    }

    @Given("^the user opens \"(.*?)\"( in Given clause)?\\.$")
    public void given_the_user_opens(String pageName) throws Throwable {

        logger.info("Start open " + pageName);
        PageObjectBase page = testData.getPageObject(pageName);
        page.openPage(testData.getDriver());
        logger.info("End action for open " + pageName);
    }

    private void clickAButtonInThePage(String buttonName, int clickTime, String pageName) throws PageObjectException {
        PageObjectBase page = testData.getPageObject(pageName);
        for (int i = 0; i < clickTime; i++) {
            page.clickButtonWithoutCheckTitle(testData.getDriver(), testData.getScenario(), buttonName);
        }

    }

    @When("^the user clicks the \"(.*?)\" in \"(.*?)\" for (\\d+) times in When clause\\.$")
    public void the_user_clicks_the_in_for_times_in_when(String buttonName, String pageName, int clickTime) throws Throwable {
        clickAButtonInThePage(buttonName, clickTime, pageName);
    }

    @Then("^the title of opened page must be \"(.*?)\"\\.$")
    public void the_title_of_opened_page_is(String expectedTitle) throws Throwable {
        String actualTitle = testData.getDriver().getTitle();
        testData.write(String.format("Expected title is %s", expectedTitle));
        testData.write(String.format("Actual   title is %s", actualTitle));
        assertEquals("Title is wrong.", expectedTitle, actualTitle);
    }

    private void checkOneValueFromBusinessLogicResultOrOutputElement(String pageName, String outputElementNameOrBusinessKeyword, String expected) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        try {

            String actualValue = page.getBusinessLogicResultOrOutputElementValueByKeywordOrOutputElementName(testData.getDriver(), outputElementNameOrBusinessKeyword);
            // String expectedValue = page.getExpectedValidationMessage(expected);
            // testData.write(String.format("Expected value for %s in %s is %s", outputElementNameOrBusinessKeyword, pageName, expectedValue) );
            testData.write(String.format("Expected value for %s in %s is %s", outputElementNameOrBusinessKeyword, pageName, expected));
            testData.write(String.format("Actual   value for %s in %s is %s", outputElementNameOrBusinessKeyword, pageName, actualValue));
            // assertEquals("outputElementValue is different", expectedValue, actualValue);
            assertEquals("outputElementValue is different", expected, actualValue);
        } catch (Exception e) {
            testData.write(String.format("Expected exception", outputElementNameOrBusinessKeyword, pageName, expected));
            testData.write(String.format("Actual   value for %s in %s is %s", outputElementNameOrBusinessKeyword, pageName, e.getClass().getSimpleName()));
            if (e.getClass().getSimpleName().equals(expected)) {
                return;
            }
            throw e;
        }
    }

    @Then("^the value from \"(.*?)\" in \"(.*?)\" must be \"(.*?)\"\\.$")
    public void the_value_from_in_must_be(String outputElementNameOrBusinessKeyword, String pageName, String expected) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        expected = testData.getFollowingValueBySpecialKey(expected);
        expected = page.changeDescriptionToValue(outputElementNameOrBusinessKeyword, expected);
        checkOneValueFromBusinessLogicResultOrOutputElement(pageName, outputElementNameOrBusinessKeyword, expected);

    }

    @Then("^the source from \"(.*?)\" image in \"(.*?)\" must be \"(.*?)\"\\.$")
    public void the_source_from_image_in_must_be(String imageElementNameOrBusinessKeyword, String pageName, String expected) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        expected = page.changeDescriptionToValue(imageElementNameOrBusinessKeyword, expected);
        checkOneValueFromBusinessLogicResultOrOutputElement(pageName, imageElementNameOrBusinessKeyword, expected);

    }

    @Then("^the value for each key in \"(.*?)\" must be as following\\.$")
    public void the_value_for_each_key_in_must_be_as_following(String pageName, Map<String, String> params) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        for (String paramName : params.keySet()) {
            String expectedValue = GCSStringUtil.trimDoubleQuote(params.get(paramName));
            expectedValue = testData.getFollowingValueBySpecialKey(expectedValue);
            expectedValue = page.changeDescriptionToValue(paramName, expectedValue);
            checkOneValueFromBusinessLogicResultOrOutputElement(pageName, paramName, expectedValue);
        }
    }

    private void checkElementAttribute(String pageName, String elementName, String attributeName, String expected) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        try {
            String actualValue = page.getAttributeFromMultipleTypesElement(testData.getDriver(), elementName, attributeName);
            testData.write(String.format("Expected attribute for %s.%s in %s is %s", elementName, attributeName, pageName, expected));
            testData.write(String.format("Actual   attribute for %s.%s in %s is %s", elementName, attributeName, pageName, actualValue));
            assertEquals(String.format("Attribute %s.%s is different", elementName, attributeName), expected, actualValue);

        } catch (Exception e) {
            testData.write(String.format("Expected attribute for %s.%s in %s is %s", elementName, attributeName, pageName, expected));
            testData.write(String.format("Actual   attribute for %s.%s in %s is %s", elementName, attributeName, pageName, e.getClass().getSimpleName()));
            if (e.getClass().getSimpleName().equals(expected)) {
                return;
            }
            throw e;
        }
    }

    @Then("^the attribute \"(.*?)\" of \"(.*?)\" in \"(.*?)\" must be \"(.*?)\"\\.$")
    public void the_attribute_of_in_must_be(String attributeName, String elementName, String pageName, String expectedValue) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);

        expectedValue = page.changeDescriptionToValue(elementName, expectedValue);

        checkElementAttribute(pageName, elementName, attributeName, expectedValue);
    }

    @Then("^the element attributes in \"(.*?)\" must be as following\\.$")
    public void the_element_attributes_in_must_be_as_following(String pageName, List<List<String>> paramList) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);

        for (List<String> param : paramList) {
            if (param == null || param.size() < 3) {
                throw new Exception("The parameter must like: | elementName | attributeName | expectedValue |");
            }

            String elementName = GCSStringUtil.trimDoubleQuote(param.get(0));
            String attributeName = GCSStringUtil.trimDoubleQuote(param.get(1));
            String expectedValue = GCSStringUtil.trimDoubleQuote(param.get(2));

            expectedValue = page.changeDescriptionToValue(elementName, expectedValue);

            checkElementAttribute(pageName, elementName, attributeName, expectedValue);
        }
    }

    @When("^the user operates \"(.*?)\" with value \"(.*?)\" in \"(.*?)\"( in When clause)?\\.$")
    public void the_user_operates_with_value_in_when(String keyword, String value, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.inputTextOrOperateKeywordWithValue(testData.getDriver(), keyword, value);
    }

    @When("the enters \"(.*?)\" into \"(.*?)\" and default values into other elements on \"(.*?)\" and submit the form")
    public void fillin_the_form_then_submit(String elementValue, String elementName, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        testData.write("'XPath of " + elementName + "'='" + page.getInputElementXPath(elementName) + "'.");
        page.fillinTheForm(testData.getDriver(), elementName, elementValue);
        page.submitAForm(testData.getDriver());
    }

    @Given("^the user clicks the \"(.*?)\" in \"(.*?)\" in Given clause\\.$")
    public void the_user_clicks_the_in_given_clause(String elementName, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.clickButtonWithoutCheckTitle(testData.getDriver(), testData.getScenario(), elementName);
    }

    @When("^the user clicks the \"(.*?)\" in \"(.*?)\"\\.$")
    public void the_user_clicks_the_in(String elementName, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.clickButtonWithoutCheckTitle(testData.getDriver(), testData.getScenario(), elementName);
    }

    @Then("^the Url of opened page must be \"(.*?)\"\\.$")
    public void the_Url_of_opened_page_must_be(String expectedUrl) throws Throwable {
        String actualUrl = testData.getDriver().getCurrentUrl();
        actualUrl = actualUrl.split("\\?")[0];
        testData.write(String.format("Expected url is %s", expectedUrl));
        testData.write(String.format("Actual   url is %s", actualUrl));
        assertEquals("url is different", expectedUrl, actualUrl);
    }

    @Then("^waiting for (\\d+)millisecs$")
    public void waiting_for_millisecs(int millisecs) throws Throwable {
        logger.info("Waiting for " + millisecs + "millisecs");
        Thread.sleep(millisecs);
    }

    @Then("^the user waits \"(.*?)\" becomes enabled or 10 seconds in \"(.*?)\"\\.$")
    public void the_user_waits_becomes_enabled_or_10_seconds_in(String elementName, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        WebDriverWait wdw = new WebDriverWait(testData.getDriver(), 10000);
        wdw.until(ExpectedConditions.elementToBeClickable(By.xpath(page.getInputElementXPath(elementName))));
    }

    @When("^the user inserts into Page \"(.*?)\" as following\\.$")
    public void the_user_inserts_into_Page_as_following(String pageName, Map<String, String> params) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);

        for (Entry<String, String> param : params.entrySet()) {
            page.putBlankToInputElement(testData.getDriver(), param.getKey());
            page.putInputTextToInputElement(testData.getDriver(), param.getValue(), param.getKey());
        }
    }

    @When("^the user switches to newest window from \"(.*?)\"\\.$")
    public void the_user_switches_to_newest_window(String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.changeWindow(testData.getDriver());
    }

    @When("^the user clicks the \"(.*?)\" in \"(.*?)\" to show alert\\.$")
    public void the_user_clicks_the_in_to_show_alert(String elementName, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        // skip snapshot for alert modal
        String browserName = System.getenv("SAUCELABS_BROWSER_NAME");
        WebDriver driver = testData.getDriver();
        //SafariDriver cannot handle alerts
        //https://github.com/seleniumhq/selenium-google-code-issue-archive/issues/3862
        if (browserName.equals("safari")) {
            ((JavascriptExecutor) driver).executeScript("confirm = function(message){return true;};");
            ((JavascriptExecutor) driver).executeScript("alert = function(message){return true;};");
            ((JavascriptExecutor) driver).executeScript("prompt = function(message){return true;}");
        }
        page.clickButtonWithoutCheckTitle(driver, elementName);
    }

    @When("^the user clicks the alert with \"(.*?)\"\\.$")
    public void the_user_clicks_the_alert_with(String buttonFlg) throws Throwable {
        //SafariDriver cannot handle alerts
        //https://github.com/seleniumhq/selenium-google-code-issue-archive/issues/3862
        String browserName = System.getenv("SAUCELABS_BROWSER_NAME");
        if (!browserName.equals("safari")) {
            if ("OK".equals(buttonFlg)) {
                testData.getDriver().switchTo().alert().accept();
                Thread.sleep(500 * 2);
            } else if ("Cancel".equals(buttonFlg)) {
                testData.getDriver().switchTo().alert().dismiss();
            } else {
                throw new Exception("buttonFlg is wrong");
            }
        }
    }

    @When("^the user clicks the \"(.*?)\" in \"(.*?)\" for (\\d+) times\\.$")
    public void the_user_clicks_the_in_for_times(String buttonName, String pageName, int clickTime) throws Throwable {
        clickAButtonInThePage(buttonName, clickTime, pageName);
    }

    @When("^the user clicks the \"(.*?)\" in \"(.*?)\" and switch window\\.$")
    public void the_user_clicks_the_in_and_switch_window(String buttonName, String pageName) throws Throwable {

        PageObjectBase page = testData.getPageObject(pageName);
        page.clickButtonAndChangeWindow(testData.getDriver(), testData.getScenario(), buttonName);
    }

    @When("^the user clicks the \"(.*?)\" in \"(.*?)\" for (\\d+) times and switch window\\.$")
    public void the_user_clicks_the_in_for_times_and_switch_window(String buttonName, String pageName, int clickTime) throws Throwable {

        PageObjectBase page = testData.getPageObject(pageName);
        page.takeAScreenshot(testData.getDriver(), testData.getScenario(), "clickButtonForTimesAndChangeWindow-before");

        try {
            for (int i = 0; i < clickTime; i++) {
                page.clickButtonWithoutCheckTitle(testData.getDriver(), buttonName);
            }
            page.changeWindow(testData.getDriver());
            page.takeAScreenshot(testData.getDriver(), testData.getScenario(), "clickButtonForTimesAndChangeWindow-after");

        } catch (Exception ex) {
            page.changeWindow(testData.getDriver());
            page.takeAScreenshot(testData.getDriver(), testData.getScenario(), "clickButtonForTimesAndChangeWindow-after");

            throw ex;
        }
    }

    @When("^the user enters \"(.*?)\" into \"(.*?)\" in \"(.*?)\"\\.$")
    public void the_user_enter_into_in(String value, String keyword, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.inputTextOrOperateKeywordWithValue(testData.getDriver(), keyword, value);
    }

    @When("^the user clears and enters \"(.*?)\" into \"(.*?)\" in \"(.*?)\"\\.$")
    public void the_user_clear_and_enter_into_in(String value, String keyword, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.putBlankToInputElement(testData.getDriver(), keyword);
        page.inputTextOrOperateKeywordWithValue(testData.getDriver(), keyword, value);
    }

    @When("^the user clears the \"(.*?)\" in \"(.*?)\"\\.$")
    public void the_user_clear_the_in(String keyword, String pageName) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        page.putBlankToInputElement(testData.getDriver(), keyword);
    }

    @When("^the user enters \"(.*?)\" into multiple types element \"(.*?)\" in \"(.*?)\"\\.$")
    public void the_user_enters_to_multiple_types_element_in(String value, String keyOrElementName, String pageName) throws Throwable {

        PageObjectBase page = testData.getPageObject(pageName);
        value = testData.getFollowingValueBySpecialKey(value);
        page.inputToMultipleTypesElementOrOperateKeyword(testData.getDriver(), keyOrElementName, value);
    }

    @When("^the user enters to elements as following in \"(.*?)\"\\.$")
    public void the_user_enters_to_elements_as_following_in(String pageName, List<List<String>> paramList) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);

        for (List<String> param : paramList) {
            if (param == null || param.size() < 2) {
                throw new Exception("The parameter must like: | elementName/operateKey | value |");
            }

            String keyOrElementName = GCSStringUtil.trimDoubleQuote(param.get(0));
            String value = GCSStringUtil.trimDoubleQuote(param.get(1));
            value = testData.getFollowingValueBySpecialKey(value);
            page.inputToMultipleTypesElementOrOperateKeyword(testData.getDriver(), keyOrElementName, value);
        }
    }

    @Then("^the value from \"(.*?)\" in \"(.*?)\" should match with \"(.*?)\"\\.$")
    public void the_value_from_in_should_match_with(String outputElementNameOrBusinessKeyword, String pageName, String expected) throws Throwable {
        expected = testData.getFollowingValue(expected);
        checkOneValueFromBusinessLogicResultOrOutputElement(pageName, outputElementNameOrBusinessKeyword, expected);

    }

    /**
     * Open a browser for user(index).
     * 
     * @param userIndex
     *            The index of user. its value like 1, 2, 3 ......
     * @throws Throwable
     */
    @When("^the user(\\d+) opens a browser to do the following operations\\.$")
    public void the_user_opens_a_browser_to_do_the_following_operations(int userIndex) throws Throwable {
        testData.getOrCreateWebDriver(userIndex - 1);
    }

    /**
     * Declaration for which users to do the following operations
     * 
     * @param userIndex
     *            The index of user. its value like 1, 2, 3 ......
     * @throws Throwable
     */
    @When("^the user(\\d+) continues to do the following operations\\.$")
    public void the_user_continues_to_do_the_following_operations(int userIndex) throws Throwable {
        testData.switchWebDriver(userIndex - 1);
    }

    /**
     * Execute Two click same element simultaneously in different browsers.
     * 
     * @param userIndex1
     *            The index of user1.
     * @param userIndex2
     *            The index of user2.
     * @param elementName
     *            The element name
     * @param pageName
     *            The page name
     * @throws Throwable
     */
    @When("^the user(\\d+) and user(\\d+) clicks the \"(.*?)\" in \"(.*?)\" at the same time\\.$")
    public void the_user_and_user_clicks_the_in_at_the_same_time(int userIndex1, int userIndex2, String elementName, String pageName) throws Throwable {
        clickAtTheSameTime(elementName, pageName, userIndex1 - 1, elementName, pageName, userIndex2 - 1);
    }

    /**
     * Execute click action simultaneously in two different browsers.
     * 
     * @param elementName1
     *            The element name of browser1
     * @param pageName1
     *            The page name of browser1
     * @param driverIndex1
     *            The driver index of browser1
     * @param elementName2
     *            The element name of browser2
     * @param pageName2
     *            The page name of browser2
     * @param driverIndex2
     *            The driver index of browser2
     * @throws InterruptedException
     * @throws ExecutionException
     */
    private void clickAtTheSameTime(final String elementName1, final String pageName1, final int driverIndex1, final String elementName2, final String pageName2, final int driverIndex2) throws InterruptedException, ExecutionException {

        ExecutorService pool = Executors.newFixedThreadPool(2);
        List<Callable<Boolean>> tasks = new ArrayList<Callable<Boolean>>();

        final PageObjectBase page1 = testData.getPageObject(pageName1);
        tasks.add(new Callable<Boolean>() {
            public Boolean call() throws Exception {
                page1.clickButtonWithoutCheckTitle(testData.getDriver(driverIndex1), testData.getScenario(), elementName1);
                return Boolean.TRUE;
            }
        });

        final PageObjectBase page2 = testData.getPageObject(pageName2);
        tasks.add(new Callable<Boolean>() {
            public Boolean call() throws Exception {
                page2.clickButtonWithoutCheckTitle(testData.getDriver(driverIndex2), testData.getScenario(), elementName2);
                return Boolean.TRUE;
            }
        });

        if ((new Random()).nextBoolean()) {
            Collections.reverse(tasks);
        }

        List<Future<Boolean>> futures = pool.invokeAll(tasks);

        for (Future<Boolean> f : futures) {
            f.get();
        }
    }

    /**
     * Open page with a given URL
     * When parameter is SpecialKey, get store URL by SpecialKey then open page.
     * 
     * @param url URL or SpecialKey for stored URL
     * @throws Throwable
     */
    @When("^the user opens page by url \"(.*?)\"\\.$")
    public void the_user_opens_page_by_url(String url) throws Throwable {
        url = testData.getFollowingValueBySpecialKey(url);
        testData.getDriver().get(url);
    }

    /**
     * Store the value of element in page to SharedTestScenarioData.
     * 
     * @param elementName The element name declare in PageObject
     * @param pageName The page name declare in Steps
     * @param storeKey The key for store
     * @throws Throwable
     */
    @When("^store value of element \"(.*?)\" in \"(.*?)\" to \"(.*?)\"\\.$")
    public void store_value_of_element_in_to(String elementName, String pageName, String storeKey) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);
        String value = page.getBusinessLogicResultOrOutputElementValueByKeywordOrOutputElementName(testData.getDriver(), elementName);
        testData.putFollowingValue(storeKey, value);
    }

    /**
     * Store the value of elements in page to SharedTestScenarioData.
     * 
     * @param pageName The page name declare in Steps
     * @param paramList The parameter must like: | elementName | storeKey |
     *            elementName is the element name declare in PageObject
     *            storeKey is the key for store
     * @throws Throwable
     */
    @When("^store value of element in \"(.*?)\" as following\\.$")
    public void store_value_of_element_in_as_following(String pageName, List<List<String>> paramList) throws Throwable {
        PageObjectBase page = testData.getPageObject(pageName);

        for (List<String> param : paramList) {
            if (param == null || param.size() < 2) {
                throw new Exception("The parameter must like: | elementName | storeKey |");
            }
            String elementName = GCSStringUtil.trimDoubleQuote(param.get(0));
            String storeKey = GCSStringUtil.trimDoubleQuote(param.get(1));
            String value = page.getBusinessLogicResultOrOutputElementValueByKeywordOrOutputElementName(testData.getDriver(), elementName);
            testData.putFollowingValue(storeKey, value);
        }
    }

    /**
     * Store the value of cookie to SharedTestScenarioData
     * 
     * @param cookieName The Name of cookie
     * @param storeKey The key for store
     * @throws Throwable
     */
    @When("^store value of cookie \"(.*?)\" to \"(.*?)\"\\.$")
    public void store_value_of_cookie_to(String cookieName, String storeKey) throws Throwable {
        Cookie cookie = testData.getDriver().manage().getCookieNamed(cookieName);
        testData.putFollowingValue(storeKey, cookie.getValue());
    }

    /**
     * Store given value to SharedTestScenarioData
     * 
     * @param value The value for store
     * @param storeKey The key for store
     * @throws Throwable
     */
    @When("^store value \"(.*?)\" to \"(.*?)\"\\.$")
    public void store_value_to(String value, String storeKey) throws Throwable {
        testData.putFollowingValue(storeKey, value);
    }

    /**
     * Delete cookie by name.
     * 
     * @param cookieName cookie name
     * @throws Throwable
     */
    @When("^delete the cookie \"(.*?)\"\\.$")
    public void delete_the_cookie(String cookieName) throws Throwable {
        testData.getDriver().manage().deleteCookieNamed(cookieName);
    }

    /**
     * Delete all cookies of browser.
     * 
     * @throws Throwable
     */
    @When("^delete all cookies\\.$")
    public void delete_all_cookie() throws Throwable {
        testData.getDriver().manage().deleteAllCookies();
    }

    /**
     * Check weather the cookie exist.
     *
     * @param cookiename Cookie name
     * @throws Throwable
     */
    @Then("^the cookie \"(.*?)\" exist\\.$")
    public void the_cookie_exist(String cookieName) throws Throwable {
        String expected = "exist";
        String actual = isCookieExist(cookieName) ? "exist" : "Not exist";

        testData.write(String.format("Expected Cookie %s %s", cookieName, expected));
        testData.write(String.format("Actual   Cookie %s %s", cookieName, actual));
        assertEquals("Cookie is Not exist", expected, actual);
    }

    /**
     * Check weather the cookie Not exist.
     *
     * @param cookiename Cookie name
     * @throws Throwable
     */
    @Then("^the cookie \"(.*?)\" Not exist\\.$")
    public void the_cookie_Not_exist(String cookieName) throws Throwable {
        String expected = "Not exist";
        String actual = isCookieExist(cookieName) ? "exist" : "Not exist";

        testData.write(String.format("Expected Cookie %s %s", cookieName, expected));
        testData.write(String.format("Actual   Cookie %s %s", cookieName, actual));
        assertEquals("Cookie is Not exist", expected, actual);
    }

    /**
     * Check whether the cookie exist
     * 
     * @param cookiename Cookie name
     * @return true (exist) , false(not exist)
     */
    private boolean isCookieExist(String cookieName) {
        return testData.getDriver().manage().getCookieNamed(cookieName) != null;
    }
}
