package com.rakuten.gcs.testautomation.framework.web;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * Created by aldo.suwandi on 2015/07/22.
 */
public class DeviceOption {

    private String capabilityName;

    private Object capabilityOption;

    private DesiredCapabilities capabilities;

    public DeviceOption(String platformName, String version, String os, String browserLocale) {
        switch (platformName) {
            case "iOS": {
                capabilities = DesiredCapabilities.iphone();
                capabilities.setCapability("appiumVersion", "1.6.5");
                capabilities.setCapability("platformVersion", version);
                capabilities.setCapability("deviceName", os);
                capabilities.setCapability("deviceOrientation", "portrait");
                capabilities.setCapability("platformName", "iOS");
                capabilities.setCapability("browserName", "safari");
                capabilities.setCapability("language", browserLocale);
                break;
            }
            case "Android": {
                capabilities = DesiredCapabilities.android();
                capabilities.setCapability("appiumVersion", "1.6.4");
                capabilities.setCapability("deviceName", os);
                capabilities.setCapability("deviceOrientation", "portrait");
                capabilities.setCapability("browserName", "Browser");
                capabilities.setCapability("platformVersion", version);
                capabilities.setCapability("platformName", "Android");
                capabilities.setCapability("language", browserLocale);
                break;
            }
        }
    }

    public DesiredCapabilities getCapabilities() {
        return capabilities;
    }

    public void setCapabilities(DesiredCapabilities capabilities) {
        this.capabilities = capabilities;
    }
}
