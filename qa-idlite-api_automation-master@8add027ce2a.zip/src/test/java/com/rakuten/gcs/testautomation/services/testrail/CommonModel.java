package com.rakuten.gcs.testautomation.services.testrail;

import com.rakuten.gcs.testautomation.services.testrail.SharedStorage;

public class CommonModel {

	public static void addTestCaseIdsToSharedStorage(String suite, Object testCaseId) {
        SharedStorage.getInstance().addData("suite", suite);
        SharedStorage.getInstance().addData("test-case-id", testCaseId);
    }
}
 