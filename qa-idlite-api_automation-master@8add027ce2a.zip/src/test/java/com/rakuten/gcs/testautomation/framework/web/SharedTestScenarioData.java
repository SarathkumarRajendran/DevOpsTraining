package com.rakuten.gcs.testautomation.framework.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;

public class SharedTestScenarioData {

    /** Pattern for special Key for FollowingValueMap */
    private static final String SPECIAL_KEY_PATTERN = "^\\$\\{(.*?)\\}$";

    private final Log logger = LogFactory.getLog(SharedTestScenarioData.class);

    private Scenario scenario;
    private List<WebDriver> driers = new ArrayList<WebDriver>();
    private int activeDriverIndex = -1;
    private String proxy;
    private String lang;

    private Map<String, PageObjectBase> pageObjectMap;
    private Map<String, String> PCIDMap;
    private Map<String, String> GidMap;
    private Map<String, String> NewLuckyIncentiveIDMap;
    private Map<String, String> FollowingValueMap;

    public SharedTestScenarioData() {
        pageObjectMap = new HashMap<String, PageObjectBase>();
        PCIDMap = new HashMap<String, String>();
        NewLuckyIncentiveIDMap = new HashMap<String, String>();
        FollowingValueMap = new HashMap<String, String>();
    }

    public void initializeAndGetWebDriver(Scenario scenario, String proxy, String lang) throws Exception {
        this.scenario = scenario;
        this.proxy = proxy;
        this.lang = lang;
        this.driers.clear();
        this.driers.add(WebDriverInitializer.getDriver(this.scenario.getName(), this.proxy, this.lang));
        this.activeDriverIndex = 0;
    }

    /**
     * Set property only, do NOT create the driver.
     * 
     * @param scenario Scenario
     * @param proxy proxy for browser.
     * @param lang browser language
     */
    public void initializeAndSetProperty(Scenario scenario, String proxy, String lang) {
        this.scenario = scenario;
        this.proxy = proxy;
        this.lang = lang;
        this.driers.clear();
    }

    /**
     * When the driver exists, return it.<br>
     * When the driver does NOT exist, create a new.<br>
     * 
     * @return the driver The web driver
     * @throws Exception
     */
    public WebDriver getOrCreateWebDriver() throws Exception {

        return getOrCreateWebDriver(0);
    }

    /**
     * When the driver of index exists, return it, and set the active index.<br>
     * When the driver of index does NOT exist, create a new, and set the active index.<br>
     * 
     * @param index
     *            The index of driver. its value like 0, 1, 2 ......
     * @return the driver The web driver
     * @throws Exception
     */
    public WebDriver getOrCreateWebDriver(int index) throws Exception {
        WebDriver driver;
        if (index < this.driers.size() && this.driers.get(index) != null) {
            driver = this.driers.get(index);

        } else {
            driver = WebDriverInitializer.getDriver(this.scenario.getName(), this.proxy, this.lang);
            this.driers.add(index, driver);
        }

        this.activeDriverIndex = index;

        return driver;
    }

    /**
     * Set the active index to index.
     * 
     * @param index
     *            The index of driver. its value like 0, 1, 2 ......
     * @return the driver of index.
     */
    public WebDriver switchWebDriver(int index) {
        WebDriver driver = this.driers.get(index);
        this.activeDriverIndex = index;

        return driver;
    }

    public void quitDriver() {
        logger.info("Quit WebDriver in SharedTestScenarioData ");
        for (WebDriver drv : this.driers) {
            drv.quit();
        }
        this.driers.clear();
        this.activeDriverIndex = -1;
    }

    public void putPageObject(String name, PageObjectBase pageObject) {
        logger.info(String.format("Putting pageobject to SharedTestScenarioData. The name of page is %s.", name));
        pageObjectMap.put(name, pageObject);
    }

    public Scenario getScenario() {
        return scenario;
    }

    public boolean isScenarioFailed() {
        return scenario.isFailed();
    }

    public PageObjectBase getPageObject(String name) {
        return pageObjectMap.get(name);
    }

    public WebDriver getDriver() {
        return getDriver(this.activeDriverIndex);
    }

    public WebDriver getDriver(int index) {
        return this.driers.get(index);
    }

    public Map<String, PageObjectBase> getPageObjectMap() {
        return pageObjectMap;
    }

    public void write(String text) {
        scenario.write(text);
    }

    public Map<String, String> getPCIDMap() {
        return PCIDMap;
    }

    public String getPCID(String key) {
        return PCIDMap.get(key);
    }

    public Map<String, String> getNewLuckyIncentiveIDMap() {
        return NewLuckyIncentiveIDMap;
    }

    public String getNewLuckyIncentiveID(String key) {
        return NewLuckyIncentiveIDMap.get(key);
    }

    public void putNewLuckyIncentiveID(String key, String NewLuckyIncentiveID) {
        NewLuckyIncentiveIDMap.put(key, NewLuckyIncentiveID);
    }

    public void putPCID(String key, String PCIDValue) {
        PCIDMap.put(key, PCIDValue);
    }

    public Map<String, String> getGidMap() {
        return GidMap;
    }

    public String getGid(String key) {
        return GidMap.get(key);
    }

    public void putGid(String key, String value) {
        GidMap.put(key, value);
    }

    public void putNewLuckyIncentiveIDMap(Map<String, String> newLuckyIncentiveIDMap) {
        NewLuckyIncentiveIDMap = newLuckyIncentiveIDMap;
    }

    public Map<String, String> getFollowingValueMap() {
        return FollowingValueMap;
    }

    public String getFollowingValue(String key) {
        return FollowingValueMap.get(key);
    }

    public void putFollowingValue(String key, String value) {
        FollowingValueMap.put(key, value);
    }

    /**
     * <pre>
     * When the specialKey like ${key}, and the key is contains in FollowingValueMap, 
     * then return the value in FollowingValueMap for the key
     * </pre>
     * 
     * @param specialKey The key like ${key}
     * @return When contains key then return value, otherwise return the specialKey.
     */
    public String getFollowingValueBySpecialKey(String specialKey) {
        Pattern pattern = Pattern.compile(SPECIAL_KEY_PATTERN);
        Matcher matcher = pattern.matcher(specialKey);
        String value = specialKey;
        if (matcher.matches() && FollowingValueMap.containsKey(matcher.group(1))) {
            value = getFollowingValue(matcher.group(1));
        }
        return value;
    }

    public void closeDriver() {
        logger.info("Close WebDriver in SharedTestScenarioData ");
        for (WebDriver drv : this.driers) {
            drv.close();
        }
        this.driers.clear();
        this.activeDriverIndex = -1;
    }
}
